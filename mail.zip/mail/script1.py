# Backend - Main Flask App
app_py_content = """
import os
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from datetime import timedelta

# Import your existing modules
from config import Config
from database.connection import init_db
from api.auth_routes import auth_bp
from api.admin_routes import admin_bp
from api.mail_routes import mail_bp
from api.user_routes import user_bp

def create_app():
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(Config)
    
    # Setup CORS for your domain
    CORS(app, origins=[
        "https://datainteg.in",
        "https://www.datainteg.in", 
        "https://datainteg.in/mailserver",
        "http://localhost:3000"  # For development
    ], supports_credentials=True)
    
    # Setup JWT
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET', 'datainteg-mail-server-2025')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=30)
    jwt = JWTManager(app)
    
    # Initialize database
    init_db()
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    app.register_blueprint(mail_bp, url_prefix='/api/mail')
    app.register_blueprint(user_bp, url_prefix='/api/user')
    
    # Health check endpoint
    @app.route('/api/health', methods=['GET'])
    def health_check():
        return jsonify({
            "status": "running",
            "message": "DataInteg Mail Server API",
            "version": "2.0.0",
            "domain": "datainteg.in"
        }), 200
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Endpoint not found"}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({"error": "Internal server error"}), 500
    
    # Setup logging
    if not app.debug:
        logging.basicConfig(level=logging.INFO)
        app.logger.info('DataInteg Mail Server startup')
    
    return app

if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=os.getenv('FLASK_ENV') == 'development')
"""

# Write the main app file
with open('DATAINTEG-MAILSERVER/backend/app.py', 'w') as f:
    f.write(app_py_content)

print("✅ Created main Flask app (app.py)")