# Backend Configuration
config_py_content = """
import os
from datetime import timedelta

class Config:
    # Basic Flask config
    SECRET_KEY = os.getenv('SECRET_KEY', 'datainteg-mail-server-secret-key-2025')
    DEBUG = os.getenv('FLASK_ENV', 'production') == 'development'
    
    # MongoDB Configuration
    MONGO_URI = os.getenv('MONGO_URI', 'mongodb://admin:DataInteg@2025@localhost:27017/datainteg_mail?authSource=admin')
    MONGO_DB_NAME = os.getenv('MONGO_DB_NAME', 'datainteg_mail')
    
    # JWT Configuration
    JWT_SECRET_KEY = os.getenv('JWT_SECRET', 'datainteg-jwt-secret-2025')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=30)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=90)
    
    # Mail Server Configuration for datainteg.in
    MAIL_SERVER = os.getenv('MAIL_SERVER', 'smtp.hostinger.com')  # Hostinger SMTP
    MAIL_PORT = int(os.getenv('MAIL_PORT', 587))
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = os.getenv('MAIL_USERNAME', 'noreply@datainteg.in')
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', 'your_email_password')
    MAIL_DEFAULT_SENDER = os.getenv('MAIL_DEFAULT_SENDER', 'DataInteg Mail <noreply@datainteg.in>')
    
    # Domain Configuration
    DOMAIN = os.getenv('DOMAIN', 'datainteg.in')
    MAIL_DOMAIN = f"@{DOMAIN}"
    
    # File Upload Configuration
    MAX_CONTENT_LENGTH = 25 * 1024 * 1024  # 25MB max file size
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'zip'}
    
    # Security Configuration
    WTF_CSRF_ENABLED = True
    WTF_CSRF_SECRET_KEY = os.getenv('CSRF_SECRET', 'csrf-secret-key-2025')
    
    # IMAP/POP3 Configuration (if needed)
    IMAP_SERVER = os.getenv('IMAP_SERVER', 'imap.hostinger.com')
    IMAP_PORT = int(os.getenv('IMAP_PORT', 993))
    IMAP_USE_SSL = True
    
    # Rate Limiting
    RATELIMIT_STORAGE_URL = os.getenv('REDIS_URL', 'redis://localhost:6379')
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    
class DevelopmentConfig(Config):
    DEBUG = True
    MONGO_URI = 'mongodb://admin:DataInteg@2025@localhost:27017/datainteg_mail_dev?authSource=admin'

class ProductionConfig(Config):
    DEBUG = False
    # Use environment variables in production
    
class TestingConfig(Config):
    TESTING = True
    MONGO_URI = 'mongodb://admin:DataInteg@2025@localhost:27017/datainteg_mail_test?authSource=admin'

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
"""

# Backend Requirements
requirements_content = """
Flask==2.3.3
Flask-CORS==4.0.0
Flask-JWT-Extended==4.5.3
Flask-Mail==0.9.1
Flask-Limiter==3.5.0
pymongo==4.5.0
bcrypt==4.0.1
python-dotenv==1.0.0
email-validator==2.0.0
Pillow==10.0.1
gunicorn==21.2.0
redis==5.0.1
celery==5.3.4
cryptography==41.0.7
python-multipart==0.0.6
validators==0.22.0
python-dateutil==2.8.2
requests==2.31.0
dnspython==2.4.2
"""

# Environment file
env_content = """
# Flask Configuration
FLASK_ENV=development
SECRET_KEY=datainteg-mail-server-secret-key-2025
JWT_SECRET=datainteg-jwt-secret-2025

# MongoDB Configuration
MONGO_URI=mongodb://admin:DataInteg@2025@localhost:27017/datainteg_mail?authSource=admin
MONGO_DB_NAME=datainteg_mail

# Mail Server Configuration (Hostinger)
MAIL_SERVER=smtp.hostinger.com
MAIL_PORT=587
MAIL_USERNAME=noreply@datainteg.in
MAIL_PASSWORD=your_hostinger_email_password
MAIL_DEFAULT_SENDER=DataInteg Mail <noreply@datainteg.in>

# IMAP Configuration
IMAP_SERVER=imap.hostinger.com
IMAP_PORT=993

# Domain Configuration
DOMAIN=datainteg.in

# Security
CSRF_SECRET=csrf-secret-key-2025

# Redis (Optional for rate limiting)
REDIS_URL=redis://localhost:6379

# Logging
LOG_LEVEL=INFO

# File Upload
UPLOAD_FOLDER=./uploads
MAX_FILE_SIZE=25MB
"""

# Write configuration files
with open('DATAINTEG-MAILSERVER/backend/config.py', 'w') as f:
    f.write(config_py_content)

with open('DATAINTEG-MAILSERVER/backend/requirements.txt', 'w') as f:
    f.write(requirements_content)

with open('DATAINTEG-MAILSERVER/backend/.env', 'w') as f:
    f.write(env_content)

print("✅ Created configuration files:")
print("  - config.py")
print("  - requirements.txt") 
print("  - .env")