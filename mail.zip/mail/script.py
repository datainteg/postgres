import os
import zipfile

# Create the complete project structure
project_structure = {
    "DATAINTEG-MAILSERVER": {
        "backend": {
            "app.py": "",
            "config.py": "",
            "requirements.txt": "",
            ".env": "",
            "api": {
                "__init__.py": "",
                "auth_routes.py": "",
                "admin_routes.py": "",
                "mail_routes.py": "",
                "user_routes.py": "",
                "utils.py": ""
            },
            "database": {
                "__init__.py": "",
                "connection.py": "",
                "operations.py": "",
                "migrations.py": ""
            },
            "email_server": {
                "__init__.py": "",
                "smtp_server.py": "",
                "imap_server.py": "",
                "mail_handler.py": ""
            },
            "models": {
                "__init__.py": "",
                "user.py": "",
                "email.py": "",
                "folder.py": "",
                "attachment.py": "",
                "domain.py": "",
                "mailbox.py": ""
            },
            "utils": {
                "__init__.py": "",
                "auth_utils.py": "",
                "email_utils.py": "",
                "file_utils.py": "",
                "smtp_utils.py": "",
                "validation_utils.py": ""
            },
            "templates": {
                "welcome_email.html": "",
                "password_reset.html": ""
            }
        },
        "frontend": {
            "package.json": "",
            "next.config.js": "",
            "tailwind.config.js": "",
            "postcss.config.js": "",
            ".env.local": "",
            "pages": {
                "_app.js": "",
                "_document.js": "",
                "index.js": "",
                "login.js": "",
                "admin": {
                    "index.js": "",
                    "users.js": "",
                    "onboard.js": ""
                },
                "mail": {
                    "index.js": "",
                    "compose.js": "",
                    "inbox.js": ""
                },
                "api": {
                    "auth": {
                        "login.js": "",
                        "logout.js": ""
                    },
                    "mail": {
                        "send.js": "",
                        "inbox.js": ""
                    }
                }
            },
            "components": {
                "Layout": {
                    "Layout.js": "",
                    "Sidebar.js": "",
                    "Header.js": ""
                },
                "Auth": {
                    "LoginForm.js": "",
                    "ProtectedRoute.js": ""
                },
                "Mail": {
                    "MailList.js": "",
                    "MailComposer.js": "",
                    "MailViewer.js": "",
                    "AttachmentHandler.js": ""
                },
                "Admin": {
                    "UserOnboarding.js": "",
                    "UserManagement.js": "",
                    "AdminDashboard.js": ""
                }
            },
            "styles": {
                "globals.css": "",
                "outlook-theme.css": ""
            },
            "public": {
                "favicon.ico": "",
                "logo.png": ""
            }
        },
        "docker-compose.yml": "",
        "README.md": "",
        "deployment": {
            "nginx.conf": "",
            "ssl-setup.sh": "",
            "deploy.sh": ""
        }
    }
}

def create_structure(structure, base_path=""):
    for name, content in structure.items():
        path = os.path.join(base_path, name)
        if isinstance(content, dict):
            os.makedirs(path, exist_ok=True)
            create_structure(content, path)
        else:
            with open(path, 'w') as f:
                f.write(content)

# Create the project structure
create_structure(project_structure)
print("Project structure created successfully!")
print(f"Root directory: {os.path.abspath('DATAINTEG-MAILSERVER')}")