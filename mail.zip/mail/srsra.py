# UserOnboarding Component (Admin)
user_onboarding_content = """import { useState } from 'react';
import { CheckIcon, XMarkIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';

export default function UserOnboarding({ onSuccess }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    
    // Company Information
    username: '',
    password: '',
    confirmPassword: '',
    employeeId: '',
    department: '',
    position: '',
    joiningDate: '',
    reportingManager: '',
    
    // Role Assignment
    roles: ['user'],
    
    // System Settings
    timezone: 'Asia/Kolkata',
    language: 'en'
  });

  const updateFormData = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep = (step) => {
    switch (step) {
      case 1:
        return formData.firstName && formData.lastName && formData.email;
      case 2:
        return formData.username && formData.password && 
               formData.password === formData.confirmPassword && 
               formData.employeeId && formData.department;
      default:
        return true;
    }
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    } else {
      toast.error('Please fill all required fields');
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    if (!validateStep(currentStep)) {
      toast.error('Please complete all required fields');
      return;
    }

    setLoading(true);

    try {
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/users`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          first_name: formData.firstName,
          last_name: formData.lastName,
          email: formData.email,
          phone_number: formData.phoneNumber,
          username: formData.username,
          password: formData.password,
          employee_id: formData.employeeId,
          department: formData.department,
          position: formData.position,
          joining_date: formData.joiningDate,
          reporting_manager: formData.reportingManager,
          roles: formData.roles,
          timezone: formData.timezone,
          language: formData.language,
          is_active: true
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        toast.success(`User ${formData.firstName} ${formData.lastName} has been successfully onboarded!`);
        onSuccess();
      } else {
        toast.error(data.error || 'Failed to onboard user');
      }
    } catch (error) {
      console.error('Onboarding error:', error);
      toast.error('Failed to onboard user');
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Personal Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  First Name *
                </label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => updateFormData('firstName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Last Name *
                </label>
                <input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => updateFormData('lastName', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateFormData('email', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => updateFormData('phoneNumber', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Company & Login Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Username *
                </label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => updateFormData('username', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Email will be: {formData.username}@datainteg.in
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee ID *
                </label>
                <input
                  type="text"
                  value={formData.employeeId}
                  onChange={(e) => updateFormData('employeeId', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => updateFormData('password', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password *
                </label>
                <input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => updateFormData('confirmPassword', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                />
                {formData.password && formData.confirmPassword && formData.password !== formData.confirmPassword && (
                  <p className="text-xs text-red-600 mt-1">Passwords do not match</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department *
                </label>
                <select
                  value={formData.department}
                  onChange={(e) => updateFormData('department', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                  required
                >
                  <option value="">Select Department</option>
                  <option value="IT">Information Technology</option>
                  <option value="HR">Human Resources</option>
                  <option value="Finance">Finance</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Sales">Sales</option>
                  <option value="Operations">Operations</option>
                  <option value="Data Engineering">Data Engineering</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Job Position
                </label>
                <input
                  type="text"
                  value={formData.position}
                  onChange={(e) => updateFormData('position', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Joining Date
                </label>
                <input
                  type="date"
                  value={formData.joiningDate}
                  onChange={(e) => updateFormData('joiningDate', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Reporting Manager
                </label>
                <input
                  type="text"
                  value={formData.reportingManager}
                  onChange={(e) => updateFormData('reportingManager', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                />
              </div>
            </div>
            
            {/* Role Assignment */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-3">Role Assignment</h4>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.roles.includes('user')}
                    onChange={(e) => {
                      const roles = e.target.checked 
                        ? [...formData.roles, 'user']
                        : formData.roles.filter(r => r !== 'user');
                      updateFormData('roles', roles);
                    }}
                    className="mr-2 text-outlook-blue focus:ring-outlook-blue"
                  />
                  User (Standard Email Access)
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.roles.includes('admin')}
                    onChange={(e) => {
                      const roles = e.target.checked 
                        ? [...formData.roles, 'admin']
                        : formData.roles.filter(r => r !== 'admin');
                      updateFormData('roles', roles);
                    }}
                    className="mr-2 text-outlook-blue focus:ring-outlook-blue"
                  />
                  Admin (Full System Access)
                </label>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const totalSteps = 2;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-outlook">
        <div className="p-6">
          {/* Header */}
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Onboard New Employee</h2>
            <p className="text-gray-600">Create a new user account for DataInteg Mail</p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Step {currentStep} of {totalSteps}</span>
              <span className="text-sm text-gray-500">{Math.round((currentStep / totalSteps) * 100)}% Complete</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-outlook-blue h-2 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Form Content */}
          {renderStep()}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className="px-6 py-2 text-gray-600 bg-gray-200 rounded-lg hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            
            {currentStep < totalSteps ? (
              <button
                onClick={nextStep}
                className="px-6 py-2 bg-outlook-blue text-white rounded-lg hover:bg-outlook-darkblue transition-colors"
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={loading}
                className="px-6 py-2 bg-mail-green text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin-slow w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Creating Account...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <CheckIcon className="w-4 h-4 mr-2" />
                    Onboard Employee
                  </div>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
"""

# UserManagement Component (Admin)
user_management_content = """import { useState, useEffect } from 'react';
import {
  UserIcon,
  PencilIcon,
  TrashIcon,
  MagnifyingGlassIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';
import { format } from 'date-fns';

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('');
  const [filterRole, setFilterRole] = useState('');
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/users`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setUsers(data.data.users || []);
      } else {
        toast.error('Failed to load users');
      }
    } catch (error) {
      console.error('Failed to load users:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (userId) => {
    if (!confirm('Are you sure you want to deactivate this user?')) return;

    try {
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        toast.success('User deactivated successfully');
        loadUsers(); // Refresh the list
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to deactivate user');
      }
    } catch (error) {
      console.error('Failed to delete user:', error);
      toast.error('Failed to deactivate user');
    }
  };

  const handleToggleUserStatus = async (userId, currentStatus) => {
    try {
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          is_active: !currentStatus
        }),
      });

      if (response.ok) {
        toast.success(`User ${!currentStatus ? 'activated' : 'deactivated'} successfully`);
        loadUsers();
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to update user status');
      }
    } catch (error) {
      console.error('Failed to toggle user status:', error);
      toast.error('Failed to update user status');
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = searchQuery === '' || 
      user.display_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDepartment = filterDepartment === '' || user.department === filterDepartment;
    const matchesRole = filterRole === '' || user.roles?.includes(filterRole);
    
    return matchesSearch && matchesDepartment && matchesRole;
  });

  const departments = [...new Set(users.map(u => u.department).filter(Boolean))];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin-slow w-8 h-8 border-2 border-outlook-blue border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-outlook-gray-600">Loading users...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-outlook-gray-900 mb-2">User Management</h1>
        <p className="text-outlook-gray-600">Manage user accounts and permissions</p>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-outlook mb-6">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex-1 min-w-64">
            <div className="relative">
              <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-3 text-outlook-gray-400" />
              <input
                type="text"
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
              />
            </div>
          </div>
          
          <select
            value={filterDepartment}
            onChange={(e) => setFilterDepartment(e.target.value)}
            className="px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
          >
            <option value="">All Departments</option>
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
          
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
          >
            <option value="">All Roles</option>
            <option value="admin">Admin</option>
            <option value="user">User</option>
          </select>
          
          <button
            onClick={loadUsers}
            className="px-4 py-2 bg-outlook-blue text-white rounded-md hover:bg-outlook-darkblue transition-colors"
          >
            Refresh
          </button>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-lg shadow-outlook overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-outlook-gray-200">
            <thead className="bg-outlook-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-outlook-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-outlook-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-outlook-gray-500 uppercase tracking-wider">
                  Role
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-outlook-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-outlook-gray-500 uppercase tracking-wider">
                  Created
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-outlook-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-outlook-gray-200">
              {filteredUsers.map((user) => (
                <tr key={user._id} className="hover:bg-outlook-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 bg-outlook-blue rounded-full flex items-center justify-center text-white font-semibold mr-4">
                        {user.first_name?.charAt(0)}{user.last_name?.charAt(0)}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-outlook-gray-900">
                          {user.display_name || `${user.first_name} ${user.last_name}`}
                        </div>
                        <div className="text-sm text-outlook-gray-500">{user.email}</div>
                        <div className="text-xs text-outlook-gray-400">ID: {user.employee_id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-outlook-gray-900">{user.department || 'Not set'}</div>
                    <div className="text-sm text-outlook-gray-500">{user.position || 'No position'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-wrap gap-1">
                      {user.roles?.map(role => (
                        <span
                          key={role}
                          className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full \\${
                            role === 'admin' 
                              ? 'bg-mail-purple text-white' 
                              : 'bg-mail-green text-white'
                          }`}
                        >
                          {role}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button
                      onClick={() => handleToggleUserStatus(user._id, user.is_active)}
                      className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full cursor-pointer transition-colors \\${
                        user.is_active 
                          ? 'bg-mail-green text-white hover:bg-green-700' 
                          : 'bg-mail-red text-white hover:bg-red-700'
                      }`}
                    >
                      {user.is_active ? 'Active' : 'Inactive'}
                    </button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-outlook-gray-500">
                    {user.created_at ? format(new Date(user.created_at), 'MMM dd, yyyy') : 'Unknown'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => setEditingUser(user)}
                        className="text-outlook-blue hover:text-outlook-darkblue transition-colors"
                        title="Edit user"
                      >
                        <PencilIcon className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteUser(user._id)}
                        className="text-mail-red hover:text-red-700 transition-colors"
                        title="Deactivate user"
                      >
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredUsers.length === 0 && !loading && (
          <div className="text-center py-8">
            <UserIcon className="h-12 w-12 text-outlook-gray-400 mx-auto mb-4" />
            <p className="text-outlook-gray-600">No users found</p>
          </div>
        )}
      </div>

      {/* Stats Summary */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-outlook">
          <div className="text-2xl font-bold text-outlook-blue">{users.length}</div>
          <div className="text-sm text-outlook-gray-600">Total Users</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-outlook">
          <div className="text-2xl font-bold text-mail-green">
            {users.filter(u => u.is_active).length}
          </div>
          <div className="text-sm text-outlook-gray-600">Active Users</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-outlook">
          <div className="text-2xl font-bold text-mail-purple">
            {users.filter(u => u.roles?.includes('admin')).length}
          </div>
          <div className="text-sm text-outlook-gray-600">Admins</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-outlook">
          <div className="text-2xl font-bold text-mail-orange">
            {departments.length}
          </div>
          <div className="text-sm text-outlook-gray-600">Departments</div>
        </div>
      </div>
    </div>
  );
}
"""

# DashboardStats Component (Admin)
dashboard_stats_content = """import { useState, useEffect } from 'react';
import { 
  UsersIcon, 
  ServerIcon, 
  EnvelopeIcon,
  ChartBarIcon 
} from '@heroicons/react/24/outline';

export default function DashboardStats({ stats, onRefresh }) {
  const [systemHealth, setSystemHealth] = useState('checking');

  useEffect(() => {
    checkSystemHealth();
    const interval = setInterval(checkSystemHealth, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const checkSystemHealth = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/health`);
      setSystemHealth(response.ok ? 'healthy' : 'degraded');
    } catch (error) {
      setSystemHealth('unhealthy');
    }
  };

  const getHealthColor = (status) => {
    switch (status) {
      case 'healthy': return 'text-mail-green';
      case 'degraded': return 'text-mail-orange';
      case 'unhealthy': return 'text-mail-red';
      default: return 'text-outlook-gray-500';
    }
  };

  const getHealthBg = (status) => {
    switch (status) {
      case 'healthy': return 'bg-green-100';
      case 'degraded': return 'bg-orange-100';
      case 'unhealthy': return 'bg-red-100';
      default: return 'bg-gray-100';
    }
  };

  if (!stats) {
    return (
      <div className="p-6 flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin-slow w-8 h-8 border-2 border-outlook-blue border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-outlook-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-outlook-gray-900">Admin Dashboard</h1>
          <p className="text-outlook-gray-600">Overview of your mail server</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className={`px-3 py-1 rounded-full text-sm font-medium \\${getHealthBg(systemHealth)}`}>
            <span className={getHealthColor(systemHealth)}>
              System {systemHealth.charAt(0).toUpperCase() + systemHealth.slice(1)}
            </span>
          </div>
          <button
            onClick={onRefresh}
            className="px-4 py-2 bg-outlook-blue text-white rounded-md hover:bg-outlook-darkblue transition-colors"
          >
            Refresh
          </button>
        </div>
      </div>

      {/* Main Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-outlook p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <UsersIcon className="h-8 w-8 text-outlook-blue" />
            </div>
            <div className="ml-4">
              <div className="text-2xl font-bold text-outlook-gray-900">
                {stats.users.total}
              </div>
              <div className="text-sm text-outlook-gray-600">Total Users</div>
              <div className="text-xs text-mail-green">
                +{stats.users.recent} this week
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-outlook p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="h-8 w-8 bg-mail-green rounded-lg flex items-center justify-center">
                <span className="text-white font-semibold">✓</span>
              </div>
            </div>
            <div className="ml-4">
              <div className="text-2xl font-bold text-outlook-gray-900">
                {stats.users.active}
              </div>
              <div className="text-sm text-outlook-gray-600">Active Users</div>
              <div className="text-xs text-outlook-gray-500">
                {stats.users.inactive} inactive
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-outlook p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="h-8 w-8 bg-mail-purple rounded-lg flex items-center justify-center">
                <span className="text-white font-semibold">⚡</span>
              </div>
            </div>
            <div className="ml-4">
              <div className="text-2xl font-bold text-outlook-gray-900">
                {stats.users.admins}
              </div>
              <div className="text-sm text-outlook-gray-600">Administrators</div>
              <div className="text-xs text-outlook-gray-500">
                {((stats.users.admins / stats.users.total) * 100).toFixed(1)}% of total
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-outlook p-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ServerIcon className="h-8 w-8 text-mail-orange" />
            </div>
            <div className="ml-4">
              <div className="text-2xl font-bold text-outlook-gray-900">
                {Object.keys(stats.departments).length}
              </div>
              <div className="text-sm text-outlook-gray-600">Departments</div>
              <div className={`text-xs \\${getHealthColor(systemHealth)}`}>
                System {systemHealth}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Department Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-outlook p-6">
          <h3 className="text-lg font-semibold text-outlook-gray-900 mb-4">
            Department Distribution
          </h3>
          <div className="space-y-3">
            {Object.entries(stats.departments).map(([dept, count]) => (
              <div key={dept} className="flex items-center justify-between">
                <span className="text-sm text-outlook-gray-700">{dept}</span>
                <div className="flex items-center">
                  <div className="w-24 bg-outlook-gray-200 rounded-full h-2 mr-3">
                    <div 
                      className="bg-outlook-blue h-2 rounded-full"
                      style={{ width: `${(count / stats.users.total) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium text-outlook-gray-900 w-8">
                    {count}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-outlook p-6">
          <h3 className="text-lg font-semibold text-outlook-gray-900 mb-4">
            System Information
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-outlook-gray-600">Server Status</span>
              <span className={`text-sm font-medium \\${getHealthColor(systemHealth)}`}>
                {systemHealth.charAt(0).toUpperCase() + systemHealth.slice(1)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-outlook-gray-600">Domain</span>
              <span className="text-sm font-medium text-outlook-gray-900">datainteg.in</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-outlook-gray-600">Mail Server</span>
              <span className="text-sm font-medium text-outlook-gray-900">Active</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-outlook-gray-600">Database</span>
              <span className="text-sm font-medium text-mail-green">Connected</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-outlook-gray-600">Last Backup</span>
              <span className="text-sm font-medium text-outlook-gray-900">
                {new Date().toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-outlook p-6">
        <h3 className="text-lg font-semibold text-outlook-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center p-4 border border-outlook-gray-200 rounded-lg hover:bg-outlook-gray-50 transition-colors">
            <UsersIcon className="h-6 w-6 text-outlook-blue mr-3" />
            <div className="text-left">
              <div className="font-medium text-outlook-gray-900">Add New User</div>
              <div className="text-sm text-outlook-gray-500">Onboard a new employee</div>
            </div>
          </button>
          
          <button className="flex items-center p-4 border border-outlook-gray-200 rounded-lg hover:bg-outlook-gray-50 transition-colors">
            <EnvelopeIcon className="h-6 w-6 text-mail-green mr-3" />
            <div className="text-left">
              <div className="font-medium text-outlook-gray-900">System Broadcast</div>
              <div className="text-sm text-outlook-gray-500">Send message to all users</div>
            </div>
          </button>
          
          <button className="flex items-center p-4 border border-outlook-gray-200 rounded-lg hover:bg-outlook-gray-50 transition-colors">
            <ChartBarIcon className="h-6 w-6 text-mail-purple mr-3" />
            <div className="text-left">
              <div className="font-medium text-outlook-gray-900">Generate Reports</div>
              <div className="text-sm text-outlook-gray-500">Usage and activity reports</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
"""

# Write admin components
with open('DATAINTEG-MAILSERVER/frontend/components/Admin/UserOnboarding.js', 'w') as f:
    f.write(user_onboarding_content)

with open('DATAINTEG-MAILSERVER/frontend/components/Admin/UserManagement.js', 'w') as f:
    f.write(user_management_content)

with open('DATAINTEG-MAILSERVER/frontend/components/Admin/DashboardStats.js', 'w') as f:
    f.write(dashboard_stats_content)

print("✅ Created admin components:")
print("  - Admin/UserOnboarding.js")
print("  - Admin/UserManagement.js")
print("  - Admin/DashboardStats.js")