# SMTP Server Handler
smtp_server_content = """
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import Dict, List, Optional
from flask import current_app
import os

class SMTPServerHandler:
    def __init__(self):
        self.smtp_host = current_app.config.get('MAIL_SERVER', 'smtp.hostinger.com')
        self.smtp_port = current_app.config.get('MAIL_PORT', 587)
        self.smtp_username = current_app.config.get('MAIL_USERNAME')
        self.smtp_password = current_app.config.get('MAIL_PASSWORD')
        self.use_tls = current_app.config.get('MAIL_USE_TLS', True)
        self.use_ssl = current_app.config.get('MAIL_USE_SSL', False)
        self.domain = current_app.config.get('DOMAIN', 'datainteg.in')
    
    def send_email(self, sender: str, recipients: List[str], subject: str, 
                   body: str, html_body: str = None, attachments: List[Dict] = None,
                   cc: List[str] = None, bcc: List[str] = None, 
                   sender_credentials: Dict = None) -> Dict:
        '''Send email via SMTP'''
        try:
            # Use custom credentials or default
            smtp_user = sender_credentials.get('username', self.smtp_username) if sender_credentials else self.smtp_username
            smtp_pass = sender_credentials.get('password', self.smtp_password) if sender_credentials else self.smtp_password
            
            # Create message
            msg = MIMEMultipart('mixed')
            msg['From'] = sender
            msg['To'] = ', '.join(recipients)
            msg['Subject'] = subject
            
            if cc:
                msg['Cc'] = ', '.join(cc)
                recipients.extend(cc)
            
            if bcc:
                recipients.extend(bcc)
            
            # Create message body container
            body_container = MIMEMultipart('alternative')
            
            # Add text body
            if body:
                text_part = MIMEText(body, 'plain', 'utf-8')
                body_container.attach(text_part)
            
            # Add HTML body
            if html_body:
                html_part = MIMEText(html_body, 'html', 'utf-8')
                body_container.attach(html_part)
            
            msg.attach(body_container)
            
            # Add attachments
            if attachments:
                for attachment in attachments:
                    self._add_attachment_to_message(msg, attachment)
            
            # Connect to SMTP server
            if self.use_ssl:
                server = smtplib.SMTP_SSL(self.smtp_host, self.smtp_port)
            else:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
                if self.use_tls:
                    server.starttls()
            
            # Authenticate
            server.login(smtp_user, smtp_pass)
            
            # Send email
            server.sendmail(sender, recipients, msg.as_string())
            server.quit()
            
            logging.info(f"Email sent successfully from {sender} to {len(recipients)} recipients")
            return {
                "success": True,
                "message": "Email sent successfully",
                "recipients_count": len(recipients)
            }
            
        except smtplib.SMTPAuthenticationError as e:
            logging.error(f"SMTP authentication failed: {str(e)}")
            return {"success": False, "error": "SMTP authentication failed"}
        
        except smtplib.SMTPRecipientsRefused as e:
            logging.error(f"SMTP recipients refused: {str(e)}")
            return {"success": False, "error": "One or more recipients were refused"}
        
        except smtplib.SMTPServerDisconnected as e:
            logging.error(f"SMTP server disconnected: {str(e)}")
            return {"success": False, "error": "SMTP server connection lost"}
        
        except Exception as e:
            logging.error(f"SMTP send error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _add_attachment_to_message(self, msg: MIMEMultipart, attachment: Dict):
        '''Add attachment to email message'''
        try:
            file_path = attachment.get('file_path')
            filename = attachment.get('original_filename', attachment.get('filename'))
            
            if not file_path or not os.path.exists(file_path):
                logging.warning(f"Attachment file not found: {file_path}")
                return
            
            with open(file_path, 'rb') as attachment_file:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment_file.read())
            
            # Encode file in ASCII characters to send by email
            encoders.encode_base64(part)
            
            # Add header
            part.add_header(
                'Content-Disposition',
                f'attachment; filename= {filename}'
            )
            
            msg.attach(part)
            logging.info(f"Added attachment: {filename}")
            
        except Exception as e:
            logging.error(f"Error adding attachment {attachment}: {str(e)}")
    
    def test_connection(self, username: str = None, password: str = None) -> Dict:
        '''Test SMTP connection'''
        try:
            test_user = username or self.smtp_username
            test_pass = password or self.smtp_password
            
            if self.use_ssl:
                server = smtplib.SMTP_SSL(self.smtp_host, self.smtp_port, timeout=10)
            else:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=10)
                if self.use_tls:
                    server.starttls()
            
            server.login(test_user, test_pass)
            server.quit()
            
            return {"success": True, "message": "SMTP connection successful"}
            
        except Exception as e:
            logging.error(f"SMTP connection test failed: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def validate_email_address(self, email: str) -> Dict:
        '''Validate email address format and domain'''
        import re
        
        # Basic email regex
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        if not re.match(email_pattern, email):
            return {"valid": False, "error": "Invalid email format"}
        
        # Check if it's a DataInteg domain email
        domain = email.split('@')[1]
        is_internal = domain == self.domain
        
        return {
            "valid": True,
            "domain": domain,
            "is_internal": is_internal
        }
    
    def create_system_email(self, recipient: str, template: str, **kwargs) -> Dict:
        '''Create system email from template'''
        templates = {
            'welcome': {
                'subject': 'Welcome to DataInteg Mail - Your Account is Ready!',
                'body': '''Dear {display_name},

Welcome to DataInteg Mail Server!

Your account has been successfully created:
- Username: {username}
- Email: {email}
- Department: {department}

You can access your email at: https://datainteg.in/mailserver

Best regards,
DataInteg IT Team''',
                'html_body': '''
<html>
<body style="font-family: Arial, sans-serif;">
    <h2 style="color: #2c5282;">Welcome to DataInteg Mail!</h2>
    <p>Dear <strong>{display_name}</strong>,</p>
    <p>Welcome to DataInteg Mail Server! Your account has been successfully created.</p>
    <div style="background-color: #f7fafc; padding: 15px; border-radius: 5px;">
        <h3>Account Details:</h3>
        <ul>
            <li>Username: {username}</li>
            <li>Email: {email}</li>
            <li>Department: {department}</li>
        </ul>
    </div>
    <p>Access your email: <a href="https://datainteg.in/mailserver">https://datainteg.in/mailserver</a></p>
    <p>Best regards,<br><strong>DataInteg IT Team</strong></p>
</body>
</html>'''
            },
            'password_reset': {
                'subject': 'Password Reset Request - DataInteg Mail',
                'body': '''Dear {display_name},

A password reset was requested for your DataInteg Mail account.

If you requested this reset, please click the link below:
{reset_link}

If you did not request this reset, please ignore this email.

Best regards,
DataInteg IT Team''',
                'html_body': '''
<html>
<body style="font-family: Arial, sans-serif;">
    <h2 style="color: #2c5282;">Password Reset Request</h2>
    <p>Dear <strong>{display_name}</strong>,</p>
    <p>A password reset was requested for your DataInteg Mail account.</p>
    <p>If you requested this reset, please click the button below:</p>
    <div style="text-align: center; margin: 20px;">
        <a href="{reset_link}" style="background-color: #2c5282; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a>
    </div>
    <p>If you did not request this reset, please ignore this email.</p>
    <p>Best regards,<br><strong>DataInteg IT Team</strong></p>
</body>
</html>'''
            }
        }
        
        if template not in templates:
            return {"success": False, "error": "Template not found"}
        
        template_data = templates[template]
        
        try:
            subject = template_data['subject'].format(**kwargs)
            body = template_data['body'].format(**kwargs)
            html_body = template_data['html_body'].format(**kwargs)
            
            return {
                "success": True,
                "email_data": {
                    "recipient": recipient,
                    "subject": subject,
                    "body": body,
                    "html_body": html_body
                }
            }
            
        except KeyError as e:
            return {"success": False, "error": f"Missing template variable: {str(e)}"}

# Global SMTP handler instance
smtp_handler = SMTPServerHandler()
"""

# IMAP Server Handler
imap_server_content = """
import imaplib
import email
import logging
from email.header import decode_header
from typing import Dict, List, Optional, Tuple
from flask import current_app
from datetime import datetime, timezone
import re

class IMAPServerHandler:
    def __init__(self):
        self.imap_host = current_app.config.get('IMAP_SERVER', 'imap.hostinger.com')
        self.imap_port = current_app.config.get('IMAP_PORT', 993)
        self.use_ssl = current_app.config.get('IMAP_USE_SSL', True)
        self.domain = current_app.config.get('DOMAIN', 'datainteg.in')
    
    def connect(self, username: str, password: str) -> Tuple[bool, Optional[imaplib.IMAP4_SSL]]:
        '''Connect to IMAP server'''
        try:
            if self.use_ssl:
                mail = imaplib.IMAP4_SSL(self.imap_host, self.imap_port)
            else:
                mail = imaplib.IMAP4(self.imap_host, self.imap_port)
            
            mail.login(username, password)
            logging.info(f"IMAP connection successful for {username}")
            return True, mail
            
        except imaplib.IMAP4.error as e:
            logging.error(f"IMAP authentication failed for {username}: {str(e)}")
            return False, None
        except Exception as e:
            logging.error(f"IMAP connection error: {str(e)}")
            return False, None
    
    def fetch_emails(self, username: str, password: str, folder: str = 'INBOX', 
                     limit: int = 50, search_criteria: str = 'ALL') -> List[Dict]:
        '''Fetch emails from IMAP server'''
        try:
            success, mail = self.connect(username, password)
            if not success or not mail:
                return []
            
            # Select folder
            status, messages = mail.select(folder)
            if status != 'OK':
                logging.error(f"Failed to select folder {folder}")
                mail.logout()
                return []
            
            # Search for emails
            status, email_ids = mail.search(None, search_criteria)
            if status != 'OK':
                logging.error(f"Failed to search emails with criteria: {search_criteria}")
                mail.logout()
                return []
            
            email_ids = email_ids[0].split()
            
            # Fetch recent emails (limited)
            recent_ids = email_ids[-limit:] if len(email_ids) > limit else email_ids
            
            emails = []
            for email_id in reversed(recent_ids):  # Most recent first
                try:
                    email_data = self._fetch_single_email(mail, email_id)
                    if email_data:
                        emails.append(email_data)
                except Exception as e:
                    logging.error(f"Error fetching email {email_id}: {str(e)}")
                    continue
            
            mail.logout()
            logging.info(f"Fetched {len(emails)} emails from {folder} for {username}")
            return emails
            
        except Exception as e:
            logging.error(f"Error fetching emails: {str(e)}")
            return []
    
    def _fetch_single_email(self, mail: imaplib.IMAP4_SSL, email_id: bytes) -> Optional[Dict]:
        '''Fetch and parse a single email'''
        try:
            # Fetch email
            status, msg_data = mail.fetch(email_id, '(RFC822)')
            if status != 'OK':
                return None
            
            # Parse email
            email_body = msg_data[0][1]
            email_message = email.message_from_bytes(email_body)
            
            # Extract basic information
            subject = self._decode_header(email_message.get('Subject', ''))
            sender = self._decode_header(email_message.get('From', ''))
            date_str = email_message.get('Date', '')
            message_id = email_message.get('Message-ID', '')
            to = self._decode_header(email_message.get('To', ''))
            cc = self._decode_header(email_message.get('Cc', ''))
            
            # Parse date
            parsed_date = self._parse_email_date(date_str)
            
            # Extract body and attachments
            body_data = self._extract_body_and_attachments(email_message)
            
            return {
                'subject': subject,
                'sender': sender,
                'recipients': self._parse_addresses(to),
                'cc': self._parse_addresses(cc),
                'body': body_data['text_body'],
                'html_body': body_data['html_body'],
                'attachments': body_data['attachments'],
                'message_id': message_id,
                'date': date_str,
                'parsed_date': parsed_date,
                'created_at': parsed_date or datetime.now(timezone.utc).isoformat(),
                'is_read': False,  # Will be updated based on flags
                'folder': 'INBOX'  # Default folder
            }
            
        except Exception as e:
            logging.error(f"Error parsing email: {str(e)}")
            return None
    
    def _decode_header(self, header: str) -> str:
        '''Decode email header'''
        if not header:
            return ''
        
        try:
            decoded_parts = decode_header(header)
            decoded_string = ''
            
            for text, encoding in decoded_parts:
                if isinstance(text, bytes):
                    decoded_string += text.decode(encoding or 'utf-8', errors='ignore')
                else:
                    decoded_string += str(text)
            
            return decoded_string.strip()
        except Exception:
            return header
    
    def _parse_email_date(self, date_str: str) -> Optional[str]:
        '''Parse email date to ISO format'''
        if not date_str:
            return None
        
        try:
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(date_str)
            return dt.isoformat()
        except Exception:
            return None
    
    def _parse_addresses(self, addresses: str) -> List[str]:
        '''Parse email addresses from header'''
        if not addresses:
            return []
        
        try:
            # Simple parsing - could be improved with email.utils.parseaddr
            addr_list = [addr.strip() for addr in addresses.split(',')]
            return [addr for addr in addr_list if addr]
        except Exception:
            return []
    
    def _extract_body_and_attachments(self, email_message) -> Dict:
        '''Extract email body and attachments'''
        text_body = ''
        html_body = ''
        attachments = []
        
        try:
            if email_message.is_multipart():
                for part in email_message.walk():
                    content_type = part.get_content_type()
                    content_disposition = str(part.get('Content-Disposition', ''))
                    
                    if 'attachment' in content_disposition:
                        # Handle attachment
                        filename = part.get_filename()
                        if filename:
                            decoded_filename = self._decode_header(filename)
                            payload = part.get_payload(decode=True)
                            
                            attachments.append({
                                'filename': decoded_filename,
                                'content_type': content_type,
                                'size': len(payload) if payload else 0,
                                'content_id': part.get('Content-ID', '').strip('<>')
                            })
                    
                    elif content_type == 'text/plain' and 'attachment' not in content_disposition:
                        payload = part.get_payload(decode=True)
                        if payload:
                            text_body = payload.decode('utf-8', errors='ignore')
                    
                    elif content_type == 'text/html' and 'attachment' not in content_disposition:
                        payload = part.get_payload(decode=True)
                        if payload:
                            html_body = payload.decode('utf-8', errors='ignore')
            
            else:
                # Single part message
                payload = email_message.get_payload(decode=True)
                if payload:
                    if email_message.get_content_type() == 'text/html':
                        html_body = payload.decode('utf-8', errors='ignore')
                    else:
                        text_body = payload.decode('utf-8', errors='ignore')
            
        except Exception as e:
            logging.error(f"Error extracting email body: {str(e)}")
        
        return {
            'text_body': text_body,
            'html_body': html_body,
            'attachments': attachments
        }
    
    def get_folder_list(self, username: str, password: str) -> List[str]:
        '''Get list of available folders'''
        try:
            success, mail = self.connect(username, password)
            if not success or not mail:
                return []
            
            status, folders = mail.list()
            if status != 'OK':
                mail.logout()
                return []
            
            folder_names = []
            for folder in folders:
                # Parse folder name from IMAP response
                folder_str = folder.decode('utf-8')
                # Extract folder name (basic parsing)
                parts = folder_str.split('"')
                if len(parts) >= 3:
                    folder_name = parts[-2]
                    folder_names.append(folder_name)
            
            mail.logout()
            return folder_names
            
        except Exception as e:
            logging.error(f"Error getting folder list: {str(e)}")
            return []
    
    def test_connection(self, username: str = None, password: str = None) -> Dict:
        '''Test IMAP connection'''
        try:
            test_user = username or 'test@datainteg.in'
            test_pass = password or 'test_password'
            
            success, mail = self.connect(test_user, test_pass)
            
            if success and mail:
                mail.logout()
                return {"success": True, "message": "IMAP connection successful"}
            else:
                return {"success": False, "error": "IMAP connection failed"}
                
        except Exception as e:
            logging.error(f"IMAP connection test failed: {str(e)}")
            return {"success": False, "error": str(e)}

# Global IMAP handler instance
imap_handler = IMAPServerHandler()
"""

# Write email server files
with open('DATAINTEG-MAILSERVER/backend/email_server/smtp_server.py', 'w') as f:
    f.write(smtp_server_content)

with open('DATAINTEG-MAILSERVER/backend/email_server/imap_server.py', 'w') as f:
    f.write(imap_server_content)

# Mail Handler (Combined functionality)
mail_handler_content = """
from .smtp_server import smtp_handler
from .imap_server import imap_handler
from database.operations import db_ops
from models.email import Email
from utils.file_utils import file_utils
import logging
from typing import Dict, List
from datetime import datetime, timezone

class MailHandler:
    def __init__(self):
        self.smtp = smtp_handler
        self.imap = imap_handler
    
    def send_email_complete(self, sender_user_id: str, email_data: Dict) -> Dict:
        '''Complete email sending process with database storage'''
        try:
            # Get sender user
            sender_user = db_ops.get_user_by_id(sender_user_id)
            if not sender_user:
                return {"success": False, "error": "Sender not found"}
            
            sender_email = f"{sender_user.get('username')}@datainteg.in"
            
            # Send via SMTP
            smtp_result = self.smtp.send_email(
                sender=sender_email,
                recipients=email_data.get('recipients', []),
                subject=email_data.get('subject', ''),
                body=email_data.get('body', ''),
                html_body=email_data.get('html_body'),
                attachments=email_data.get('attachments', []),
                cc=email_data.get('cc', []),
                bcc=email_data.get('bcc', [])
            )
            
            if smtp_result['success']:
                # Save to SENT folder in database
                sent_email_data = Email.create_email_data({
                    'user_id': sender_user_id,
                    'sender': sender_email,
                    'recipients': email_data.get('recipients', []),
                    'cc': email_data.get('cc', []),
                    'bcc': email_data.get('bcc', []),
                    'subject': email_data.get('subject', ''),
                    'body': email_data.get('body', ''),
                    'html_body': email_data.get('html_body'),
                    'folder': 'SENT',
                    'attachments': email_data.get('attachments', []),
                    'is_read': True
                })
                
                db_result = db_ops.create_email(sent_email_data)
                
                return {
                    "success": True,
                    "message": "Email sent and saved successfully",
                    "email_id": db_result.get('email_id')
                }
            else:
                return smtp_result
                
        except Exception as e:
            logging.error(f"Complete email send error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def sync_inbox_from_imap(self, user_id: str, username: str, password: str) -> Dict:
        '''Sync inbox from IMAP server to database'''
        try:
            # Fetch emails from IMAP
            emails = self.imap.fetch_emails(username, password, 'INBOX', limit=100)
            
            synced_count = 0
            for email_data in emails:
                # Check if email already exists
                existing_email = db_ops.get_email_by_message_id(email_data.get('message_id'))
                
                if not existing_email:
                    # Add to database
                    email_data['user_id'] = user_id
                    email_data['folder'] = 'INBOX'
                    
                    db_result = db_ops.create_email(email_data)
                    if db_result['success']:
                        synced_count += 1
            
            return {
                "success": True,
                "message": f"Synced {synced_count} new emails",
                "synced_count": synced_count
            }
            
        except Exception as e:
            logging.error(f"IMAP sync error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def create_and_send_welcome_email(self, user_data: Dict) -> Dict:
        '''Create and send welcome email for new user'''
        try:
            # Create welcome email
            email_template = self.smtp.create_system_email(
                recipient=f"{user_data.get('username')}@datainteg.in",
                template='welcome',
                display_name=user_data.get('display_name'),
                username=user_data.get('username'),
                email=f"{user_data.get('username')}@datainteg.in",
                department=user_data.get('department', 'Not specified')
            )
            
            if not email_template['success']:
                return email_template
            
            # Send email
            send_result = self.smtp.send_email(
                sender='noreply@datainteg.in',
                recipients=[email_template['email_data']['recipient']],
                subject=email_template['email_data']['subject'],
                body=email_template['email_data']['body'],
                html_body=email_template['email_data']['html_body']
            )
            
            # Save to user's inbox
            if send_result['success']:
                inbox_email_data = Email.create_email_data({
                    'user_id': user_data.get('_id'),
                    'sender': 'noreply@datainteg.in',
                    'recipients': [email_template['email_data']['recipient']],
                    'subject': email_template['email_data']['subject'],
                    'body': email_template['email_data']['body'],
                    'html_body': email_template['email_data']['html_body'],
                    'folder': 'INBOX',
                    'is_read': False
                })
                
                db_ops.create_email(inbox_email_data)
            
            return send_result
            
        except Exception as e:
            logging.error(f"Welcome email error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def handle_email_reply(self, user_id: str, original_email_id: str, reply_data: Dict) -> Dict:
        '''Handle email reply with proper threading'''
        try:
            # Get original email
            original_email = db_ops.get_email_by_id(original_email_id)
            if not original_email:
                return {"success": False, "error": "Original email not found"}
            
            # Check access
            if original_email.get('user_id') != user_id:
                return {"success": False, "error": "Access denied"}
            
            # Get sender user
            sender_user = db_ops.get_user_by_id(user_id)
            if not sender_user:
                return {"success": False, "error": "User not found"}
            
            sender_email = f"{sender_user.get('username')}@datainteg.in"
            
            # Prepare reply email data
            reply_subject = f"Re: {original_email.get('subject', '')}"
            if not original_email.get('subject', '').startswith('Re:'):
                reply_subject = f"Re: {original_email.get('subject', '')}"
            else:
                reply_subject = original_email.get('subject', '')
            
            # Add quoted original message
            quoted_message = f"\\n\\n--- Original Message ---\\nFrom: {original_email.get('sender')}\\nSent: {original_email.get('created_at')}\\nSubject: {original_email.get('subject')}\\n\\n{original_email.get('body', '')}"
            
            full_reply_body = reply_data.get('body', '') + quoted_message
            
            # Send reply
            reply_email_data = {
                'recipients': [original_email.get('sender')],
                'subject': reply_subject,
                'body': full_reply_body,
                'html_body': reply_data.get('html_body'),
                'attachments': reply_data.get('attachments', [])
            }
            
            return self.send_email_complete(user_id, reply_email_data)
            
        except Exception as e:
            logging.error(f"Email reply error: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def test_mail_server_health(self) -> Dict:
        '''Test overall mail server health'''
        try:
            results = {
                "smtp": self.smtp.test_connection(),
                "imap": self.imap.test_connection()
            }
            
            overall_health = all(result.get('success', False) for result in results.values())
            
            return {
                "success": overall_health,
                "services": results,
                "status": "healthy" if overall_health else "degraded"
            }
            
        except Exception as e:
            logging.error(f"Mail server health check error: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "status": "unhealthy"
            }

# Global mail handler instance
mail_handler = MailHandler()
"""

with open('DATAINTEG-MAILSERVER/backend/email_server/mail_handler.py', 'w') as f:
    f.write(mail_handler_content)

# Email Server __init__.py
email_server_init_content = """
from .smtp_server import smtp_handler
from .imap_server import imap_handler
from .mail_handler import mail_handler

__all__ = ['smtp_handler', 'imap_handler', 'mail_handler']
"""

with open('DATAINTEG-MAILSERVER/backend/email_server/__init__.py', 'w') as f:
    f.write(email_server_init_content)

print("✅ Created email server modules:")
print("  - smtp_server.py")
print("  - imap_server.py")
print("  - mail_handler.py")
print("  - __init__.py")