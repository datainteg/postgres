# Authentication Utilities
auth_utils_content = """
import jwt
import logging
from datetime import datetime, timezone, timedelta
from functools import wraps
from flask import request, jsonify, current_app
from flask_jwt_extended import decode_token, get_jwt_identity
from models.user import User
from database.operations import db_ops

def generate_jwt_token(user_data: dict, expires_delta: timedelta = None) -> str:
    '''Generate JWT token for user'''
    try:
        if expires_delta is None:
            expires_delta = timedelta(days=30)
        
        payload = {
            'user_id': str(user_data.get('_id')),
            'username': user_data.get('username'),
            'email': user_data.get('email'),
            'roles': user_data.get('roles', ['user']),
            'exp': datetime.now(timezone.utc) + expires_delta,
            'iat': datetime.now(timezone.utc),
            'iss': 'datainteg.in'
        }
        
        secret_key = current_app.config.get('JWT_SECRET_KEY', 'fallback_secret')
        token = jwt.encode(payload, secret_key, algorithm='HS256')
        
        return token
    except Exception as e:
        logging.error(f"Error generating JWT token: {str(e)}")
        return None

def decode_jwt_token(token: str) -> dict:
    '''Decode JWT token'''
    try:
        secret_key = current_app.config.get('JWT_SECRET_KEY', 'fallback_secret')
        payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        logging.error("JWT token has expired")
        return None
    except jwt.InvalidTokenError as e:
        logging.error(f"Invalid JWT token: {str(e)}")
        return None

def authenticate_user(username: str, password: str) -> dict:
    '''Authenticate user with username and password'''
    try:
        # Get user from database
        user_data = db_ops.get_user_by_username(username)
        if not user_data:
            # Try email as username
            user_data = db_ops.get_user_by_email(username)
        
        if not user_data:
            return {"success": False, "error": "User not found"}
        
        # Check if user is active
        if not user_data.get('is_active', True):
            return {"success": False, "error": "Account is deactivated"}
        
        # Verify password
        if not User.verify_password(password, user_data.get('password')):
            return {"success": False, "error": "Invalid credentials"}
        
        # Update last login
        db_ops.update_user(user_data.get('_id'), {'last_login': datetime.now(timezone.utc)})
        
        # Generate token
        token = generate_jwt_token(user_data)
        if not token:
            return {"success": False, "error": "Failed to generate token"}
        
        # Remove password from response
        user_data.pop('password', None)
        
        return {
            "success": True,
            "token": token,
            "user": user_data,
            "message": "Authentication successful"
        }
        
    except Exception as e:
        logging.error(f"Authentication error: {str(e)}")
        return {"success": False, "error": "Authentication failed"}

def require_auth(f):
    '''Decorator to require authentication'''
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None
        
        # Get token from header
        auth_header = request.headers.get('Authorization')
        if auth_header:
            try:
                token = auth_header.split(' ')[1]  # Bearer <token>
            except IndexError:
                return jsonify({'error': 'Invalid authorization header format'}), 401
        
        if not token:
            return jsonify({'error': 'Authorization token is required'}), 401
        
        # Decode token
        payload = decode_jwt_token(token)
        if not payload:
            return jsonify({'error': 'Invalid or expired token'}), 401
        
        # Get current user
        current_user = db_ops.get_user_by_id(payload.get('user_id'))
        if not current_user:
            return jsonify({'error': 'User not found'}), 401
        
        # Check if user is still active
        if not current_user.get('is_active', True):
            return jsonify({'error': 'Account is deactivated'}), 401
        
        # Add current_user to request context
        request.current_user = current_user
        
        return f(*args, **kwargs)
    
    return decorated_function

def require_admin(f):
    '''Decorator to require admin role'''
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # First check authentication
        result = require_auth(f)(*args, **kwargs)
        
        # If authentication failed, return the error
        if hasattr(result, 'status_code') and result.status_code != 200:
            return result
        
        # Check admin role
        current_user = getattr(request, 'current_user', None)
        if not current_user or 'admin' not in current_user.get('roles', []):
            return jsonify({'error': 'Admin privileges required'}), 403
        
        return f(*args, **kwargs)
    
    return decorated_function

def require_role(role: str):
    '''Decorator to require specific role'''
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # First check authentication
            token = None
            auth_header = request.headers.get('Authorization')
            if auth_header:
                try:
                    token = auth_header.split(' ')[1]
                except IndexError:
                    return jsonify({'error': 'Invalid authorization header format'}), 401
            
            if not token:
                return jsonify({'error': 'Authorization token is required'}), 401
            
            payload = decode_jwt_token(token)
            if not payload:
                return jsonify({'error': 'Invalid or expired token'}), 401
            
            current_user = db_ops.get_user_by_id(payload.get('user_id'))
            if not current_user:
                return jsonify({'error': 'User not found'}), 401
            
            # Check role
            if role not in current_user.get('roles', []):
                return jsonify({'error': f'{role.title()} privileges required'}), 403
            
            request.current_user = current_user
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

def get_current_user_from_token() -> dict:
    '''Get current user from JWT token in request'''
    try:
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return None
        
        token = auth_header.split(' ')[1]
        payload = decode_jwt_token(token)
        if not payload:
            return None
        
        return db_ops.get_user_by_id(payload.get('user_id'))
    except Exception:
        return None

def validate_token_for_user(token: str, user_id: str) -> bool:
    '''Validate if token belongs to specific user'''
    try:
        payload = decode_jwt_token(token)
        if not payload:
            return False
        
        return payload.get('user_id') == user_id
    except Exception:
        return False
"""

# Email Utilities
email_utils_content = """
import smtplib
import imaplib
import email
import logging
import mimetypes
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.header import decode_header
from typing import Dict, List, Optional, Tuple
from flask import current_app
import os
from datetime import datetime, timezone

class EmailUtils:
    def __init__(self):
        self.smtp_server = current_app.config.get('MAIL_SERVER', 'smtp.hostinger.com')
        self.smtp_port = current_app.config.get('MAIL_PORT', 587)
        self.smtp_username = current_app.config.get('MAIL_USERNAME')
        self.smtp_password = current_app.config.get('MAIL_PASSWORD')
        self.imap_server = current_app.config.get('IMAP_SERVER', 'imap.hostinger.com')
        self.imap_port = current_app.config.get('IMAP_PORT', 993)
    
    def send_email(self, sender: str, recipients: List[str], subject: str, 
                   body: str, html_body: str = None, attachments: List[Dict] = None,
                   cc: List[str] = None, bcc: List[str] = None) -> Dict:
        '''Send email using SMTP'''
        try:
            # Create message
            msg = MIMEMultipart('alternative')
            msg['From'] = sender
            msg['To'] = ', '.join(recipients)
            msg['Subject'] = subject
            
            if cc:
                msg['Cc'] = ', '.join(cc)
                recipients.extend(cc)
            
            if bcc:
                recipients.extend(bcc)
            
            # Add text body
            if body:
                text_part = MIMEText(body, 'plain', 'utf-8')
                msg.attach(text_part)
            
            # Add HTML body
            if html_body:
                html_part = MIMEText(html_body, 'html', 'utf-8')
                msg.attach(html_part)
            
            # Add attachments
            if attachments:
                for attachment in attachments:
                    self._add_attachment(msg, attachment)
            
            # Connect to SMTP server
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            
            # Use sender's credentials or default
            smtp_user = self.smtp_username
            smtp_pass = self.smtp_password
            
            # If sender has custom credentials, use them
            # This would require storing user SMTP credentials
            
            server.login(smtp_user, smtp_pass)
            
            # Send email
            text = msg.as_string()
            server.sendmail(sender, recipients, text)
            server.quit()
            
            logging.info(f"Email sent successfully from {sender} to {recipients}")
            return {"success": True, "message": "Email sent successfully"}
            
        except Exception as e:
            logging.error(f"Error sending email: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _add_attachment(self, msg: MIMEMultipart, attachment: Dict):
        '''Add attachment to email message'''
        try:
            file_path = attachment.get('file_path')
            filename = attachment.get('filename')
            
            if not os.path.exists(file_path):
                logging.error(f"Attachment file not found: {file_path}")
                return
            
            # Guess content type
            ctype, encoding = mimetypes.guess_type(file_path)
            if ctype is None or encoding is not None:
                ctype = 'application/octet-stream'
            
            maintype, subtype = ctype.split('/', 1)
            
            with open(file_path, 'rb') as fp:
                attachment_part = MIMEBase(maintype, subtype)
                attachment_part.set_payload(fp.read())
                encoders.encode_base64(attachment_part)
                attachment_part.add_header(
                    'Content-Disposition',
                    f'attachment; filename="{filename}"'
                )
                msg.attach(attachment_part)
                
        except Exception as e:
            logging.error(f"Error adding attachment: {str(e)}")
    
    def fetch_emails_imap(self, username: str, password: str, folder: str = 'INBOX', 
                          limit: int = 50) -> List[Dict]:
        '''Fetch emails from IMAP server'''
        try:
            # Connect to IMAP server
            mail = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
            mail.login(username, password)
            
            # Select folder
            mail.select(folder)
            
            # Search for emails
            result, data = mail.search(None, 'ALL')
            email_ids = data[0].split()
            
            emails = []
            # Get recent emails (limit)
            for email_id in email_ids[-limit:]:
                result, msg_data = mail.fetch(email_id, '(RFC822)')
                email_body = msg_data[0][1]
                email_message = email.message_from_bytes(email_body)
                
                # Parse email
                parsed_email = self._parse_email(email_message)
                emails.append(parsed_email)
            
            mail.close()
            mail.logout()
            
            return emails
            
        except Exception as e:
            logging.error(f"Error fetching emails from IMAP: {str(e)}")
            return []
    
    def _parse_email(self, email_message) -> Dict:
        '''Parse email message to dictionary'''
        try:
            subject = self._decode_header(email_message.get('Subject', ''))
            sender = self._decode_header(email_message.get('From', ''))
            date = email_message.get('Date', '')
            message_id = email_message.get('Message-ID', '')
            
            # Get recipients
            to = self._decode_header(email_message.get('To', ''))
            cc = self._decode_header(email_message.get('Cc', ''))
            
            # Get body
            body = ''
            html_body = ''
            attachments = []
            
            if email_message.is_multipart():
                for part in email_message.walk():
                    content_type = part.get_content_type()
                    content_disposition = str(part.get('Content-Disposition', ''))
                    
                    if 'attachment' in content_disposition:
                        # Handle attachment
                        filename = part.get_filename()
                        if filename:
                            attachments.append({
                                'filename': filename,
                                'content_type': content_type,
                                'size': len(part.get_payload(decode=True) or b'')
                            })
                    elif content_type == 'text/plain' and 'attachment' not in content_disposition:
                        body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                    elif content_type == 'text/html' and 'attachment' not in content_disposition:
                        html_body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
            else:
                body = email_message.get_payload(decode=True).decode('utf-8', errors='ignore')
            
            return {
                'subject': subject,
                'sender': sender,
                'recipients': [to] if to else [],
                'cc': [cc] if cc else [],
                'body': body,
                'html_body': html_body,
                'attachments': attachments,
                'message_id': message_id,
                'date': date,
                'created_at': datetime.now(timezone.utc).isoformat()
            }
            
        except Exception as e:
            logging.error(f"Error parsing email: {str(e)}")
            return {}
    
    def _decode_header(self, header: str) -> str:
        '''Decode email header'''
        if not header:
            return ''
        
        try:
            decoded_header = decode_header(header)
            decoded_string = ''
            
            for text, encoding in decoded_header:
                if isinstance(text, bytes):
                    decoded_string += text.decode(encoding or 'utf-8', errors='ignore')
                else:
                    decoded_string += text
            
            return decoded_string
        except Exception:
            return header
    
    def create_welcome_email(self, user_data: Dict) -> Dict:
        '''Create welcome email for new user'''
        subject = f"Welcome to DataInteg Mail - {user_data.get('display_name')}"
        
        body = f\"\"\"
Dear {user_data.get('display_name')},

Welcome to DataInteg Mail Server!

Your account has been successfully created with the following details:

Username: {user_data.get('username')}
Email: {user_data.get('username')}@datainteg.in
Department: {user_data.get('department', 'Not specified')}
Position: {user_data.get('position', 'Not specified')}

You can now access your email account at: https://datainteg.in/mailserver

Best regards,
DataInteg IT Team
\"\"\"

        html_body = f\"\"\"
<html>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #2c5282;">Welcome to DataInteg Mail!</h2>
        
        <p>Dear <strong>{user_data.get('display_name')}</strong>,</p>
        
        <p>Welcome to DataInteg Mail Server! Your account has been successfully created.</p>
        
        <div style="background-color: #f7fafc; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #2c5282;">Account Details:</h3>
            <ul style="list-style-type: none; padding-left: 0;">
                <li><strong>Username:</strong> {user_data.get('username')}</li>
                <li><strong>Email:</strong> {user_data.get('username')}@datainteg.in</li>
                <li><strong>Department:</strong> {user_data.get('department', 'Not specified')}</li>
                <li><strong>Position:</strong> {user_data.get('position', 'Not specified')}</li>
            </ul>
        </div>
        
        <p>You can access your email account at: <a href="https://datainteg.in/mailserver" style="color: #2c5282;">https://datainteg.in/mailserver</a></p>
        
        <p>Best regards,<br>
        <strong>DataInteg IT Team</strong></p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin-top: 30px;">
        <p style="font-size: 12px; color: #718096;">
            This is an automated message. Please do not reply to this email.
        </p>
    </div>
</body>
</html>
\"\"\"

        return {
            'subject': subject,
            'body': body,
            'html_body': html_body,
            'sender': 'noreply@datainteg.in',
            'recipients': [f"{user_data.get('username')}@datainteg.in"]
        }

# Global instance
email_utils = EmailUtils()
"""

# Write utility files
with open('DATAINTEG-MAILSERVER/backend/utils/auth_utils.py', 'w') as f:
    f.write(auth_utils_content)

with open('DATAINTEG-MAILSERVER/backend/utils/email_utils.py', 'w') as f:
    f.write(email_utils_content)

print("✅ Created utility files:")
print("  - auth_utils.py")  
print("  - email_utils.py")