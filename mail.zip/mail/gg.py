# User Model
user_model_content = """
from datetime import datetime, timezone
from typing import Dict, List, Optional
import bcrypt
from bson import ObjectId

class User:
    def __init__(self, data: Dict = None):
        if data:
            self._id = data.get('_id')
            self.username = data.get('username')
            self.email = data.get('email')
            self.password = data.get('password')
            self.first_name = data.get('first_name', '')
            self.last_name = data.get('last_name', '')
            self.display_name = data.get('display_name', f"{self.first_name} {self.last_name}".strip())
            self.roles = data.get('roles', ['user'])
            self.is_active = data.get('is_active', True)
            self.employee_id = data.get('employee_id')
            self.department = data.get('department')
            self.position = data.get('position')
            self.phone_number = data.get('phone_number')
            self.joining_date = data.get('joining_date')
            self.reporting_manager = data.get('reporting_manager')
            self.work_location = data.get('work_location')
            self.emergency_contact = data.get('emergency_contact', {})
            self.mail_settings = data.get('mail_settings', {})
            self.created_at = data.get('created_at', datetime.now(timezone.utc))
            self.updated_at = data.get('updated_at', datetime.now(timezone.utc))
            self.last_login = data.get('last_login')
    
    @staticmethod
    def hash_password(password: str) -> str:
        '''Hash password using bcrypt'''
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    @staticmethod
    def verify_password(password: str, hashed_password: str) -> bool:
        '''Verify password against hash'''
        try:
            return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
        except Exception:
            return False
    
    def to_dict(self, include_password: bool = False) -> Dict:
        '''Convert user object to dictionary'''
        data = {
            '_id': str(self._id) if self._id else None,
            'username': self.username,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'display_name': self.display_name,
            'roles': self.roles,
            'is_active': self.is_active,
            'employee_id': self.employee_id,
            'department': self.department,
            'position': self.position,
            'phone_number': self.phone_number,
            'joining_date': self.joining_date,
            'reporting_manager': self.reporting_manager,
            'work_location': self.work_location,
            'emergency_contact': self.emergency_contact,
            'mail_settings': self.mail_settings,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
        
        if include_password:
            data['password'] = self.password
        
        return data
    
    def has_role(self, role: str) -> bool:
        '''Check if user has specific role'''
        return role in self.roles
    
    def is_admin(self) -> bool:
        '''Check if user is admin'''
        return self.has_role('admin')
    
    def get_full_email(self) -> str:
        '''Get full email address with domain'''
        return f"{self.username}@datainteg.in"
    
    @classmethod
    def create_user_data(cls, user_input: Dict) -> Dict:
        '''Create user data dictionary for database insertion'''
        user_data = {
            'username': user_input.get('username'),
            'email': user_input.get('email', f"{user_input.get('username')}@datainteg.in"),
            'password': cls.hash_password(user_input.get('password')),
            'first_name': user_input.get('first_name', ''),
            'last_name': user_input.get('last_name', ''),
            'display_name': user_input.get('display_name', f"{user_input.get('first_name', '')} {user_input.get('last_name', '')}".strip()),
            'roles': user_input.get('roles', ['user']),
            'is_active': user_input.get('is_active', True),
            'employee_id': user_input.get('employee_id'),
            'department': user_input.get('department'),
            'position': user_input.get('position'),
            'phone_number': user_input.get('phone_number'),
            'joining_date': user_input.get('joining_date'),
            'reporting_manager': user_input.get('reporting_manager'),
            'work_location': user_input.get('work_location'),
            'emergency_contact': {
                'name': user_input.get('emergency_contact_name'),
                'phone': user_input.get('emergency_contact_phone'),
                'relation': user_input.get('emergency_contact_relation')
            },
            'mail_settings': {
                'signature': user_input.get('email_signature', f"Best regards,\\n{user_input.get('first_name', '')} {user_input.get('last_name', '')}\\n{user_input.get('position', '')}\\nDataInteg Solutions"),
                'auto_reply': False,
                'forwarding_enabled': False,
                'timezone': user_input.get('timezone', 'Asia/Kolkata')
            }
        }
        
        return user_data
"""

# Email Model
email_model_content = """
from datetime import datetime, timezone
from typing import Dict, List, Optional
from bson import ObjectId

class Email:
    def __init__(self, data: Dict = None):
        if data:
            self._id = data.get('_id')
            self.user_id = data.get('user_id')
            self.sender = data.get('sender')
            self.recipients = data.get('recipients', [])
            self.cc = data.get('cc', [])
            self.bcc = data.get('bcc', [])
            self.subject = data.get('subject', '')
            self.body = data.get('body', '')
            self.html_body = data.get('html_body')
            self.folder = data.get('folder', 'INBOX')
            self.is_read = data.get('is_read', False)
            self.is_starred = data.get('is_starred', False)
            self.is_important = data.get('is_important', False)
            self.thread_id = data.get('thread_id')
            self.in_reply_to = data.get('in_reply_to')
            self.message_id = data.get('message_id')
            self.attachments = data.get('attachments', [])
            self.labels = data.get('labels', [])
            self.created_at = data.get('created_at', datetime.now(timezone.utc))
            self.updated_at = data.get('updated_at', datetime.now(timezone.utc))
            self.read_at = data.get('read_at')
            self.sent_at = data.get('sent_at')
    
    def to_dict(self) -> Dict:
        '''Convert email object to dictionary'''
        return {
            '_id': str(self._id) if self._id else None,
            'user_id': str(self.user_id) if self.user_id else None,
            'sender': self.sender,
            'recipients': self.recipients,
            'cc': self.cc,
            'bcc': self.bcc,
            'subject': self.subject,
            'body': self.body,
            'html_body': self.html_body,
            'folder': self.folder,
            'is_read': self.is_read,
            'is_starred': self.is_starred,
            'is_important': self.is_important,
            'thread_id': self.thread_id,
            'in_reply_to': self.in_reply_to,
            'message_id': self.message_id,
            'attachments': self.attachments,
            'labels': self.labels,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'read_at': self.read_at.isoformat() if self.read_at else None,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None
        }
    
    def mark_as_read(self):
        '''Mark email as read'''
        self.is_read = True
        self.read_at = datetime.now(timezone.utc)
        self.updated_at = datetime.now(timezone.utc)
    
    def add_attachment(self, attachment_data: Dict):
        '''Add attachment to email'''
        if not self.attachments:
            self.attachments = []
        self.attachments.append(attachment_data)
        self.updated_at = datetime.now(timezone.utc)
    
    def get_preview_text(self, length: int = 150) -> str:
        '''Get preview text of email body'''
        if self.body:
            # Remove HTML tags if present
            import re
            text = re.sub('<[^<]+?>', '', self.body)
            return text[:length] + ('...' if len(text) > length else '')
        return ''
    
    @classmethod
    def create_email_data(cls, email_input: Dict) -> Dict:
        '''Create email data dictionary for database insertion'''
        import uuid
        
        email_data = {
            'user_id': ObjectId(email_input.get('user_id')),
            'sender': email_input.get('sender'),
            'recipients': email_input.get('recipients', []),
            'cc': email_input.get('cc', []),
            'bcc': email_input.get('bcc', []),
            'subject': email_input.get('subject', ''),
            'body': email_input.get('body', ''),
            'html_body': email_input.get('html_body'),
            'folder': email_input.get('folder', 'INBOX'),
            'is_read': email_input.get('is_read', False),
            'is_starred': email_input.get('is_starred', False),
            'is_important': email_input.get('is_important', False),
            'message_id': email_input.get('message_id', f"<{uuid.uuid4()}@datainteg.in>"),
            'attachments': email_input.get('attachments', []),
            'labels': email_input.get('labels', []),
            'sent_at': datetime.now(timezone.utc) if email_input.get('folder') == 'SENT' else None
        }
        
        return email_data
"""

# Attachment Model
attachment_model_content = """
from datetime import datetime, timezone
from typing import Dict, Optional
from bson import ObjectId
import os
import mimetypes

class Attachment:
    def __init__(self, data: Dict = None):
        if data:
            self._id = data.get('_id')
            self.email_id = data.get('email_id')
            self.filename = data.get('filename')
            self.original_filename = data.get('original_filename')
            self.file_path = data.get('file_path')
            self.file_size = data.get('file_size')
            self.mime_type = data.get('mime_type')
            self.content_id = data.get('content_id')
            self.is_inline = data.get('is_inline', False)
            self.created_at = data.get('created_at', datetime.now(timezone.utc))
    
    def to_dict(self) -> Dict:
        '''Convert attachment object to dictionary'''
        return {
            '_id': str(self._id) if self._id else None,
            'email_id': str(self.email_id) if self.email_id else None,
            'filename': self.filename,
            'original_filename': self.original_filename,
            'file_path': self.file_path,
            'file_size': self.file_size,
            'mime_type': self.mime_type,
            'content_id': self.content_id,
            'is_inline': self.is_inline,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def get_size_formatted(self) -> str:
        '''Get formatted file size'''
        if not self.file_size:
            return '0 B'
        
        size = self.file_size
        units = ['B', 'KB', 'MB', 'GB']
        unit_index = 0
        
        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1
        
        return f"{size:.1f} {units[unit_index]}"
    
    def is_image(self) -> bool:
        '''Check if attachment is an image'''
        if self.mime_type:
            return self.mime_type.startswith('image/')
        return False
    
    def is_document(self) -> bool:
        '''Check if attachment is a document'''
        document_types = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/plain'
        ]
        return self.mime_type in document_types
    
    @classmethod
    def create_attachment_data(cls, file_data: Dict, email_id: str) -> Dict:
        '''Create attachment data dictionary for database insertion'''
        import uuid
        
        # Generate unique filename
        file_extension = os.path.splitext(file_data.get('filename', ''))[1]
        unique_filename = f"{uuid.uuid4()}{file_extension}"
        
        # Detect MIME type
        mime_type, _ = mimetypes.guess_type(file_data.get('filename', ''))
        
        attachment_data = {
            'email_id': ObjectId(email_id),
            'filename': unique_filename,
            'original_filename': file_data.get('filename'),
            'file_path': file_data.get('file_path'),
            'file_size': file_data.get('file_size'),
            'mime_type': mime_type or 'application/octet-stream',
            'content_id': file_data.get('content_id'),
            'is_inline': file_data.get('is_inline', False)
        }
        
        return attachment_data
"""

# Folder/Mailbox Model
folder_model_content = """
from datetime import datetime, timezone
from typing import Dict, List, Optional
from bson import ObjectId

class Folder:
    def __init__(self, data: Dict = None):
        if data:
            self._id = data.get('_id')
            self.user_id = data.get('user_id')
            self.name = data.get('name')
            self.display_name = data.get('display_name')
            self.parent_folder = data.get('parent_folder')
            self.count = data.get('count', 0)
            self.unread_count = data.get('unread_count', 0)
            self.is_system = data.get('is_system', False)
            self.color = data.get('color')
            self.created_at = data.get('created_at', datetime.now(timezone.utc))
            self.updated_at = data.get('updated_at', datetime.now(timezone.utc))
    
    def to_dict(self) -> Dict:
        '''Convert folder object to dictionary'''
        return {
            '_id': str(self._id) if self._id else None,
            'user_id': str(self.user_id) if self.user_id else None,
            'name': self.name,
            'display_name': self.display_name,
            'parent_folder': self.parent_folder,
            'count': self.count,
            'unread_count': self.unread_count,
            'is_system': self.is_system,
            'color': self.color,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def increment_count(self, unread: bool = False):
        '''Increment folder count'''
        self.count += 1
        if unread:
            self.unread_count += 1
        self.updated_at = datetime.now(timezone.utc)
    
    def decrement_count(self, was_unread: bool = False):
        '''Decrement folder count'''
        if self.count > 0:
            self.count -= 1
        if was_unread and self.unread_count > 0:
            self.unread_count -= 1
        self.updated_at = datetime.now(timezone.utc)
    
    @classmethod
    def get_system_folders(cls) -> List[Dict]:
        '''Get system folder definitions'''
        return [
            {
                'name': 'INBOX',
                'display_name': 'Inbox',
                'is_system': True,
                'color': '#1f77b4'
            },
            {
                'name': 'SENT',
                'display_name': 'Sent',
                'is_system': True,
                'color': '#2ca02c'
            },
            {
                'name': 'DRAFTS',
                'display_name': 'Drafts',
                'is_system': True,
                'color': '#ff7f0e'
            },
            {
                'name': 'SPAM',
                'display_name': 'Spam',
                'is_system': True,
                'color': '#d62728'
            },
            {
                'name': 'TRASH',
                'display_name': 'Trash',
                'is_system': True,
                'color': '#8c564b'
            }
        ]
"""

# Domain Model
domain_model_content = """
from datetime import datetime, timezone
from typing import Dict, Optional

class Domain:
    def __init__(self, data: Dict = None):
        if data:
            self._id = data.get('_id')
            self.domain = data.get('domain')
            self.is_active = data.get('is_active', True)
            self.mx_records = data.get('mx_records', [])
            self.spf_record = data.get('spf_record')
            self.dkim_record = data.get('dkim_record')
            self.dmarc_record = data.get('dmarc_record')
            self.created_at = data.get('created_at', datetime.now(timezone.utc))
            self.updated_at = data.get('updated_at', datetime.now(timezone.utc))
    
    def to_dict(self) -> Dict:
        '''Convert domain object to dictionary'''
        return {
            '_id': str(self._id) if self._id else None,
            'domain': self.domain,
            'is_active': self.is_active,
            'mx_records': self.mx_records,
            'spf_record': self.spf_record,
            'dkim_record': self.dkim_record,
            'dmarc_record': self.dmarc_record,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def create_datainteg_domain(cls) -> Dict:
        '''Create DataInteg domain configuration'''
        return {
            'domain': 'datainteg.in',
            'is_active': True,
            'mx_records': [
                {'priority': 10, 'server': 'mail.datainteg.in'},
                {'priority': 20, 'server': 'mail2.datainteg.in'}
            ],
            'spf_record': 'v=spf1 include:spf.hostinger.com ~all',
            'dkim_record': 'v=DKIM1; k=rsa; p=...',  # Your actual DKIM key
            'dmarc_record': 'v=DMARC1; p=none; rua=mailto:dmarc@datainteg.in'
        }
"""

# Write model files
with open('DATAINTEG-MAILSERVER/backend/models/user.py', 'w') as f:
    f.write(user_model_content)

with open('DATAINTEG-MAILSERVER/backend/models/email.py', 'w') as f:
    f.write(email_model_content)

with open('DATAINTEG-MAILSERVER/backend/models/attachment.py', 'w') as f:
    f.write(attachment_model_content)

with open('DATAINTEG-MAILSERVER/backend/models/folder.py', 'w') as f:
    f.write(folder_model_content)

with open('DATAINTEG-MAILSERVER/backend/models/domain.py', 'w') as f:
    f.write(domain_model_content)

# Mailbox Model (combining functionality)
mailbox_model_content = """
from datetime import datetime, timezone
from typing import Dict, List, Optional
from bson import ObjectId
from models.folder import Folder
from models.email import Email

class Mailbox:
    def __init__(self, user_id: str):
        self.user_id = ObjectId(user_id)
        self.folders = []
        self.total_emails = 0
        self.unread_emails = 0
    
    def get_folder_stats(self) -> Dict:
        '''Get mailbox statistics'''
        return {
            'user_id': str(self.user_id),
            'total_folders': len(self.folders),
            'total_emails': self.total_emails,
            'unread_emails': self.unread_emails,
            'folders': [folder.to_dict() for folder in self.folders]
        }
    
    def create_custom_folder(self, name: str, display_name: str, color: str = None) -> Dict:
        '''Create a custom folder'''
        folder_data = {
            'user_id': self.user_id,
            'name': name.upper().replace(' ', '_'),
            'display_name': display_name,
            'is_system': False,
            'color': color or '#9467bd'
        }
        
        return Folder.create_folder_data(folder_data)
"""

with open('DATAINTEG-MAILSERVER/backend/models/mailbox.py', 'w') as f:
    f.write(mailbox_model_content)

# Models __init__.py
models_init_content = """
from .user import User
from .email import Email
from .attachment import Attachment
from .folder import Folder
from .domain import Domain
from .mailbox import Mailbox

__all__ = ['User', 'Email', 'Attachment', 'Folder', 'Domain', 'Mailbox']
"""

with open('DATAINTEG-MAILSERVER/backend/models/__init__.py', 'w') as f:
    f.write(models_init_content)

print("✅ Created model files:")
print("  - user.py")
print("  - email.py")
print("  - attachment.py")
print("  - folder.py")
print("  - domain.py")
print("  - mailbox.py")
print("  - __init__.py")