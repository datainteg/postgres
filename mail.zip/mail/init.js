// MongoDB initialization script
db = db.getSiblingDB('datainteg_mail');

// Create collections
db.createCollection('users');
db.createCollection('emails');
db.createCollection('mailboxes');
db.createCollection('attachments');
db.createCollection('domains');

// Create indexes
db.users.createIndex({ "username": 1 }, { unique: true });
db.users.createIndex({ "email": 1 }, { unique: true });
db.users.createIndex({ "employee_id": 1 }, { unique: true, sparse: true });
db.users.createIndex({ "roles": 1 });

db.emails.createIndex({ "user_id": 1, "folder": 1 });
db.emails.createIndex({ "user_id": 1, "created_at": -1 });
db.emails.createIndex({ "sender": 1 });
db.emails.createIndex({ "recipients": 1 });
db.emails.createIndex({ "subject": "text", "body": "text" });

db.mailboxes.createIndex({ "user_id": 1, "name": 1 }, { unique: true });

db.attachments.createIndex({ "email_id": 1 });

// Insert default domain
db.domains.insertOne({
    "domain": "datainteg.in",
    "is_active": true,
    "mx_records": [
        { "priority": 10, "server": "mail.datainteg.in" }
    ],
    "spf_record": "v=spf1 include:spf.hostinger.com ~all",
    "created_at": new Date()
});

// Create default admin user
db.users.insertOne({
    "username": "admin",
    "email": "admin@datainteg.in",
    "password": "$2b$12$LKF.HhO0qNjJZZ5V8V8KSeOKfS8vK8nO0.5P0bG0/vW8b9I4P1.8.", // Welcome@911
    "first_name": "System",
    "last_name": "Administrator",
    "display_name": "System Administrator",
    "roles": ["admin", "user"],
    "is_active": true,
    "employee_id": "ADMIN001",
    "department": "IT",
    "position": "System Administrator",
    "created_at": new Date(),
    "updated_at": new Date(),
    "mail_settings": {
        "signature": "Best regards,\nSystem Administrator\nDataInteg Solutions",
        "auto_reply": false,
        "forwarding_enabled": false
    }
});

print("Database initialized successfully!");
