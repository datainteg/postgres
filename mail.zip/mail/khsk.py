# Global CSS
globals_css_content = """@tailwind base;
@tailwind components;
@tailwind utilities;

/* Custom Outlook-inspired styles */
@layer base {
  html {
    font-family: 'Segoe UI', system-ui, sans-serif;
  }
  
  body {
    @apply bg-outlook-gray-50 text-outlook-gray-900;
  }
}

@layer components {
  /* Button styles */
  .btn-primary {
    @apply bg-outlook-blue text-white px-4 py-2 rounded-md hover:bg-outlook-darkblue transition-colors font-medium;
  }
  
  .btn-secondary {
    @apply bg-outlook-gray-200 text-outlook-gray-700 px-4 py-2 rounded-md hover:bg-outlook-gray-300 transition-colors font-medium;
  }
  
  .btn-danger {
    @apply bg-mail-red text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors font-medium;
  }
  
  /* Input styles */
  .input-primary {
    @apply w-full px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent;
  }
  
  /* Card styles */
  .card {
    @apply bg-white rounded-lg shadow-outlook;
  }
  
  .card-header {
    @apply p-4 border-b border-outlook-gray-200;
  }
  
  .card-body {
    @apply p-4;
  }
  
  /* Outlook-specific components */
  .outlook-sidebar {
    @apply w-64 bg-white border-r border-outlook-gray-200 flex flex-col;
  }
  
  .outlook-main {
    @apply flex-1 bg-white border-r border-outlook-gray-200;
  }
  
  .outlook-viewer {
    @apply flex-1 bg-white;
  }
  
  /* Email list styles */
  .email-item {
    @apply p-3 border-b border-outlook-gray-100 hover:bg-outlook-gray-50 cursor-pointer transition-colors;
  }
  
  .email-item.selected {
    @apply bg-outlook-lightblue border-r-2 border-outlook-blue;
  }
  
  .email-item.unread {
    @apply bg-white;
  }
  
  .email-item.read {
    @apply bg-outlook-gray-25;
  }
  
  /* Status indicators */
  .status-online {
    @apply bg-mail-green;
  }
  
  .status-offline {
    @apply bg-outlook-gray-400;
  }
  
  .status-away {
    @apply bg-mail-orange;
  }
  
  .status-busy {
    @apply bg-mail-red;
  }
  
  /* Loading states */
  .loading-spinner {
    @apply animate-spin-slow w-4 h-4 border-2 border-outlook-blue border-t-transparent rounded-full;
  }
  
  .loading-dots {
    @apply inline-flex space-x-1;
  }
  
  .loading-dots span {
    @apply w-1 h-1 bg-outlook-blue rounded-full animate-pulse;
    animation-delay: calc(var(--i) * 0.1s);
  }
}

@layer utilities {
  /* Custom utilities */
  .scrollbar-thin {
    scrollbar-width: thin;
    scrollbar-color: rgb(203 213 225) rgb(241 245 249);
  }
  
  .scrollbar-thin::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-track {
    background: rgb(241 245 249);
    border-radius: 3px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: rgb(203 213 225);
    border-radius: 3px;
  }
  
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: rgb(148 163 184);
  }
  
  /* Hide scrollbar but keep functionality */
  .scrollbar-none {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
  
  .scrollbar-none::-webkit-scrollbar {
    display: none;
  }
  
  /* Text truncation utilities */
  .truncate-2-lines {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  
  .truncate-3-lines {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  
  /* Outlook-specific animations */
  .fade-in-up {
    animation: fadeInUp 0.3s ease-out;
  }
  
  .slide-in-right {
    animation: slideInRight 0.3s ease-out;
  }
  
  .scale-in {
    animation: scaleIn 0.2s ease-out;
  }
}

/* Custom animations */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(20px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes scaleIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

/* Dark mode styles (optional) */
@media (prefers-color-scheme: dark) {
  .dark-mode {
    @apply bg-outlook-gray-900 text-outlook-gray-100;
  }
  
  .dark-mode .card {
    @apply bg-outlook-gray-800 border-outlook-gray-700;
  }
  
  .dark-mode .input-primary {
    @apply bg-outlook-gray-800 border-outlook-gray-600 text-outlook-gray-100;
  }
}

/* Print styles */
@media print {
  .no-print {
    display: none !important;
  }
  
  .print-break-before {
    page-break-before: always;
  }
  
  .print-break-after {
    page-break-after: always;
  }
}

/* Mobile responsive adjustments */
@media (max-width: 768px) {
  .outlook-sidebar {
    @apply w-full;
  }
  
  .outlook-main {
    @apply border-r-0;
  }
  
  .mobile-stack {
    @apply flex-col;
  }
}

/* High contrast mode support */
@media (prefers-contrast: high) {
  .input-primary {
    @apply border-2 border-black;
  }
  
  .btn-primary {
    @apply border-2 border-black;
  }
}

/* Reduced motion support */
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}

/* Focus styles for accessibility */
.focus-visible:focus {
  @apply outline-none ring-2 ring-outlook-blue ring-offset-2;
}

/* Custom selection */
::selection {
  @apply bg-outlook-blue text-white;
}

/* Placeholder styling */
::placeholder {
  @apply text-outlook-gray-500;
}
"""

# Frontend Dockerfile
frontend_dockerfile_content = """FROM node:18-alpine

WORKDIR /app

# Install dependencies
COPY package.json package-lock.json* ./
RUN npm ci --only=production

# Copy source code
COPY . .

# Build the application
RUN npm run build

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:3000 || exit 1

# Start the application
CMD ["npm", "start"]
"""

# README.md
readme_content = """# DataInteg Mail Server

A professional, secure email server solution built with Flask (Python) backend and Next.js frontend, designed specifically for DataInteg business communications.

## 🚀 Features

### Core Mail Features
- **Professional Email Interface**: Outlook-inspired design for familiar user experience
- **Real-time Email Management**: Send, receive, organize emails with folders
- **Rich Text Composition**: HTML email support with file attachments (25MB max)
- **Advanced Search**: Search across subjects, content, and senders
- **Email Threading**: Reply and forward with proper email threading
- **Attachment Handling**: Support for multiple file types with preview

### User Management
- **Role-based Authentication**: Admin and user roles with JWT tokens
- **User Onboarding**: Streamlined process for adding new employees
- **Profile Management**: Update personal information and preferences
- **Department Organization**: Group users by departments and positions

### Admin Features
- **Dashboard Analytics**: User statistics and system health monitoring
- **User Management**: Create, edit, deactivate user accounts
- **System Monitoring**: Real-time system health and performance metrics
- **Bulk Operations**: Manage multiple users simultaneously

### Security & Infrastructure
- **JWT Authentication**: Secure token-based authentication (30-day expiry)
- **Password Security**: bcrypt hashing with strong password requirements
- **HTTPS/SSL Support**: Production-ready SSL certificate configuration
- **Rate Limiting**: Protection against brute force attacks
- **Input Validation**: Comprehensive server-side validation

## 🏗️ Architecture

### Backend (Python Flask)
- **Framework**: Flask with Blueprint organization
- **Database**: MongoDB with optimized indexes
- **Email Server**: SMTP/IMAP integration (Hostinger compatible)
- **Authentication**: JWT with refresh token support
- **File Storage**: Local file system with organized structure
- **API Design**: RESTful endpoints with comprehensive error handling

### Frontend (Next.js React)
- **Framework**: Next.js 14 with TypeScript support
- **Styling**: Tailwind CSS with Outlook-inspired theme
- **State Management**: React hooks with local storage
- **Components**: Modular, reusable components
- **Responsive Design**: Mobile-first responsive layout

## 📦 Installation & Deployment

### Prerequisites
- Docker & Docker Compose
- Node.js 18+
- Python 3.11+
- MongoDB 7.0+

### Quick Start with Docker

1. **Clone and Setup**
   ```bash
   git clone <repository-url>
   cd DATAINTEG-MAILSERVER
   cp .env.example .env
   # Edit .env with your configuration
   ```

2. **Configure Environment**
   ```bash
   # Update .env file with:
   MAIL_PASSWORD=your_hostinger_email_password
   JWT_SECRET=your-jwt-secret-key
   MONGODB_ROOT_PASSWORD=DataInteg@2025
   ```

3. **Deploy with Docker**
   ```bash
   # Make deploy script executable
   chmod +x deployment/deploy.sh
   
   # Run deployment
   ./deployment/deploy.sh
   ```

4. **Setup SSL (Production)**
   ```bash
   ./deployment/ssl-setup.sh
   ```

### Manual Installation

#### Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

#### Frontend Setup
```bash
cd frontend
npm install
npm run build
npm start
```

## 🔧 Configuration

### Environment Variables

#### Backend (.env)
```env
FLASK_ENV=production
MONGO_URI=mongodb://admin:DataInteg@2025@localhost:27017/datainteg_mail?authSource=admin
MAIL_SERVER=smtp.hostinger.com
MAIL_USERNAME=noreply@datainteg.in
MAIL_PASSWORD=your_password
DOMAIN=datainteg.in
JWT_SECRET=your-jwt-secret
```

#### Frontend (.env.local)
```env
NEXT_PUBLIC_API_URL=https://datainteg.in/api
NEXT_PUBLIC_DOMAIN=datainteg.in
```

### Domain Setup

1. **DNS Configuration**
   ```
   A     datainteg.in          -> Your_Server_IP
   CNAME www.datainteg.in      -> datainteg.in
   MX    datainteg.in          -> mail.datainteg.in (Priority: 10)
   ```

2. **Email Records**
   ```
   TXT   datainteg.in          -> "v=spf1 include:spf.hostinger.com ~all"
   TXT   _dmarc.datainteg.in   -> "v=DMARC1; p=none; rua=mailto:dmarc@datainteg.in"
   ```

## 👥 User Roles & Permissions

### Admin Users
- **Full System Access**: Manage all users and system settings
- **User Management**: Create, edit, deactivate user accounts
- **System Monitoring**: Access to analytics and health metrics
- **Email Access**: Full email functionality plus administrative tools

### Standard Users
- **Email Management**: Send, receive, organize emails
- **Profile Updates**: Manage personal information and settings
- **Search & Filter**: Advanced email search and organization
- **File Attachments**: Upload and manage email attachments

## 📧 Email Server Integration

### SMTP Configuration (Hostinger)
- **Server**: smtp.hostinger.com
- **Port**: 587 (STARTTLS)
- **Authentication**: Username/Password
- **Security**: TLS encryption

### IMAP Configuration (Optional)
- **Server**: imap.hostinger.com
- **Port**: 993 (SSL)
- **Folders**: INBOX, SENT, DRAFTS, SPAM, TRASH

## 🔒 Security Features

### Authentication
- **JWT Tokens**: 30-day access tokens with automatic refresh
- **Password Policy**: Minimum 8 characters with complexity requirements
- **Session Management**: Secure cookie handling with HttpOnly flags
- **Brute Force Protection**: Rate limiting on login attempts

### Data Protection
- **Input Validation**: Comprehensive server-side validation
- **SQL Injection Prevention**: MongoDB with parameterized queries
- **XSS Protection**: HTML sanitization for email content
- **File Upload Security**: Type validation and size limits

## 📊 Monitoring & Analytics

### System Health
- **API Health Checks**: Automated endpoint monitoring
- **Database Connectivity**: Real-time connection status
- **Email Server Status**: SMTP/IMAP health monitoring
- **Performance Metrics**: Response times and error rates

### User Analytics
- **Active Users**: Real-time active user tracking
- **Department Statistics**: User distribution by department
- **Email Activity**: Send/receive volume tracking
- **Login Analytics**: Authentication success/failure rates

## 🚀 Production Deployment

### Server Requirements
- **CPU**: 2+ cores recommended
- **RAM**: 4GB+ recommended
- **Storage**: 50GB+ for emails and attachments
- **Network**: Stable internet with static IP

### SSL Certificate Setup
```bash
# Using Let's Encrypt (Recommended)
sudo certbot certonly --standalone -d datainteg.in -d www.datainteg.in

# Using custom certificate
cp your-certificate.crt deployment/ssl/datainteg.in.crt
cp your-private-key.key deployment/ssl/datainteg.in.key
```

### Nginx Configuration
The included nginx.conf provides:
- **SSL Termination**: HTTPS redirect and certificate handling
- **Load Balancing**: Backend API load balancing
- **Static Files**: Optimized static asset serving
- **Security Headers**: HSTS, XSS protection, content security policy

## 🔄 Backup & Recovery

### Database Backup
```bash
# Create backup
docker exec datainteg_mongodb mongodump --authenticationDatabase=admin -u admin -p DataInteg@2025 --out /backup

# Restore backup
docker exec datainteg_mongodb mongorestore --authenticationDatabase=admin -u admin -p DataInteg@2025 /backup
```

### File System Backup
```bash
# Backup user uploads and attachments
tar -czf backup-$(date +%Y%m%d).tar.gz backend/uploads
```

## 🐛 Troubleshooting

### Common Issues

**Authentication Failures**
- Check JWT_SECRET consistency between services
- Verify MongoDB connection and user credentials
- Confirm email server (SMTP) credentials

**Email Delivery Issues**
- Verify DNS MX records are properly configured
- Check SMTP server credentials and settings
- Confirm firewall allows outbound port 587/25

**Database Connection**
- Ensure MongoDB service is running
- Verify connection string format
- Check network connectivity between services

**Performance Issues**
- Monitor database indexes and query performance
- Check disk space for uploads and logs
- Review Nginx access logs for bottlenecks

### Logs & Debugging
```bash
# View application logs
docker logs datainteg_backend
docker logs datainteg_frontend

# Database logs
docker logs datainteg_mongodb

# Nginx logs
docker logs datainteg_nginx
```

## 📝 API Documentation

### Authentication Endpoints
```
POST /api/auth/login          # User login
POST /api/auth/logout         # User logout
GET  /api/auth/verify         # Token verification
PUT  /api/auth/change-password # Change password
```

### Mail Endpoints
```
POST /api/mail/send           # Send email
GET  /api/mail/folders/{folder}/emails # Get emails
GET  /api/mail/emails/{id}    # Get specific email
PUT  /api/mail/emails/{id}/read # Mark as read
```

### Admin Endpoints
```
GET  /api/admin/users         # List all users
POST /api/admin/users         # Create user
PUT  /api/admin/users/{id}    # Update user
DELETE /api/admin/users/{id}  # Deactivate user
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes with tests
4. Submit a pull request

## 📄 License

Copyright © 2025 DataInteg Solutions. All rights reserved.

## 📞 Support

For technical support or questions:
- **Email**: support@datainteg.in
- **Documentation**: https://docs.datainteg.in
- **Issues**: Create an issue in the repository

---

**DataInteg Mail Server** - Professional email communication for modern businesses.
"""

# .dockerignore
dockerignore_content = """# Dependencies
node_modules/
__pycache__/
*.pyc
venv/
env/

# Build outputs
.next/
dist/
build/

# Environment files
.env
.env.local
.env.production

# Logs
*.log
logs/

# OS generated files
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# IDE files
.vscode/
.idea/
*.swp
*.swo

# Git
.git/
.gitignore

# Documentation
README.md
docs/

# Test files
__tests__/
*.test.js
*.spec.js

# Development files
*.dev.js
"""

# Write final files
with open('DATAINTEG-MAILSERVER/frontend/styles/globals.css', 'w') as f:
    f.write(globals_css_content)

with open('DATAINTEG-MAILSERVER/frontend/Dockerfile', 'w') as f:
    f.write(frontend_dockerfile_content)

with open('DATAINTEG-MAILSERVER/README.md', 'w') as f:
    f.write(readme_content)

with open('DATAINTEG-MAILSERVER/.dockerignore', 'w') as f:
    f.write(dockerignore_content)

# Create empty __init__.py files for Python packages
with open('DATAINTEG-MAILSERVER/backend/__init__.py', 'w') as f:
    f.write("")

# Create empty uploads directory and add .gitkeep
os.makedirs('DATAINTEG-MAILSERVER/backend/uploads', exist_ok=True)
with open('DATAINTEG-MAILSERVER/backend/uploads/.gitkeep', 'w') as f:
    f.write("")

print("✅ Created final project files:")
print("  - frontend/styles/globals.css")
print("  - frontend/Dockerfile")
print("  - README.md")
print("  - .dockerignore")
print("  - backend/__init__.py")
print("  - backend/uploads/.gitkeep")
print("")
print("🎉 DATAINTEG MAIL SERVER PROJECT COMPLETED!")
print("")
print("📂 Project Structure Overview:")
print("├── backend/                 # Python Flask API")
print("│   ├── api/                # REST API endpoints")
print("│   ├── database/           # MongoDB operations")
print("│   ├── models/             # Data models")
print("│   ├── utils/              # Utility functions")
print("│   ├── email_server/       # SMTP/IMAP handlers")
print("│   └── uploads/            # File storage")
print("├── frontend/               # Next.js React app")
print("│   ├── pages/              # Application pages")
print("│   ├── components/         # React components")
print("│   └── styles/             # CSS styling")
print("├── deployment/             # Docker & deployment")
print("└── docker-compose.yml      # Container orchestration")

print("")
print("🚀 Quick Start:")
print("1. cd DATAINTEG-MAILSERVER")
print("2. Update .env with your credentials")
print("3. chmod +x deployment/deploy.sh")  
print("4. ./deployment/deploy.sh")
print("5. Access: https://datainteg.in/mailserver")
print("")
print("👤 Default Admin Login:")
print("   Username: admin")
print("   Password: Welcome@911")