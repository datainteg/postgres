# Mail Routes
mail_routes_content = """
from flask import Blueprint, request, jsonify, current_app
from utils.auth_utils import require_auth
from utils.email_utils import email_utils
from utils.file_utils import file_utils
from utils.validation_utils import validation_utils
from models.email import Email
from models.attachment import Attachment
from database.operations import db_ops
import logging
from datetime import datetime, timezone

mail_bp = Blueprint('mail', __name__)

@mail_bp.route('/send', methods=['POST'])
@require_auth
def send_email():
    '''Send email'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Validate email data
        validation_result = validation_utils.validate_email_content(data)
        if not validation_result['valid']:
            return jsonify({"error": "Validation failed", "details": validation_result['errors']}), 400
        
        # Prepare email data
        sender = f"{current_user.get('username')}@datainteg.in"
        recipients = data.get('recipients', [])
        cc = data.get('cc', [])
        bcc = data.get('bcc', [])
        subject = data.get('subject', '')
        body = data.get('body', '')
        html_body = data.get('html_body')
        attachments = data.get('attachments', [])
        
        # Send email via SMTP
        send_result = email_utils.send_email(
            sender=sender,
            recipients=recipients,
            subject=subject,
            body=body,
            html_body=html_body,
            attachments=attachments,
            cc=cc,
            bcc=bcc
        )
        
        if send_result['success']:
            # Save to SENT folder in database
            email_data = Email.create_email_data({
                'user_id': current_user['_id'],
                'sender': sender,
                'recipients': recipients,
                'cc': cc,
                'bcc': bcc,
                'subject': subject,
                'body': body,
                'html_body': html_body,
                'folder': 'SENT',
                'attachments': attachments,
                'is_read': True  # Sent emails are considered read
            })
            
            # Save email to database
            db_result = db_ops.create_email(email_data)
            
            logging.info(f"Email sent by {current_user.get('username')} to {recipients}")
            
            return jsonify({
                "success": True,
                "message": "Email sent successfully",
                "data": {
                    "email_id": db_result.get('email_id'),
                    "sent_at": datetime.now(timezone.utc).isoformat()
                }
            }), 200
        else:
            return jsonify({
                "success": False,
                "error": f"Failed to send email: {send_result.get('error')}"
            }), 500
        
    except Exception as e:
        logging.error(f"Send email error: {str(e)}")
        return jsonify({"error": "Failed to send email"}), 500

@mail_bp.route('/folders/<folder>/emails', methods=['GET'])
@require_auth
def get_emails_by_folder(folder):
    '''Get emails in a specific folder'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        # Get pagination parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 50))
        skip = (page - 1) * limit
        
        # Get search parameter
        search = request.args.get('search', '').strip()
        
        emails = db_ops.get_emails_by_user_and_folder(
            user_id=current_user['_id'],
            folder=folder.upper(),
            skip=skip,
            limit=limit
        )
        
        # Apply search filter if provided
        if search:
            filtered_emails = []
            for email in emails:
                if (search.lower() in email.get('subject', '').lower() or
                    search.lower() in email.get('body', '').lower() or
                    search.lower() in email.get('sender', '').lower()):
                    filtered_emails.append(email)
            emails = filtered_emails
        
        # Add preview text and format dates
        for email in emails:
            email['preview'] = Email({'body': email.get('body', '')}).get_preview_text()
            if email.get('created_at'):
                email['formatted_date'] = email['created_at']
        
        return jsonify({
            "success": True,
            "data": {
                "emails": emails,
                "folder": folder,
                "pagination": {
                    "page": page,
                    "limit": limit,
                    "total": len(emails)
                }
            }
        }), 200
        
    except Exception as e:
        logging.error(f"Get emails by folder error: {str(e)}")
        return jsonify({"error": "Failed to retrieve emails"}), 500

@mail_bp.route('/emails/<email_id>', methods=['GET'])
@require_auth
def get_email(email_id):
    '''Get specific email'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        email = db_ops.get_email_by_id(email_id)
        
        if not email:
            return jsonify({"error": "Email not found"}), 404
        
        # Check if email belongs to current user
        if email.get('user_id') != current_user['_id']:
            return jsonify({"error": "Access denied"}), 403
        
        # Mark email as read if it's not already
        if not email.get('is_read', False):
            db_ops.mark_email_as_read(email_id, current_user['_id'])
            email['is_read'] = True
            email['read_at'] = datetime.now(timezone.utc).isoformat()
        
        # Get attachments
        attachments = db_ops.get_email_attachments(email_id)
        email['attachments'] = attachments
        
        return jsonify({
            "success": True,
            "data": email
        }), 200
        
    except Exception as e:
        logging.error(f"Get email error: {str(e)}")
        return jsonify({"error": "Failed to retrieve email"}), 500

@mail_bp.route('/emails/<email_id>/read', methods=['PUT'])
@require_auth
def mark_email_read(email_id):
    '''Mark email as read'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        success = db_ops.mark_email_as_read(email_id, current_user['_id'])
        
        if success:
            return jsonify({
                "success": True,
                "message": "Email marked as read"
            }), 200
        else:
            return jsonify({"error": "Failed to mark email as read"}), 500
        
    except Exception as e:
        logging.error(f"Mark email read error: {str(e)}")
        return jsonify({"error": "Failed to mark email as read"}), 500

@mail_bp.route('/emails/<email_id>/move', methods=['PUT'])
@require_auth
def move_email(email_id):
    '''Move email to different folder'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data or not data.get('folder'):
            return jsonify({"error": "Target folder is required"}), 400
        
        folder = data.get('folder').upper()
        valid_folders = ['INBOX', 'SENT', 'DRAFTS', 'SPAM', 'TRASH']
        
        if folder not in valid_folders:
            return jsonify({"error": "Invalid folder"}), 400
        
        success = db_ops.move_email_to_folder(email_id, folder, current_user['_id'])
        
        if success:
            return jsonify({
                "success": True,
                "message": f"Email moved to {folder}"
            }), 200
        else:
            return jsonify({"error": "Failed to move email"}), 500
        
    except Exception as e:
        logging.error(f"Move email error: {str(e)}")
        return jsonify({"error": "Failed to move email"}), 500

@mail_bp.route('/emails/<email_id>/reply', methods=['POST'])
@require_auth
def reply_to_email(email_id):
    '''Reply to an email'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Get original email
        original_email = db_ops.get_email_by_id(email_id)
        if not original_email:
            return jsonify({"error": "Original email not found"}), 404
        
        # Check access
        if original_email.get('user_id') != current_user['_id']:
            return jsonify({"error": "Access denied"}), 403
        
        # Prepare reply
        reply_body = data.get('body', '')
        reply_html = data.get('html_body')
        
        # Add original email to reply
        original_body = f"\\n\\n--- Original Message ---\\nFrom: {original_email.get('sender')}\\nSubject: {original_email.get('subject')}\\n\\n{original_email.get('body', '')}"
        
        sender = f"{current_user.get('username')}@datainteg.in"
        recipient = original_email.get('sender')
        subject = f"Re: {original_email.get('subject', '')}"
        
        # Send reply
        send_result = email_utils.send_email(
            sender=sender,
            recipients=[recipient],
            subject=subject,
            body=reply_body + original_body,
            html_body=reply_html
        )
        
        if send_result['success']:
            # Save to SENT folder
            reply_data = Email.create_email_data({
                'user_id': current_user['_id'],
                'sender': sender,
                'recipients': [recipient],
                'subject': subject,
                'body': reply_body + original_body,
                'html_body': reply_html,
                'folder': 'SENT',
                'in_reply_to': email_id,
                'is_read': True
            })
            
            db_ops.create_email(reply_data)
            
            return jsonify({
                "success": True,
                "message": "Reply sent successfully"
            }), 200
        else:
            return jsonify({
                "success": False,
                "error": f"Failed to send reply: {send_result.get('error')}"
            }), 500
        
    except Exception as e:
        logging.error(f"Reply to email error: {str(e)}")
        return jsonify({"error": "Failed to send reply"}), 500

@mail_bp.route('/upload-attachment', methods=['POST'])
@require_auth
def upload_attachment():
    '''Upload attachment for email'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        if 'file' not in request.files:
            return jsonify({"error": "No file provided"}), 400
        
        file = request.files['file']
        email_id = request.form.get('email_id')  # Optional
        
        # Save file
        save_result = file_utils.save_uploaded_file(file, email_id)
        
        if save_result['success']:
            file_info = save_result['file_info']
            
            # If email_id provided, save attachment metadata
            if email_id:
                attachment_data = Attachment.create_attachment_data(file_info, email_id)
                db_ops.save_attachment(attachment_data)
            
            return jsonify({
                "success": True,
                "message": "File uploaded successfully",
                "data": {
                    "filename": file_info['filename'],
                    "original_filename": file_info['original_filename'],
                    "file_size": file_info['file_size'],
                    "mime_type": file_info['mime_type']
                }
            }), 200
        else:
            return jsonify({
                "success": False,
                "error": save_result['error']
            }), 400
        
    except Exception as e:
        logging.error(f"Upload attachment error: {str(e)}")
        return jsonify({"error": "Failed to upload attachment"}), 500

@mail_bp.route('/folders', methods=['GET'])
@require_auth
def get_folders():
    '''Get user's mail folders'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        folders = db_ops.get_user_mailboxes(current_user['_id'])
        
        return jsonify({
            "success": True,
            "data": folders
        }), 200
        
    except Exception as e:
        logging.error(f"Get folders error: {str(e)}")
        return jsonify({"error": "Failed to retrieve folders"}), 500

@mail_bp.route('/search', methods=['GET'])
@require_auth
def search_emails():
    '''Search emails'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        query = request.args.get('q', '').strip()
        folder = request.args.get('folder', '').upper()
        
        if not query:
            return jsonify({"error": "Search query is required"}), 400
        
        # For now, search in all folders or specific folder
        if folder:
            emails = db_ops.get_emails_by_user_and_folder(current_user['_id'], folder, limit=100)
        else:
            # Search in all folders - would need database aggregation for better performance
            all_emails = []
            for folder_name in ['INBOX', 'SENT', 'DRAFTS']:
                folder_emails = db_ops.get_emails_by_user_and_folder(current_user['_id'], folder_name, limit=50)
                all_emails.extend(folder_emails)
            emails = all_emails
        
        # Filter by search query
        search_results = []
        for email in emails:
            if (query.lower() in email.get('subject', '').lower() or
                query.lower() in email.get('body', '').lower() or
                query.lower() in email.get('sender', '').lower()):
                
                email['preview'] = Email({'body': email.get('body', '')}).get_preview_text()
                search_results.append(email)
        
        return jsonify({
            "success": True,
            "data": {
                "results": search_results,
                "query": query,
                "total": len(search_results)
            }
        }), 200
        
    except Exception as e:
        logging.error(f"Search emails error: {str(e)}")
        return jsonify({"error": "Failed to search emails"}), 500

@mail_bp.route('/health', methods=['GET'])
@require_auth
def mail_health():
    '''Mail service health check'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        return jsonify({
            "status": "healthy",
            "service": "mail",
            "user": current_user.get('username'),
            "endpoints": [
                "POST /api/mail/send",
                "GET /api/mail/folders/<folder>/emails",
                "GET /api/mail/emails/<id>",
                "PUT /api/mail/emails/<id>/read",
                "PUT /api/mail/emails/<id>/move",
                "POST /api/mail/emails/<id>/reply",
                "POST /api/mail/upload-attachment",
                "GET /api/mail/folders",
                "GET /api/mail/search"
            ]
        }), 200
        
    except Exception as e:
        return jsonify({"status": "unhealthy", "error": str(e)}), 500
"""

# User Routes
user_routes_content = """
from flask import Blueprint, request, jsonify, current_app
from utils.auth_utils import require_auth
from utils.validation_utils import validation_utils
from database.operations import db_ops
import logging

user_bp = Blueprint('user', __name__)

@user_bp.route('/profile', methods=['GET'])
@require_auth
def get_user_profile():
    '''Get current user profile'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        # Remove sensitive information
        profile = {k: v for k, v in current_user.items() if k != 'password'}
        
        return jsonify({
            "success": True,
            "data": profile
        }), 200
        
    except Exception as e:
        logging.error(f"Get user profile error: {str(e)}")
        return jsonify({"error": "Failed to get profile"}), 500

@user_bp.route('/profile', methods=['PUT'])
@require_auth
def update_user_profile():
    '''Update current user profile'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Fields that regular users can update
        user_updatable_fields = [
            'first_name', 'last_name', 'phone_number', 'emergency_contact',
            'mail_settings'
        ]
        
        update_data = {}
        for field in user_updatable_fields:
            if field in data:
                if field == 'phone_number' and data[field]:
                    phone_validation = validation_utils.validate_phone(data[field])
                    if not phone_validation['valid']:
                        return jsonify({"error": phone_validation['error']}), 400
                    update_data[field] = phone_validation.get('normalized', data[field])
                else:
                    update_data[field] = data[field]
        
        # Update display name if first or last name changed
        if 'first_name' in update_data or 'last_name' in update_data:
            first_name = update_data.get('first_name', current_user.get('first_name', ''))
            last_name = update_data.get('last_name', current_user.get('last_name', ''))
            update_data['display_name'] = f"{first_name} {last_name}".strip()
        
        if not update_data:
            return jsonify({"error": "No valid fields to update"}), 400
        
        success = db_ops.update_user(current_user['_id'], update_data)
        
        if success:
            # Get updated user data
            updated_user = db_ops.get_user_by_id(current_user['_id'])
            updated_user.pop('password', None)
            
            logging.info(f"Profile updated for user: {current_user.get('username')}")
            
            return jsonify({
                "success": True,
                "message": "Profile updated successfully",
                "data": updated_user
            }), 200
        else:
            return jsonify({"error": "Failed to update profile"}), 500
        
    except Exception as e:
        logging.error(f"Update user profile error: {str(e)}")
        return jsonify({"error": "Profile update failed"}), 500

@user_bp.route('/settings', methods=['GET'])
@require_auth
def get_user_settings():
    '''Get current user settings'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        settings = {
            'mail_settings': current_user.get('mail_settings', {}),
            'timezone': current_user.get('timezone', 'Asia/Kolkata'),
            'language': current_user.get('language', 'en'),
            'notifications': current_user.get('notifications', {})
        }
        
        return jsonify({
            "success": True,
            "data": settings
        }), 200
        
    except Exception as e:
        logging.error(f"Get user settings error: {str(e)}")
        return jsonify({"error": "Failed to get settings"}), 500

@user_bp.route('/settings', methods=['PUT'])
@require_auth
def update_user_settings():
    '''Update current user settings'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        update_data = {}
        
        # Update mail settings
        if 'mail_settings' in data:
            current_mail_settings = current_user.get('mail_settings', {})
            new_mail_settings = data['mail_settings']
            
            # Merge settings
            current_mail_settings.update(new_mail_settings)
            update_data['mail_settings'] = current_mail_settings
        
        # Update other settings
        if 'timezone' in data:
            update_data['timezone'] = data['timezone']
        
        if 'language' in data:
            update_data['language'] = data['language']
        
        if 'notifications' in data:
            update_data['notifications'] = data['notifications']
        
        if not update_data:
            return jsonify({"error": "No valid settings to update"}), 400
        
        success = db_ops.update_user(current_user['_id'], update_data)
        
        if success:
            logging.info(f"Settings updated for user: {current_user.get('username')}")
            
            return jsonify({
                "success": True,
                "message": "Settings updated successfully"
            }), 200
        else:
            return jsonify({"error": "Failed to update settings"}), 500
        
    except Exception as e:
        logging.error(f"Update user settings error: {str(e)}")
        return jsonify({"error": "Settings update failed"}), 500

@user_bp.route('/mailboxes', methods=['GET'])
@require_auth
def get_user_mailboxes():
    '''Get current user's mailboxes/folders'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        mailboxes = db_ops.get_user_mailboxes(current_user['_id'])
        
        # Add email counts for each mailbox
        for mailbox in mailboxes:
            folder_name = mailbox.get('name')
            if folder_name:
                emails = db_ops.get_emails_by_user_and_folder(
                    current_user['_id'], 
                    folder_name, 
                    limit=1000  # Get all for counting
                )
                mailbox['count'] = len(emails)
                mailbox['unread_count'] = len([e for e in emails if not e.get('is_read', False)])
        
        return jsonify({
            "success": True,
            "data": mailboxes
        }), 200
        
    except Exception as e:
        logging.error(f"Get user mailboxes error: {str(e)}")
        return jsonify({"error": "Failed to get mailboxes"}), 500

@user_bp.route('/stats', methods=['GET'])
@require_auth
def get_user_stats():
    '''Get current user's mail statistics'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        # Get emails from different folders
        inbox_emails = db_ops.get_emails_by_user_and_folder(current_user['_id'], 'INBOX', limit=1000)
        sent_emails = db_ops.get_emails_by_user_and_folder(current_user['_id'], 'SENT', limit=1000)
        draft_emails = db_ops.get_emails_by_user_and_folder(current_user['_id'], 'DRAFTS', limit=1000)
        
        # Calculate statistics
        total_emails = len(inbox_emails) + len(sent_emails) + len(draft_emails)
        unread_emails = len([e for e in inbox_emails if not e.get('is_read', False)])
        
        # Get recent activity (last 7 days)
        from datetime import datetime, timedelta
        week_ago = datetime.now() - timedelta(days=7)
        
        recent_received = []
        recent_sent = []
        
        for email in inbox_emails:
            if email.get('created_at'):
                try:
                    email_date = datetime.fromisoformat(email['created_at'].replace('Z', '+00:00'))
                    if email_date > week_ago:
                        recent_received.append(email)
                except:
                    continue
        
        for email in sent_emails:
            if email.get('created_at'):
                try:
                    email_date = datetime.fromisoformat(email['created_at'].replace('Z', '+00:00'))
                    if email_date > week_ago:
                        recent_sent.append(email)
                except:
                    continue
        
        stats = {
            "emails": {
                "total": total_emails,
                "inbox": len(inbox_emails),
                "sent": len(sent_emails),
                "drafts": len(draft_emails),
                "unread": unread_emails
            },
            "activity": {
                "recent_received": len(recent_received),
                "recent_sent": len(recent_sent)
            },
            "account": {
                "created": current_user.get('created_at'),
                "last_login": current_user.get('last_login')
            }
        }
        
        return jsonify({
            "success": True,
            "data": stats
        }), 200
        
    except Exception as e:
        logging.error(f"Get user stats error: {str(e)}")
        return jsonify({"error": "Failed to get statistics"}), 500

@user_bp.route('/health', methods=['GET'])
@require_auth
def user_health():
    '''User service health check'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        return jsonify({
            "status": "healthy",
            "service": "user",
            "user": current_user.get('username'),
            "endpoints": [
                "GET /api/user/profile",
                "PUT /api/user/profile",
                "GET /api/user/settings",
                "PUT /api/user/settings",
                "GET /api/user/mailboxes",
                "GET /api/user/stats"
            ]
        }), 200
        
    except Exception as e:
        return jsonify({"status": "unhealthy", "error": str(e)}), 500
"""

# API __init__.py
api_init_content = """
from .auth_routes import auth_bp
from .admin_routes import admin_bp
from .mail_routes import mail_bp
from .user_routes import user_bp

__all__ = ['auth_bp', 'admin_routes', 'mail_bp', 'user_bp']
"""

# Write API route files
with open('DATAINTEG-MAILSERVER/backend/api/mail_routes.py', 'w') as f:
    f.write(mail_routes_content)

with open('DATAINTEG-MAILSERVER/backend/api/user_routes.py', 'w') as f:
    f.write(user_routes_content)

with open('DATAINTEG-MAILSERVER/backend/api/__init__.py', 'w') as f:
    f.write(api_init_content)

# API Utils
api_utils_content = """
from flask import jsonify
import logging
from datetime import datetime, timezone

def success_response(data=None, message="Success", status_code=200):
    '''Create standardized success response'''
    response = {
        "success": True,
        "message": message,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    if data is not None:
        response["data"] = data
    
    return jsonify(response), status_code

def error_response(error="An error occurred", status_code=500, details=None):
    '''Create standardized error response'''
    response = {
        "success": False,
        "error": error,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    if details:
        response["details"] = details
    
    logging.error(f"API Error: {error} (Status: {status_code})")
    
    return jsonify(response), status_code

def paginate_response(data, page, limit, total_count=None):
    '''Create paginated response'''
    if total_count is None:
        total_count = len(data)
    
    return {
        "data": data,
        "pagination": {
            "page": page,
            "limit": limit,
            "total": total_count,
            "has_next": len(data) == limit,
            "has_prev": page > 1
        }
    }

def validate_json_request(required_fields=None):
    '''Decorator to validate JSON request'''
    def decorator(func):
        from functools import wraps
        from flask import request
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not request.is_json:
                return error_response("Content-Type must be application/json", 400)
            
            data = request.get_json()
            if not data:
                return error_response("No JSON data provided", 400)
            
            if required_fields:
                missing_fields = [field for field in required_fields if field not in data]
                if missing_fields:
                    return error_response(
                        f"Missing required fields: {', '.join(missing_fields)}", 
                        400
                    )
            
            return func(*args, **kwargs)
        
        return wrapper
    return decorator
"""

with open('DATAINTEG-MAILSERVER/backend/api/utils.py', 'w') as f:
    f.write(api_utils_content)

print("✅ Created remaining API files:")
print("  - mail_routes.py")
print("  - user_routes.py")
print("  - utils.py")
print("  - __init__.py")