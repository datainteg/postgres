# OutlookLayout Component
outlook_layout_content = """import { useState } from 'react';
import {
  Bars3Icon,
  UserCircleIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
} from '@heroicons/react/24/outline';

export default function OutlookLayout({ children, user, onLogout }) {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <div className="h-screen flex flex-col bg-outlook-gray-50">
      {/* Top Navigation Bar */}
      <header className="bg-outlook-blue text-white shadow-outlook">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center">
            <div className="flex items-center space-x-3">
              <svg className="h-8 w-8" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
              </svg>
              <div>
                <h1 className="text-lg font-semibold">DataInteg Mail</h1>
                <p className="text-xs text-outlook-lightblue">{user?.email}</p>
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-xl mx-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Search mail and people"
                className="w-full px-4 py-1.5 pr-10 text-outlook-gray-900 bg-white border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <svg className="h-4 w-4 text-outlook-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-outlook-darkblue transition-colors"
            >
              <UserCircleIcon className="h-6 w-6" />
              <span className="text-sm hidden md:block">{user?.display_name}</span>
            </button>

            {/* Dropdown Menu */}
            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-outlook-hover py-1 z-50">
                <div className="px-4 py-2 border-b border-outlook-gray-200">
                  <p className="text-sm font-medium text-outlook-gray-900">{user?.display_name}</p>
                  <p className="text-xs text-outlook-gray-600">{user?.email}</p>
                  <p className="text-xs text-outlook-blue">{user?.roles?.join(', ')}</p>
                </div>
                
                <a
                  href="#"
                  className="flex items-center px-4 py-2 text-sm text-outlook-gray-700 hover:bg-outlook-gray-100"
                  onClick={() => setShowUserMenu(false)}
                >
                  <UserCircleIcon className="mr-3 h-4 w-4" />
                  My Profile
                </a>
                
                <a
                  href="#"
                  className="flex items-center px-4 py-2 text-sm text-outlook-gray-700 hover:bg-outlook-gray-100"
                  onClick={() => setShowUserMenu(false)}
                >
                  <Cog6ToothIcon className="mr-3 h-4 w-4" />
                  Settings
                </a>
                
                {user?.roles?.includes('admin') && (
                  <a
                    href="/admin"
                    className="flex items-center px-4 py-2 text-sm text-outlook-gray-700 hover:bg-outlook-gray-100"
                    onClick={() => setShowUserMenu(false)}
                  >
                    <Bars3Icon className="mr-3 h-4 w-4" />
                    Admin Panel
                  </a>
                )}
                
                <div className="border-t border-outlook-gray-200 mt-1">
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      onLogout();
                    }}
                    className="flex items-center w-full px-4 py-2 text-sm text-mail-red hover:bg-outlook-gray-100"
                  >
                    <ArrowRightOnRectangleIcon className="mr-3 h-4 w-4" />
                    Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Quick Action Bar */}
        <div className="border-t border-outlook-darkblue">
          <div className="flex items-center px-4 py-1">
            <div className="flex items-center space-x-1">
              <button className="px-2 py-1 text-xs text-outlook-lightblue hover:text-white hover:bg-outlook-darkblue rounded">
                New
              </button>
              <button className="px-2 py-1 text-xs text-outlook-lightblue hover:text-white hover:bg-outlook-darkblue rounded">
                Delete
              </button>
              <button className="px-2 py-1 text-xs text-outlook-lightblue hover:text-white hover:bg-outlook-darkblue rounded">
                Archive
              </button>
              <button className="px-2 py-1 text-xs text-outlook-lightblue hover:text-white hover:bg-outlook-darkblue rounded">
                Move
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        {children}
      </main>

      {/* Click outside handler */}
      {showUserMenu && (
        <div 
          className="fixed inset-0 z-40"
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </div>
  );
}
"""

# AdminLayout Component
admin_layout_content = """import { useState } from 'react';
import {
  UserCircleIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
  HomeIcon,
} from '@heroicons/react/24/outline';

export default function AdminLayout({ children, user, onLogout }) {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <div className="h-screen flex flex-col bg-outlook-gray-50">
      {/* Admin Top Bar */}
      <header className="bg-mail-purple text-white shadow-outlook">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center">
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-semibold">DataInteg Admin</h1>
                <p className="text-xs text-purple-200">System Administration</p>
              </div>
            </div>
          </div>

          {/* Admin Tools */}
          <div className="flex items-center space-x-4">
            <div className="text-sm text-purple-200">
              System Status: <span className="text-mail-green font-medium">Healthy</span>
            </div>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-purple-700 transition-colors"
              >
                <UserCircleIcon className="h-6 w-6" />
                <span className="text-sm hidden md:block">{user?.display_name}</span>
              </button>

              {/* Dropdown Menu */}
              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-outlook-hover py-1 z-50">
                  <div className="px-4 py-2 border-b border-outlook-gray-200">
                    <p className="text-sm font-medium text-outlook-gray-900">{user?.display_name}</p>
                    <p className="text-xs text-outlook-gray-600">{user?.email}</p>
                    <p className="text-xs text-mail-purple font-medium">Administrator</p>
                  </div>
                  
                  <a
                    href="#"
                    className="flex items-center px-4 py-2 text-sm text-outlook-gray-700 hover:bg-outlook-gray-100"
                    onClick={() => setShowUserMenu(false)}
                  >
                    <UserCircleIcon className="mr-3 h-4 w-4" />
                    Admin Profile
                  </a>
                  
                  <a
                    href="#"
                    className="flex items-center px-4 py-2 text-sm text-outlook-gray-700 hover:bg-outlook-gray-100"
                    onClick={() => setShowUserMenu(false)}
                  >
                    <Cog6ToothIcon className="mr-3 h-4 w-4" />
                    System Settings
                  </a>
                  
                  <a
                    href="/mail"
                    className="flex items-center px-4 py-2 text-sm text-outlook-gray-700 hover:bg-outlook-gray-100"
                    onClick={() => setShowUserMenu(false)}
                  >
                    <HomeIcon className="mr-3 h-4 w-4" />
                    Go to Mail
                  </a>
                  
                  <div className="border-t border-outlook-gray-200 mt-1">
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onLogout();
                      }}
                      className="flex items-center w-full px-4 py-2 text-sm text-mail-red hover:bg-outlook-gray-100"
                    >
                      <ArrowRightOnRectangleIcon className="mr-3 h-4 w-4" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        {children}
      </main>

      {/* Click outside handler */}
      {showUserMenu && (
        <div 
          className="fixed inset-0 z-40"
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </div>
  );
}
"""

# Sidebar Component (Mail)
sidebar_content = """import { useState } from 'react';
import {
  PlusIcon,
  InboxIcon,
  PaperAirplaneIcon,
  DocumentIcon,
  TrashIcon,
  ExclamationTriangleIcon,
  ArrowPathIcon,
} from '@heroicons/react/24/outline';

export default function Sidebar({ 
  user, 
  folders, 
  selectedFolder, 
  onFolderSelect, 
  onCompose, 
  onRefresh 
}) {
  const [refreshing, setRefreshing] = useState(false);

  const defaultFolders = [
    {
      name: 'INBOX',
      display_name: 'Inbox',
      icon: InboxIcon,
      count: 0,
      unread_count: 0,
    },
    {
      name: 'SENT',
      display_name: 'Sent Items',
      icon: PaperAirplaneIcon,
      count: 0,
    },
    {
      name: 'DRAFTS',
      display_name: 'Drafts',
      icon: DocumentIcon,
      count: 0,
    },
    {
      name: 'SPAM',
      display_name: 'Junk Email',
      icon: ExclamationTriangleIcon,
      count: 0,
    },
    {
      name: 'TRASH',
      display_name: 'Deleted Items',
      icon: TrashIcon,
      count: 0,
    },
  ];

  const handleRefresh = async () => {
    setRefreshing(true);
    await onRefresh();
    setTimeout(() => setRefreshing(false), 1000);
  };

  const folderList = folders.length > 0 ? folders : defaultFolders;

  return (
    <div className="w-64 bg-white border-r border-outlook-gray-200 flex flex-col">
      {/* Compose Button */}
      <div className="p-4 border-b border-outlook-gray-200">
        <button
          onClick={onCompose}
          className="w-full flex items-center justify-center px-4 py-2 bg-outlook-blue text-white rounded-lg hover:bg-outlook-darkblue transition-colors font-medium"
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          New message
        </button>
      </div>

      {/* User Info */}
      <div className="p-4 border-b border-outlook-gray-200">
        <div className="flex items-center">
          <div className="h-10 w-10 bg-outlook-blue rounded-full flex items-center justify-center text-white font-semibold">
            {user?.first_name?.charAt(0)}{user?.last_name?.charAt(0)}
          </div>
          <div className="ml-3 flex-1">
            <p className="text-sm font-medium text-outlook-gray-900 truncate">
              {user?.display_name}
            </p>
            <p className="text-xs text-outlook-gray-600 truncate">
              {user?.department}
            </p>
          </div>
        </div>
      </div>

      {/* Folders */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-outlook-gray-900">Folders</h3>
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="text-outlook-gray-400 hover:text-outlook-gray-600 transition-colors"
            >
              <ArrowPathIcon className={`h-4 w-4 \${refreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>
          
          <nav className="space-y-1">
            {folderList.map((folder) => {
              const IconComponent = folder.icon || InboxIcon;
              const isSelected = selectedFolder === folder.name;
              const unreadCount = folder.unread_count || 0;
              
              return (
                <button
                  key={folder.name}
                  onClick={() => onFolderSelect(folder.name)}
                  className={`w-full flex items-center px-3 py-2 text-sm rounded-lg transition-colors \${
                    isSelected
                      ? 'bg-outlook-blue text-white'
                      : 'text-outlook-gray-700 hover:bg-outlook-gray-100'
                  }`}
                >
                  <IconComponent className="h-4 w-4 mr-3 flex-shrink-0" />
                  <span className="flex-1 text-left truncate">
                    {folder.display_name}
                  </span>
                  
                  {/* Unread count */}
                  {unreadCount > 0 && (
                    <span className={`ml-2 px-2 py-0.5 text-xs rounded-full \${
                      isSelected 
                        ? 'bg-white text-outlook-blue' 
                        : 'bg-outlook-blue text-white'
                    }`}>
                      {unreadCount}
                    </span>
                  )}
                  
                  {/* Total count */}
                  {folder.count > 0 && unreadCount === 0 && (
                    <span className="ml-2 text-xs text-outlook-gray-400">
                      {folder.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Storage Info */}
      <div className="p-4 border-t border-outlook-gray-200">
        <div className="text-xs text-outlook-gray-600">
          <div className="flex justify-between mb-1">
            <span>Storage used</span>
            <span>2.1 GB of 15 GB</span>
          </div>
          <div className="w-full bg-outlook-gray-200 rounded-full h-1">
            <div className="bg-outlook-blue h-1 rounded-full" style={{ width: '14%' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}
"""

# Write layout and sidebar components
with open('DATAINTEG-MAILSERVER/frontend/components/Layout/OutlookLayout.js', 'w') as f:
    f.write(outlook_layout_content)

with open('DATAINTEG-MAILSERVER/frontend/components/Layout/AdminLayout.js', 'w') as f:
    f.write(admin_layout_content)

with open('DATAINTEG-MAILSERVER/frontend/components/Mail/Sidebar.js', 'w') as f:
    f.write(sidebar_content)

print("✅ Created layout components:")
print("  - Layout/OutlookLayout.js")
print("  - Layout/AdminLayout.js")
print("  - Mail/Sidebar.js")