# Frontend Package.json
frontend_package_json = """{
  "name": "datainteg-mailserver-frontend",
  "version": "1.0.0",
  "description": "Professional mail server frontend for DataInteg",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start -p 3000",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "14.0.3",
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "react-hot-toast": "2.4.1",
    "js-cookie": "3.0.5",
    "date-fns": "2.30.0",
    "react-icons": "4.11.0",
    "@heroicons/react": "2.0.18",
    "axios": "1.6.0",
    "react-dropzone": "14.2.3",
    "react-quill": "2.0.0",
    "quill": "1.3.7",
    "clsx": "2.0.0",
    "tailwind-merge": "2.0.0"
  },
  "devDependencies": {
    "@types/js-cookie": "3.0.6",
    "@types/node": "20.9.0",
    "@types/react": "18.2.37",
    "@types/react-dom": "18.2.15",
    "autoprefixer": "10.4.16",
    "eslint": "8.53.0",
    "eslint-config-next": "14.0.3",
    "postcss": "8.4.31",
    "tailwindcss": "3.3.5",
    "typescript": "5.2.2"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}"""

# Next.js Configuration
next_config_content = """/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  
  // Configure for production deployment
  output: 'standalone',
  
  // Environment variables
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api',
    NEXT_PUBLIC_DOMAIN: process.env.NEXT_PUBLIC_DOMAIN || 'datainteg.in',
  },
  
  // Image domains (if needed)
  images: {
    domains: ['datainteg.in', 'localhost'],
  },
  
  // Custom webpack config
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    // Custom webpack configurations if needed
    return config;
  },
  
  // Redirect configuration
  async redirects() {
    return [
      {
        source: '/',
        destination: '/login',
        permanent: false,
      },
    ];
  },
  
  // Headers configuration
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Credentials', value: 'true' },
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET,OPTIONS,PATCH,DELETE,POST,PUT' },
          { key: 'Access-Control-Allow-Headers', value: 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
"""

# Tailwind Configuration
tailwind_config_content = """/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Outlook-inspired color palette
        'outlook-blue': '#0078d4',
        'outlook-darkblue': '#106ebe',
        'outlook-lightblue': '#deecf9',
        'outlook-gray': {
          50: '#faf9f8',
          100: '#f3f2f1',
          200: '#edebe9',
          300: '#e1dfdd',
          400: '#d2d0ce',
          500: '#b3b0ad',
          600: '#979593',
          700: '#797775',
          800: '#605e5c',
          900: '#323130',
        },
        'mail-red': '#d13438',
        'mail-green': '#107c10',
        'mail-orange': '#ff8c00',
        'mail-purple': '#5c2d91',
      },
      fontFamily: {
        'segoe': ['Segoe UI', 'system-ui', 'sans-serif'],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-in': 'slideIn 0.3s ease-out',
        'spin-slow': 'spin 2s linear infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' },
        },
      },
      boxShadow: {
        'outlook': '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)',
        'outlook-hover': '0 3.2px 7.2px 0 rgba(0,0,0,0.132), 0 0.6px 1.8px 0 rgba(0,0,0,0.108)',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
};
"""

# PostCSS Configuration
postcss_config_content = """module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
"""

# Environment Variables
env_local_content = """# API Configuration
NEXT_PUBLIC_API_URL=https://datainteg.in/api
NEXT_PUBLIC_DOMAIN=datainteg.in

# Application Configuration
NEXT_PUBLIC_APP_NAME=DataInteg Mail
NEXT_PUBLIC_APP_VERSION=1.0.0

# Debug Mode
NEXT_PUBLIC_DEBUG=false
"""

# Write frontend configuration files
with open('DATAINTEG-MAILSERVER/frontend/package.json', 'w') as f:
    f.write(frontend_package_json)

with open('DATAINTEG-MAILSERVER/frontend/next.config.js', 'w') as f:
    f.write(next_config_content)

with open('DATAINTEG-MAILSERVER/frontend/tailwind.config.js', 'w') as f:
    f.write(tailwind_config_content)

with open('DATAINTEG-MAILSERVER/frontend/postcss.config.js', 'w') as f:
    f.write(postcss_config_content)

with open('DATAINTEG-MAILSERVER/frontend/.env.local', 'w') as f:
    f.write(env_local_content)

print("✅ Created frontend configuration files:")
print("  - package.json")
print("  - next.config.js")
print("  - tailwind.config.js")
print("  - postcss.config.js")
print("  - .env.local")