# MailList Component
mail_list_content = """import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import {
  StarIcon,
  PaperClipIcon,
  ExclamationCircleIcon,
} from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';

export default function MailList({ 
  emails, 
  loading, 
  selectedEmail, 
  onEmailSelect, 
  folder, 
  onRefresh 
}) {
  const [selectAll, setSelectAll] = useState(false);
  const [selectedEmails, setSelectedEmails] = useState([]);

  const formatDate = (dateStr) => {
    try {
      const date = new Date(dateStr);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return 'Unknown';
    }
  };

  const handleSelectAll = (checked) => {
    setSelectAll(checked);
    if (checked) {
      setSelectedEmails(emails.map(email => email._id));
    } else {
      setSelectedEmails([]);
    }
  };

  const handleEmailCheck = (emailId, checked) => {
    if (checked) {
      setSelectedEmails(prev => [...prev, emailId]);
    } else {
      setSelectedEmails(prev => prev.filter(id => id !== emailId));
    }
  };

  const getSenderDisplay = (sender) => {
    if (!sender) return 'Unknown Sender';
    
    // Extract name from "Name <email@domain.com>" format
    const match = sender.match(/^(.+?)\\s*<(.+)>$/);
    if (match) {
      return match[1].replace(/['"]/g, '').trim();
    }
    
    // If just email, extract local part
    if (sender.includes('@')) {
      return sender.split('@')[0];
    }
    
    return sender;
  };

  if (loading) {
    return (
      <div className="w-80 border-r border-outlook-gray-200 bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin-slow w-6 h-6 border-2 border-outlook-blue border-t-transparent rounded-full mx-auto mb-2"></div>
          <p className="text-sm text-outlook-gray-600">Loading emails...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 border-r border-outlook-gray-200 bg-white flex flex-col">
      {/* Email List Header */}
      <div className="border-b border-outlook-gray-200 p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-outlook-gray-900 capitalize">
            {folder?.toLowerCase() || 'Inbox'}
          </h2>
          <span className="text-sm text-outlook-gray-600">
            {emails.length} items
          </span>
        </div>
        
        {/* Select All Checkbox */}
        <div className="flex items-center">
          <input
            type="checkbox"
            checked={selectAll}
            onChange={(e) => handleSelectAll(e.target.checked)}
            className="h-4 w-4 text-outlook-blue focus:ring-outlook-blue border-outlook-gray-300 rounded"
          />
          <label className="ml-2 text-sm text-outlook-gray-700">
            Select all
          </label>
        </div>
      </div>

      {/* Email List */}
      <div className="flex-1 overflow-y-auto">
        {emails.length === 0 ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-outlook-gray-100 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-outlook-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-outlook-gray-600">No emails in this folder</p>
          </div>
        ) : (
          <div className="divide-y divide-outlook-gray-100">
            {emails.map((email) => {
              const isSelected = selectedEmail?._id === email._id;
              const isChecked = selectedEmails.includes(email._id);
              const isUnread = !email.is_read;
              const hasAttachments = email.attachments && email.attachments.length > 0;
              
              return (
                <div
                  key={email._id}
                  onClick={() => onEmailSelect(email)}
                  className={`p-3 cursor-pointer transition-colors hover:bg-outlook-gray-50 \\${
                    isSelected ? 'bg-outlook-lightblue border-r-2 border-outlook-blue' : ''
                  } \\${isUnread ? 'bg-white' : 'bg-outlook-gray-25'}`}
                >
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1 mr-3">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => {
                          e.stopPropagation();
                          handleEmailCheck(email._id, e.target.checked);
                        }}
                        className="h-4 w-4 text-outlook-blue focus:ring-outlook-blue border-outlook-gray-300 rounded"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center min-w-0 flex-1">
                          <p className={`text-sm truncate \\${
                            isUnread ? 'font-semibold text-outlook-gray-900' : 'font-normal text-outlook-gray-700'
                          }`}>
                            {getSenderDisplay(email.sender)}
                          </p>
                          
                          {/* Unread indicator */}
                          {isUnread && (
                            <div className="ml-2 w-2 h-2 bg-outlook-blue rounded-full flex-shrink-0"></div>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-1 ml-2 flex-shrink-0">
                          {/* Star */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              // TODO: Handle star toggle
                            }}
                            className="text-outlook-gray-400 hover:text-mail-orange transition-colors"
                          >
                            {email.is_starred ? (
                              <StarIconSolid className="h-4 w-4 text-mail-orange" />
                            ) : (
                              <StarIcon className="h-4 w-4" />
                            )}
                          </button>
                          
                          {/* Attachments */}
                          {hasAttachments && (
                            <PaperClipIcon className="h-4 w-4 text-outlook-gray-400" />
                          )}
                          
                          {/* Important */}
                          {email.is_important && (
                            <ExclamationCircleIcon className="h-4 w-4 text-mail-red" />
                          )}
                        </div>
                      </div>
                      
                      <p className={`text-sm mb-1 truncate \\${
                        isUnread ? 'font-medium text-outlook-gray-900' : 'text-outlook-gray-600'
                      }`}>
                        {email.subject || '(No Subject)'}
                      </p>
                      
                      <p className="text-xs text-outlook-gray-500 truncate mb-2">
                        {email.preview || email.body?.substring(0, 100) || 'No preview available'}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-outlook-gray-500">
                          {formatDate(email.created_at)}
                        </span>
                        
                        {/* Folder indicator if not in INBOX */}
                        {folder !== 'INBOX' && (
                          <span className="text-xs text-outlook-gray-400 bg-outlook-gray-100 px-2 py-0.5 rounded">
                            {folder}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bulk Actions */}
      {selectedEmails.length > 0 && (
        <div className="border-t border-outlook-gray-200 p-3 bg-outlook-gray-50">
          <div className="flex items-center justify-between">
            <span className="text-sm text-outlook-gray-700">
              {selectedEmails.length} selected
            </span>
            <div className="flex space-x-2">
              <button className="text-xs bg-outlook-blue text-white px-3 py-1 rounded hover:bg-outlook-darkblue transition-colors">
                Archive
              </button>
              <button className="text-xs bg-mail-red text-white px-3 py-1 rounded hover:bg-red-700 transition-colors">
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
"""

# MailViewer Component
mail_viewer_content = """import { useState } from 'react';
import { formatDistanceToNow, format } from 'date-fns';
import {
  XMarkIcon,
  ArrowUturnLeftIcon,
  ArrowPathIcon,
  PrinterIcon,
  PaperClipIcon,
  StarIcon,
  ExclamationCircleIcon,
} from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';

export default function MailViewer({ email, onClose, onReply }) {
  const [showFullHeaders, setShowFullHeaders] = useState(false);

  if (!email) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-outlook-gray-100 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-outlook-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <p className="text-outlook-gray-600">Select an email to read</p>
        </div>
      </div>
    );
  }

  const formatDate = (dateStr) => {
    try {
      const date = new Date(dateStr);
      return format(date, 'PPpp');
    } catch (error) {
      return 'Unknown date';
    }
  };

  const getSenderDisplay = (sender) => {
    if (!sender) return 'Unknown Sender';
    
    const match = sender.match(/^(.+?)\\s*<(.+)>$/);
    if (match) {
      return {
        name: match[1].replace(/['"]/g, '').trim(),
        email: match[2]
      };
    }
    
    return {
      name: sender.includes('@') ? sender.split('@')[0] : sender,
      email: sender
    };
  };

  const senderInfo = getSenderDisplay(email.sender);
  const hasAttachments = email.attachments && email.attachments.length > 0;

  return (
    <div className="flex-1 bg-white flex flex-col">
      {/* Email Header */}
      <div className="border-b border-outlook-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <h1 className="text-xl font-semibold text-outlook-gray-900 truncate">
              {email.subject || '(No Subject)'}
            </h1>
            
            {email.is_starred && (
              <StarIconSolid className="h-5 w-5 text-mail-orange" />
            )}
            
            {email.is_important && (
              <ExclamationCircleIcon className="h-5 w-5 text-mail-red" />
            )}
            
            {hasAttachments && (
              <PaperClipIcon className="h-5 w-5 text-outlook-gray-400" />
            )}
          </div>
          
          <button
            onClick={onClose}
            className="text-outlook-gray-400 hover:text-outlook-gray-600 transition-colors"
          >
            <XMarkIcon className="h-5 w-5" />
          </button>
        </div>

        {/* Sender Info */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <div className="h-10 w-10 bg-outlook-blue rounded-full flex items-center justify-center text-white font-semibold mr-3">
              {senderInfo.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-medium text-outlook-gray-900">{senderInfo.name}</p>
              <p className="text-sm text-outlook-gray-600">{senderInfo.email}</p>
            </div>
          </div>
          
          <div className="text-right">
            <p className="text-sm text-outlook-gray-600">{formatDate(email.created_at)}</p>
            <p className="text-xs text-outlook-gray-500">
              {email.is_read ? 'Read' : 'Unread'}
            </p>
          </div>
        </div>

        {/* Recipients */}
        <div className="text-sm text-outlook-gray-600 mb-3">
          <div className="flex flex-wrap items-center">
            <span className="font-medium mr-2">To:</span>
            <span>{email.recipients?.join(', ') || 'Unknown'}</span>
          </div>
          
          {email.cc && email.cc.length > 0 && (
            <div className="flex flex-wrap items-center mt-1">
              <span className="font-medium mr-2">Cc:</span>
              <span>{email.cc.join(', ')}</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onReply}
            className="flex items-center px-3 py-1.5 text-sm bg-outlook-blue text-white rounded hover:bg-outlook-darkblue transition-colors"
          >
            <ArrowUturnLeftIcon className="h-4 w-4 mr-1" />
            Reply
          </button>
          
          <button className="flex items-center px-3 py-1.5 text-sm border border-outlook-gray-300 text-outlook-gray-700 rounded hover:bg-outlook-gray-50 transition-colors">
            <ArrowPathIcon className="h-4 w-4 mr-1" />
            Forward
          </button>
          
          <button className="flex items-center px-3 py-1.5 text-sm border border-outlook-gray-300 text-outlook-gray-700 rounded hover:bg-outlook-gray-50 transition-colors">
            <PrinterIcon className="h-4 w-4 mr-1" />
            Print
          </button>
          
          <button className="flex items-center px-3 py-1.5 text-sm border border-outlook-gray-300 text-outlook-gray-700 rounded hover:bg-outlook-gray-50 transition-colors">
            <StarIcon className="h-4 w-4 mr-1" />
            Star
          </button>
        </div>
      </div>

      {/* Attachments */}
      {hasAttachments && (
        <div className="border-b border-outlook-gray-200 p-4 bg-outlook-gray-50">
          <h3 className="text-sm font-medium text-outlook-gray-900 mb-2">
            Attachments ({email.attachments.length})
          </h3>
          <div className="flex flex-wrap gap-2">
            {email.attachments.map((attachment, index) => (
              <div
                key={index}
                className="flex items-center px-3 py-2 bg-white border border-outlook-gray-200 rounded-lg"
              >
                <PaperClipIcon className="h-4 w-4 text-outlook-gray-400 mr-2" />
                <span className="text-sm text-outlook-gray-700 mr-2">
                  {attachment.original_filename || attachment.filename}
                </span>
                <span className="text-xs text-outlook-gray-500">
                  ({attachment.file_size ? (attachment.file_size / 1024).toFixed(1) + ' KB' : 'Unknown size'})
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Email Body */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-none">
          {email.html_body ? (
            <div 
              className="prose prose-sm max-w-none"
              dangerouslySetInnerHTML={{ __html: email.html_body }}
            />
          ) : (
            <div className="whitespace-pre-wrap text-outlook-gray-800 leading-relaxed">
              {email.body || 'No content available'}
            </div>
          )}
        </div>
      </div>

      {/* Email Metadata (Optional) */}
      {showFullHeaders && (
        <div className="border-t border-outlook-gray-200 p-4 bg-outlook-gray-50">
          <h3 className="text-sm font-medium text-outlook-gray-900 mb-2">Message Details</h3>
          <div className="text-xs text-outlook-gray-600 space-y-1">
            <div><span className="font-medium">Message ID:</span> {email.message_id}</div>
            <div><span className="font-medium">Folder:</span> {email.folder}</div>
            <div><span className="font-medium">Created:</span> {email.created_at}</div>
            {email.read_at && (
              <div><span className="font-medium">Read:</span> {email.read_at}</div>
            )}
          </div>
        </div>
      )}

      {/* Toggle Headers Button */}
      <div className="border-t border-outlook-gray-200 p-2">
        <button
          onClick={() => setShowFullHeaders(!showFullHeaders)}
          className="text-xs text-outlook-gray-500 hover:text-outlook-gray-700 transition-colors"
        >
          {showFullHeaders ? 'Hide' : 'Show'} message details
        </button>
      </div>
    </div>
  );
}
"""

# ComposeModal Component
compose_modal_content = """import { useState, useRef } from 'react';
import {
  XMarkIcon,
  PaperAirplaneIcon,
  PaperClipIcon,
  DocumentIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';

export default function ComposeModal({ user, onClose, onSent, replyTo }) {
  const [formData, setFormData] = useState({
    recipients: replyTo ? [replyTo.sender] : [],
    cc: [],
    bcc: [],
    subject: replyTo ? `Re: ${replyTo.subject}` : '',
    body: replyTo ? getReplyBody(replyTo) : '',
    attachments: []
  });
  
  const [sending, setSending] = useState(false);
  const [showCc, setShowCc] = useState(false);
  const [showBcc, setShowBcc] = useState(false);
  const fileInputRef = useRef(null);

  function getReplyBody(email) {
    const originalDate = new Date(email.created_at).toLocaleString();
    return `\\n\\n---Original Message---\\nFrom: ${email.sender}\\nSent: ${originalDate}\\nSubject: ${email.subject}\\n\\n${email.body || ''}`;
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRecipientsChange = (value, field = 'recipients') => {
    const emails = value.split(',').map(email => email.trim()).filter(email => email);
    handleInputChange(field, emails);
  };

  const handleFileAttachment = (e) => {
    const files = Array.from(e.target.files);
    // For now, just store file info - in real implementation, upload to server
    const fileInfo = files.map(file => ({
      name: file.name,
      size: file.size,
      type: file.type,
      file: file
    }));
    
    setFormData(prev => ({
      ...prev,
      attachments: [...prev.attachments, ...fileInfo]
    }));
  };

  const removeAttachment = (index) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  const handleSend = async () => {
    // Validation
    if (formData.recipients.length === 0) {
      toast.error('Please add at least one recipient');
      return;
    }

    if (!formData.subject.trim()) {
      toast.error('Please add a subject');
      return;
    }

    if (!formData.body.trim()) {
      toast.error('Please add a message');
      return;
    }

    setSending(true);

    try {
      // TODO: Upload attachments first if any
      let attachmentData = [];
      
      if (formData.attachments.length > 0) {
        // Upload attachments
        for (const attachment of formData.attachments) {
          const formDataAttachment = new FormData();
          formDataAttachment.append('file', attachment.file);
          
          const token = Cookies.get('auth-token');
          const uploadResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/mail/upload-attachment`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
            },
            body: formDataAttachment,
          });
          
          if (uploadResponse.ok) {
            const uploadData = await uploadResponse.json();
            attachmentData.push(uploadData.data);
          }
        }
      }

      // Send email
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/mail/send`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          recipients: formData.recipients,
          cc: formData.cc.length > 0 ? formData.cc : undefined,
          bcc: formData.bcc.length > 0 ? formData.bcc : undefined,
          subject: formData.subject,
          body: formData.body,
          attachments: attachmentData
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        onSent();
      } else {
        toast.error(data.error || 'Failed to send email');
      }
    } catch (error) {
      console.error('Send email error:', error);
      toast.error('Failed to send email');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-outlook-hover max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-outlook-gray-200">
          <h2 className="text-lg font-semibold text-outlook-gray-900">
            {replyTo ? 'Reply' : 'New Message'}
          </h2>
          <button
            onClick={onClose}
            className="text-outlook-gray-400 hover:text-outlook-gray-600 transition-colors"
          >
            <XMarkIcon className="h-5 w-5" />
          </button>
        </div>

        {/* Form */}
        <div className="flex flex-col h-full max-h-[calc(90vh-80px)]">
          {/* Recipients */}
          <div className="p-6 border-b border-outlook-gray-200 space-y-3">
            <div className="flex items-center">
              <label className="w-12 text-sm font-medium text-outlook-gray-700">To:</label>
              <input
                type="text"
                value={formData.recipients.join(', ')}
                onChange={(e) => handleRecipientsChange(e.target.value)}
                placeholder="Enter email addresses separated by commas"
                className="flex-1 px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
              />
              <button
                onClick={() => setShowCc(!showCc)}
                className="ml-2 text-sm text-outlook-blue hover:text-outlook-darkblue"
              >
                Cc
              </button>
              <button
                onClick={() => setShowBcc(!showBcc)}
                className="ml-2 text-sm text-outlook-blue hover:text-outlook-darkblue"
              >
                Bcc
              </button>
            </div>

            {showCc && (
              <div className="flex items-center">
                <label className="w-12 text-sm font-medium text-outlook-gray-700">Cc:</label>
                <input
                  type="text"
                  value={formData.cc.join(', ')}
                  onChange={(e) => handleRecipientsChange(e.target.value, 'cc')}
                  placeholder="Carbon copy recipients"
                  className="flex-1 px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                />
              </div>
            )}

            {showBcc && (
              <div className="flex items-center">
                <label className="w-12 text-sm font-medium text-outlook-gray-700">Bcc:</label>
                <input
                  type="text"
                  value={formData.bcc.join(', ')}
                  onChange={(e) => handleRecipientsChange(e.target.value, 'bcc')}
                  placeholder="Blind carbon copy recipients"
                  className="flex-1 px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
                />
              </div>
            )}

            <div className="flex items-center">
              <label className="w-12 text-sm font-medium text-outlook-gray-700">Subject:</label>
              <input
                type="text"
                value={formData.subject}
                onChange={(e) => handleInputChange('subject', e.target.value)}
                placeholder="Email subject"
                className="flex-1 px-3 py-2 border border-outlook-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
              />
            </div>
          </div>

          {/* Attachments */}
          {formData.attachments.length > 0 && (
            <div className="px-6 py-3 border-b border-outlook-gray-200 bg-outlook-gray-50">
              <div className="flex flex-wrap gap-2">
                {formData.attachments.map((attachment, index) => (
                  <div
                    key={index}
                    className="flex items-center px-3 py-1 bg-white border border-outlook-gray-200 rounded-lg"
                  >
                    <DocumentIcon className="h-4 w-4 text-outlook-gray-400 mr-2" />
                    <span className="text-sm text-outlook-gray-700 mr-2">{attachment.name}</span>
                    <button
                      onClick={() => removeAttachment(index)}
                      className="text-outlook-gray-400 hover:text-mail-red transition-colors"
                    >
                      <XMarkIcon className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Message Body */}
          <div className="flex-1 p-6">
            <textarea
              value={formData.body}
              onChange={(e) => handleInputChange('body', e.target.value)}
              placeholder="Type your message here..."
              className="w-full h-full resize-none border border-outlook-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-outlook-blue focus:border-transparent"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-between px-6 py-4 border-t border-outlook-gray-200">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center px-3 py-1.5 text-sm border border-outlook-gray-300 text-outlook-gray-700 rounded hover:bg-outlook-gray-50 transition-colors"
              >
                <PaperClipIcon className="h-4 w-4 mr-1" />
                Attach
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileAttachment}
                className="hidden"
              />
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm border border-outlook-gray-300 text-outlook-gray-700 rounded hover:bg-outlook-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSend}
                disabled={sending}
                className="flex items-center px-4 py-2 text-sm bg-outlook-blue text-white rounded hover:bg-outlook-darkblue disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {sending ? (
                  <>
                    <div className="animate-spin-slow w-4 h-4 border border-white border-t-transparent rounded-full mr-2"></div>
                    Sending...
                  </>
                ) : (
                  <>
                    <PaperAirplaneIcon className="h-4 w-4 mr-1" />
                    Send
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
"""

# Write mail components
with open('DATAINTEG-MAILSERVER/frontend/components/Mail/MailList.js', 'w') as f:
    f.write(mail_list_content)

with open('DATAINTEG-MAILSERVER/frontend/components/Mail/MailViewer.js', 'w') as f:
    f.write(mail_viewer_content)

with open('DATAINTEG-MAILSERVER/frontend/components/Mail/ComposeModal.js', 'w') as f:
    f.write(compose_modal_content)

print("✅ Created mail components:")
print("  - Mail/MailList.js")
print("  - Mail/MailViewer.js")
print("  - Mail/ComposeModal.js")