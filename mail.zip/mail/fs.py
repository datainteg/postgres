# File Utilities
file_utils_content = """
import os
import uuid
import mimetypes
import logging
from werkzeug.utils import secure_filename
from flask import current_app
from typing import Dict, List, Optional, Tuple
from PIL import Image
import hashlib

class FileUtils:
    def __init__(self):
        self.upload_folder = current_app.config.get('UPLOAD_FOLDER', './uploads')
        self.max_file_size = current_app.config.get('MAX_CONTENT_LENGTH', 25 * 1024 * 1024)  # 25MB
        self.allowed_extensions = current_app.config.get('ALLOWED_EXTENSIONS', {
            'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 
            'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'rar', '7z', 'mp4', 'avi', 'mp3'
        })
        
        # Ensure upload directory exists
        os.makedirs(self.upload_folder, exist_ok=True)
    
    def allowed_file(self, filename: str) -> bool:
        '''Check if file extension is allowed'''
        return '.' in filename and \\
               filename.rsplit('.', 1)[1].lower() in self.allowed_extensions
    
    def save_uploaded_file(self, file, email_id: str = None) -> Dict:
        '''Save uploaded file and return file information'''
        try:
            if not file or not file.filename:
                return {"success": False, "error": "No file provided"}
            
            if not self.allowed_file(file.filename):
                return {"success": False, "error": "File type not allowed"}
            
            # Check file size
            file.seek(0, os.SEEK_END)
            file_size = file.tell()
            file.seek(0)
            
            if file_size > self.max_file_size:
                return {"success": False, "error": "File size too large"}
            
            # Generate unique filename
            original_filename = secure_filename(file.filename)
            file_extension = os.path.splitext(original_filename)[1]
            unique_filename = f"{uuid.uuid4()}{file_extension}"
            
            # Create subdirectory based on email_id or date
            if email_id:
                subdirectory = os.path.join(self.upload_folder, 'emails', email_id)
            else:
                from datetime import datetime
                subdirectory = os.path.join(self.upload_folder, datetime.now().strftime('%Y/%m/%d'))
            
            os.makedirs(subdirectory, exist_ok=True)
            
            # Save file
            file_path = os.path.join(subdirectory, unique_filename)
            file.save(file_path)
            
            # Get file info
            mime_type, _ = mimetypes.guess_type(original_filename)
            file_hash = self._calculate_file_hash(file_path)
            
            file_info = {
                'filename': unique_filename,
                'original_filename': original_filename,
                'file_path': file_path,
                'file_size': file_size,
                'mime_type': mime_type or 'application/octet-stream',
                'file_hash': file_hash
            }
            
            # If it's an image, create thumbnail
            if self._is_image(mime_type):
                thumbnail_path = self._create_thumbnail(file_path, unique_filename, subdirectory)
                file_info['thumbnail_path'] = thumbnail_path
            
            logging.info(f"File saved successfully: {original_filename}")
            return {"success": True, "file_info": file_info}
            
        except Exception as e:
            logging.error(f"Error saving file: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _calculate_file_hash(self, file_path: str) -> str:
        '''Calculate SHA-256 hash of file'''
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(chunk)
            return sha256_hash.hexdigest()
        except Exception:
            return ''
    
    def _is_image(self, mime_type: str) -> bool:
        '''Check if file is an image'''
        return mime_type and mime_type.startswith('image/')
    
    def _create_thumbnail(self, file_path: str, filename: str, subdirectory: str) -> str:
        '''Create thumbnail for image files'''
        try:
            # Open image
            with Image.open(file_path) as img:
                # Convert to RGB if necessary
                if img.mode in ('RGBA', 'P'):
                    img = img.convert('RGB')
                
                # Create thumbnail
                img.thumbnail((150, 150), Image.Resampling.LANCZOS)
                
                # Save thumbnail
                thumbnail_filename = f"thumb_{filename}"
                thumbnail_path = os.path.join(subdirectory, thumbnail_filename)
                img.save(thumbnail_path, 'JPEG', quality=85)
                
                return thumbnail_path
        except Exception as e:
            logging.error(f"Error creating thumbnail: {str(e)}")
            return ''
    
    def delete_file(self, file_path: str) -> bool:
        '''Delete file from filesystem'''
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                
                # Also delete thumbnail if exists
                directory, filename = os.path.split(file_path)
                thumbnail_path = os.path.join(directory, f"thumb_{filename}")
                if os.path.exists(thumbnail_path):
                    os.remove(thumbnail_path)
                
                logging.info(f"File deleted: {file_path}")
                return True
            return False
        except Exception as e:
            logging.error(f"Error deleting file: {str(e)}")
            return False
    
    def get_file_info(self, file_path: str) -> Dict:
        '''Get information about a file'''
        try:
            if not os.path.exists(file_path):
                return {"success": False, "error": "File not found"}
            
            stat = os.stat(file_path)
            mime_type, _ = mimetypes.guess_type(file_path)
            
            return {
                "success": True,
                "info": {
                    "size": stat.st_size,
                    "modified": stat.st_mtime,
                    "mime_type": mime_type,
                    "exists": True
                }
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def clean_old_files(self, days: int = 30) -> Dict:
        '''Clean files older than specified days'''
        try:
            import time
            from datetime import datetime, timedelta
            
            cutoff_time = time.time() - (days * 24 * 60 * 60)
            deleted_count = 0
            
            for root, dirs, files in os.walk(self.upload_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    if os.path.getmtime(file_path) < cutoff_time:
                        try:
                            os.remove(file_path)
                            deleted_count += 1
                        except Exception:
                            continue
            
            return {
                "success": True, 
                "deleted_count": deleted_count,
                "message": f"Deleted {deleted_count} old files"
            }
            
        except Exception as e:
            logging.error(f"Error cleaning old files: {str(e)}")
            return {"success": False, "error": str(e)}

# Global instance
file_utils = FileUtils()
"""

# SMTP Utilities
smtp_utils_content = """
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import Dict, List, Optional
from flask import current_app
import socket
import dns.resolver

class SMTPUtils:
    def __init__(self):
        self.smtp_server = current_app.config.get('MAIL_SERVER', 'smtp.hostinger.com')
        self.smtp_port = current_app.config.get('MAIL_PORT', 587)
        self.default_username = current_app.config.get('MAIL_USERNAME')
        self.default_password = current_app.config.get('MAIL_PASSWORD')
        self.use_tls = current_app.config.get('MAIL_USE_TLS', True)
        self.use_ssl = current_app.config.get('MAIL_USE_SSL', False)
    
    def test_smtp_connection(self, username: str = None, password: str = None) -> Dict:
        '''Test SMTP connection'''
        try:
            username = username or self.default_username
            password = password or self.default_password
            
            if self.use_ssl:
                server = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port)
            else:
                server = smtplib.SMTP(self.smtp_server, self.smtp_port)
                
            if self.use_tls and not self.use_ssl:
                server.starttls()
                
            server.login(username, password)
            server.quit()
            
            return {"success": True, "message": "SMTP connection successful"}
            
        except smtplib.SMTPAuthenticationError:
            return {"success": False, "error": "SMTP authentication failed"}
        except smtplib.SMTPConnectError:
            return {"success": False, "error": "Failed to connect to SMTP server"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def send_email_direct(self, sender: str, recipient: str, subject: str, 
                         body: str, html_body: str = None, 
                         sender_credentials: Dict = None) -> Dict:
        '''Send email directly through SMTP'''
        try:
            # Use provided credentials or default
            if sender_credentials:
                username = sender_credentials.get('username', self.default_username)
                password = sender_credentials.get('password', self.default_password)
            else:
                username = self.default_username
                password = self.default_password
            
            # Create message
            msg = MIMEMultipart('alternative')
            msg['From'] = sender
            msg['To'] = recipient
            msg['Subject'] = subject
            
            # Add text part
            text_part = MIMEText(body, 'plain', 'utf-8')
            msg.attach(text_part)
            
            # Add HTML part if provided
            if html_body:
                html_part = MIMEText(html_body, 'html', 'utf-8')
                msg.attach(html_part)
            
            # Connect and send
            if self.use_ssl:
                server = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port)
            else:
                server = smtplib.SMTP(self.smtp_server, self.smtp_port)
                
            if self.use_tls and not self.use_ssl:
                server.starttls()
                
            server.login(username, password)
            server.sendmail(sender, recipient, msg.as_string())
            server.quit()
            
            logging.info(f"Email sent successfully from {sender} to {recipient}")
            return {"success": True, "message": "Email sent successfully"}
            
        except Exception as e:
            logging.error(f"Error sending email: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_mx_records(self, domain: str) -> List[Dict]:
        '''Get MX records for a domain'''
        try:
            mx_records = dns.resolver.resolve(domain, 'MX')
            records = []
            
            for mx in mx_records:
                records.append({
                    'priority': mx.preference,
                    'server': str(mx.exchange).rstrip('.')
                })
            
            return sorted(records, key=lambda x: x['priority'])
            
        except Exception as e:
            logging.error(f"Error getting MX records for {domain}: {str(e)}")
            return []
    
    def validate_email_domain(self, email: str) -> Dict:
        '''Validate email domain has MX records'''
        try:
            domain = email.split('@')[1]
            mx_records = self.get_mx_records(domain)
            
            if mx_records:
                return {
                    "success": True, 
                    "valid": True,
                    "mx_records": mx_records
                }
            else:
                return {
                    "success": True,
                    "valid": False,
                    "error": "No MX records found"
                }
                
        except Exception as e:
            return {
                "success": False,
                "valid": False,
                "error": str(e)
            }
    
    def check_smtp_server_health(self) -> Dict:
        '''Check SMTP server health'''
        try:
            # Test connection without authentication
            if self.use_ssl:
                server = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port, timeout=10)
            else:
                server = smtplib.SMTP(self.smtp_server, self.smtp_port, timeout=10)
                
            if self.use_tls and not self.use_ssl:
                server.starttls()
                
            # Get server info
            code, message = server.noop()
            server.quit()
            
            return {
                "success": True,
                "server_response": message.decode() if isinstance(message, bytes) else str(message),
                "response_code": code
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}

# Global instance  
smtp_utils = SMTPUtils()
"""

# Validation Utilities
validation_utils_content = """
import re
import email_validator
import logging
from typing import Dict, List, Optional
from flask import current_app

class ValidationUtils:
    def __init__(self):
        self.domain = current_app.config.get('DOMAIN', 'datainteg.in')
        
        # Regex patterns
        self.email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        self.username_pattern = re.compile(r'^[a-zA-Z0-9._-]+$')
        self.phone_pattern = re.compile(r'^[+]?[1-9]?[0-9]{7,15}$')
        
        # Password requirements
        self.min_password_length = 8
        self.password_pattern = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]')
    
    def validate_email(self, email: str) -> Dict:
        '''Validate email address'''
        try:
            if not email:
                return {"valid": False, "error": "Email is required"}
            
            # Basic format check
            if not self.email_pattern.match(email):
                return {"valid": False, "error": "Invalid email format"}
            
            # Use email-validator for more thorough validation
            try:
                validated_email = email_validator.validate_email(email)
                return {
                    "valid": True, 
                    "normalized": validated_email.email,
                    "local": validated_email.local,
                    "domain": validated_email.domain
                }
            except email_validator.EmailNotValidError as e:
                return {"valid": False, "error": str(e)}
                
        except Exception as e:
            logging.error(f"Error validating email: {str(e)}")
            return {"valid": False, "error": "Email validation failed"}
    
    def validate_username(self, username: str) -> Dict:
        '''Validate username'''
        try:
            if not username:
                return {"valid": False, "error": "Username is required"}
            
            if len(username) < 3:
                return {"valid": False, "error": "Username must be at least 3 characters"}
            
            if len(username) > 30:
                return {"valid": False, "error": "Username must be less than 30 characters"}
            
            if not self.username_pattern.match(username):
                return {"valid": False, "error": "Username can only contain letters, numbers, dots, hyphens and underscores"}
            
            # Check for reserved usernames
            reserved_usernames = ['admin', 'root', 'support', 'info', 'noreply', 'postmaster']
            if username.lower() in reserved_usernames:
                return {"valid": False, "error": "Username is reserved"}
            
            return {"valid": True}
            
        except Exception as e:
            logging.error(f"Error validating username: {str(e)}")
            return {"valid": False, "error": "Username validation failed"}
    
    def validate_password(self, password: str) -> Dict:
        '''Validate password strength'''
        try:
            if not password:
                return {"valid": False, "error": "Password is required"}
            
            if len(password) < self.min_password_length:
                return {
                    "valid": False, 
                    "error": f"Password must be at least {self.min_password_length} characters"
                }
            
            # Check complexity
            has_lower = any(c.islower() for c in password)
            has_upper = any(c.isupper() for c in password)
            has_digit = any(c.isdigit() for c in password)
            has_special = any(c in '@$!%*?&' for c in password)
            
            missing = []
            if not has_lower:
                missing.append("lowercase letter")
            if not has_upper:
                missing.append("uppercase letter")  
            if not has_digit:
                missing.append("number")
            if not has_special:
                missing.append("special character (@$!%*?&)")
            
            if missing:
                return {
                    "valid": False,
                    "error": f"Password must contain at least one: {', '.join(missing)}"
                }
            
            return {"valid": True, "strength": "strong"}
            
        except Exception as e:
            logging.error(f"Error validating password: {str(e)}")
            return {"valid": False, "error": "Password validation failed"}
    
    def validate_phone(self, phone: str) -> Dict:
        '''Validate phone number'''
        try:
            if not phone:
                return {"valid": True}  # Phone is optional
            
            # Remove spaces and formatting
            clean_phone = re.sub(r'[^\d+]', '', phone)
            
            if not self.phone_pattern.match(clean_phone):
                return {"valid": False, "error": "Invalid phone number format"}
            
            return {"valid": True, "normalized": clean_phone}
            
        except Exception as e:
            logging.error(f"Error validating phone: {str(e)}")
            return {"valid": False, "error": "Phone validation failed"}
    
    def validate_user_registration(self, user_data: Dict) -> Dict:
        '''Validate complete user registration data'''
        errors = {}
        
        # Required fields
        required_fields = ['username', 'password', 'first_name', 'last_name', 'email']
        for field in required_fields:
            if not user_data.get(field):
                errors[field] = f"{field.replace('_', ' ').title()} is required"
        
        # Validate individual fields
        if user_data.get('username'):
            username_validation = self.validate_username(user_data['username'])
            if not username_validation['valid']:
                errors['username'] = username_validation['error']
        
        if user_data.get('email'):
            email_validation = self.validate_email(user_data['email'])
            if not email_validation['valid']:
                errors['email'] = email_validation['error']
        
        if user_data.get('password'):
            password_validation = self.validate_password(user_data['password'])
            if not password_validation['valid']:
                errors['password'] = password_validation['error']
        
        if user_data.get('phone_number'):
            phone_validation = self.validate_phone(user_data['phone_number'])
            if not phone_validation['valid']:
                errors['phone_number'] = phone_validation['error']
        
        # Confirm password match
        if user_data.get('password') != user_data.get('confirm_password'):
            errors['confirm_password'] = "Passwords do not match"
        
        return {
            "valid": len(errors) == 0,
            "errors": errors
        }
    
    def validate_email_content(self, email_data: Dict) -> Dict:
        '''Validate email content before sending'''
        errors = {}
        
        # Required fields
        if not email_data.get('recipients'):
            errors['recipients'] = "At least one recipient is required"
        elif not isinstance(email_data['recipients'], list) or len(email_data['recipients']) == 0:
            errors['recipients'] = "Recipients must be a non-empty list"
        
        if not email_data.get('subject'):
            errors['subject'] = "Subject is required"
        
        if not email_data.get('body') and not email_data.get('html_body'):
            errors['body'] = "Email body is required"
        
        # Validate recipient emails
        if email_data.get('recipients'):
            for i, recipient in enumerate(email_data['recipients']):
                email_validation = self.validate_email(recipient)
                if not email_validation['valid']:
                    errors[f'recipient_{i}'] = f"Invalid recipient email: {recipient}"
        
        # Validate CC emails
        if email_data.get('cc'):
            for i, cc_email in enumerate(email_data['cc']):
                email_validation = self.validate_email(cc_email)
                if not email_validation['valid']:
                    errors[f'cc_{i}'] = f"Invalid CC email: {cc_email}"
        
        # Check subject length
        if email_data.get('subject') and len(email_data['subject']) > 200:
            errors['subject'] = "Subject is too long (max 200 characters)"
        
        return {
            "valid": len(errors) == 0,
            "errors": errors
        }
    
    def sanitize_input(self, text: str, max_length: int = None) -> str:
        '''Sanitize text input'''
        if not text:
            return ''
        
        # Remove potentially harmful characters
        text = re.sub(r'[<>\"\'&]', '', text)
        
        # Trim whitespace
        text = text.strip()
        
        # Limit length
        if max_length and len(text) > max_length:
            text = text[:max_length]
        
        return text

# Global instance
validation_utils = ValidationUtils()
"""

# Write utility files
with open('DATAINTEG-MAILSERVER/backend/utils/file_utils.py', 'w') as f:
    f.write(file_utils_content)

with open('DATAINTEG-MAILSERVER/backend/utils/smtp_utils.py', 'w') as f:
    f.write(smtp_utils_content)

with open('DATAINTEG-MAILSERVER/backend/utils/validation_utils.py', 'w') as f:
    f.write(validation_utils_content)

# Utils __init__.py
utils_init_content = """
from .auth_utils import generate_jwt_token, decode_jwt_token, authenticate_user, require_auth, require_admin, require_role, get_current_user_from_token
from .email_utils import email_utils
from .file_utils import file_utils
from .smtp_utils import smtp_utils
from .validation_utils import validation_utils

__all__ = [
    'generate_jwt_token', 'decode_jwt_token', 'authenticate_user', 
    'require_auth', 'require_admin', 'require_role', 'get_current_user_from_token',
    'email_utils', 'file_utils', 'smtp_utils', 'validation_utils'
]
"""

with open('DATAINTEG-MAILSERVER/backend/utils/__init__.py', 'w') as f:
    f.write(utils_init_content)

print("✅ Created remaining utility files:")
print("  - file_utils.py")
print("  - smtp_utils.py") 
print("  - validation_utils.py")
print("  - __init__.py")