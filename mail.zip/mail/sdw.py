# Frontend App.js
app_js_content = """import { useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import '../styles/globals.css';

export default function App({ Component, pageProps }) {
  useEffect(() => {
    // Set page title
    document.title = 'DataInteg Mail Server';
  }, []);

  return (
    <>
      <Component {...pageProps} />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#323130',
            color: '#fff',
          },
          success: {
            duration: 3000,
            iconTheme: {
              primary: '#107c10',
              secondary: '#fff',
            },
          },
          error: {
            duration: 5000,
            iconTheme: {
              primary: '#d13438',
              secondary: '#fff',
            },
          },
        }}
      />
    </>
  );
}
"""

# Document.js
document_js_content = """import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta charSet="utf-8" />
        <meta name="description" content="Professional mail server for DataInteg - Secure, reliable email communication" />
        <meta name="keywords" content="email, mail server, professional, business, DataInteg" />
        <meta name="author" content="DataInteg Solutions" />
        
        {/* Favicons */}
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        
        {/* Fonts */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
        
        {/* PWA */}
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#0078d4" />
        
        {/* Microsoft Outlook Web App styling compatibility */}
        <meta name="format-detection" content="telephone=no" />
        <meta name="format-detection" content="date=no" />
        <meta name="format-detection" content="address=no" />
        <meta name="format-detection" content="email=no" />
      </Head>
      <body className="font-segoe bg-outlook-gray-50 text-outlook-gray-900 antialiased">
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
"""

# Index.js (redirect to login)
index_js_content = """import { useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function HomePage() {
  const router = useRouter();

  useEffect(() => {
    // Check if user is already logged in
    const token = document.cookie
      .split('; ')
      .find(row => row.startsWith('auth-token='))
      ?.split('=')[1];

    if (token) {
      // Redirect to mail if logged in
      router.push('/mail');
    } else {
      // Redirect to login if not logged in
      router.push('/login');
    }
  }, [router]);

  return (
    <>
      <Head>
        <title>DataInteg Mail Server</title>
      </Head>
      <div className="min-h-screen bg-outlook-blue flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin-slow w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading DataInteg Mail...</p>
        </div>
      </div>
    </>
  );
}
"""

# Login Page
login_js_content = """import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';

export default function LoginPage() {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // Check if user is already logged in
    const token = Cookies.get('auth-token');
    if (token) {
      router.push('/mail');
    }
  }, [router]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        // Store token and user data
        Cookies.set('auth-token', data.data.token, { expires: 30 });
        Cookies.set('user-data', JSON.stringify(data.data.user), { expires: 30 });
        
        // Welcome message
        const userRoles = data.data.user.roles?.join(', ') || 'User';
        toast.success(`Welcome ${data.data.user.display_name}! (${userRoles})`);
        
        // Redirect based on role
        if (data.data.user.roles?.includes('admin')) {
          router.push('/admin');
        } else {
          router.push('/mail');
        }
      } else {
        toast.error(data.error || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Connection error. Please check your network.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <>
      <Head>
        <title>Sign In - DataInteg Mail</title>
      </Head>
      
      <div className="min-h-screen bg-gradient-to-br from-outlook-blue to-outlook-darkblue flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full space-y-8">
          {/* Logo and Header */}
          <div className="text-center">
            <div className="mx-auto h-20 w-20 bg-white rounded-full flex items-center justify-center mb-6 shadow-outlook">
              <svg className="h-10 w-10 text-outlook-blue" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-white">
              Sign in to DataInteg Mail
            </h2>
            <p className="mt-2 text-outlook-lightblue">
              Secure professional email for your business
            </p>
          </div>

          {/* Login Form */}
          <div className="bg-white rounded-lg shadow-outlook-hover p-8">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-outlook-gray-900">
                  Username or Email
                </label>
                <div className="mt-1">
                  <input
                    id="username"
                    name="username"
                    type="text"
                    autoComplete="username"
                    required
                    value={formData.username}
                    onChange={handleInputChange}
                    className="appearance-none relative block w-full px-3 py-2 border border-outlook-gray-300 placeholder-outlook-gray-500 text-outlook-gray-900 rounded-md focus:outline-none focus:ring-outlook-blue focus:border-outlook-blue focus:z-10 sm:text-sm"
                    placeholder="Enter your username or email"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-outlook-gray-900">
                  Password
                </label>
                <div className="mt-1 relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    required
                    value={formData.password}
                    onChange={handleInputChange}
                    className="appearance-none relative block w-full px-3 py-2 pr-10 border border-outlook-gray-300 placeholder-outlook-gray-500 text-outlook-gray-900 rounded-md focus:outline-none focus:ring-outlook-blue focus:border-outlook-blue focus:z-10 sm:text-sm"
                    placeholder="Enter your password"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-outlook-gray-400 hover:text-outlook-gray-500 focus:outline-none focus:text-outlook-gray-500"
                    >
                      {showPassword ? (
                        <EyeSlashIcon className="h-5 w-5" aria-hidden="true" />
                      ) : (
                        <EyeIcon className="h-5 w-5" aria-hidden="true" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    className="h-4 w-4 text-outlook-blue focus:ring-outlook-blue border-outlook-gray-300 rounded"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-outlook-gray-900">
                    Remember me
                  </label>
                </div>

                <div className="text-sm">
                  <a
                    href="#"
                    className="font-medium text-outlook-blue hover:text-outlook-darkblue"
                  >
                    Forgot your password?
                  </a>
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  disabled={loading}
                  className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-outlook-blue hover:bg-outlook-darkblue focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-outlook-blue disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin-slow w-4 h-4 border border-white border-t-transparent rounded-full mr-2"></div>
                      Signing in...
                    </>
                  ) : (
                    'Sign in'
                  )}
                </button>
              </div>
            </form>

            {/* Help Section */}
            <div className="mt-6 pt-6 border-t border-outlook-gray-200">
              <div className="text-sm text-outlook-gray-600 text-center">
                <p>Need help accessing your account?</p>
                <p className="mt-1">Contact your IT administrator</p>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-outlook-lightblue text-sm">
            <p>&copy; 2025 DataInteg Solutions. All rights reserved.</p>
          </div>
        </div>
      </div>
    </>
  );
}
"""

# Write main frontend pages
with open('DATAINTEG-MAILSERVER/frontend/pages/_app.js', 'w') as f:
    f.write(app_js_content)

with open('DATAINTEG-MAILSERVER/frontend/pages/_document.js', 'w') as f:
    f.write(document_js_content)

with open('DATAINTEG-MAILSERVER/frontend/pages/index.js', 'w') as f:
    f.write(index_js_content)

with open('DATAINTEG-MAILSERVER/frontend/pages/login.js', 'w') as f:
    f.write(login_js_content)

print("✅ Created main frontend pages:")
print("  - _app.js")
print("  - _document.js") 
print("  - index.js")
print("  - login.js")