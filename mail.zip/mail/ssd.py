# Docker Compose Configuration
docker_compose_content = """version: '3.8'

services:
  # MongoDB Database
  mongodb:
    image: mongo:7.0
    container_name: datainteg_mongodb
    restart: unless-stopped
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: DataInteg@2025
      MONGO_INITDB_DATABASE: datainteg_mail
    ports:
      - "27017:27017"
    volumes:
      - mongodb_data:/data/db
      - ./backend/database/init.js:/docker-entrypoint-initdb.d/init.js:ro
    networks:
      - datainteg_network

  # Redis (Optional - for caching and rate limiting)
  redis:
    image: redis:7.2-alpine
    container_name: datainteg_redis
    restart: unless-stopped
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - datainteg_network

  # Backend Flask API
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: datainteg_backend
    restart: unless-stopped
    environment:
      - FLASK_ENV=production
      - MONGO_URI=mongodb://admin:DataInteg@2025@mongodb:27017/datainteg_mail?authSource=admin
      - REDIS_URL=redis://redis:6379
      - DOMAIN=datainteg.in
      - MAIL_SERVER=smtp.hostinger.com
      - MAIL_PORT=587
      - MAIL_USERNAME=noreply@datainteg.in
      - MAIL_PASSWORD=${MAIL_PASSWORD}
      - JWT_SECRET=${JWT_SECRET}
    ports:
      - "5000:5000"
    volumes:
      - ./backend/uploads:/app/uploads
      - ./backend/logs:/app/logs
    depends_on:
      - mongodb
      - redis
    networks:
      - datainteg_network

  # Frontend Next.js
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: datainteg_frontend
    restart: unless-stopped
    environment:
      - NEXT_PUBLIC_API_URL=https://datainteg.in/api
      - NEXT_PUBLIC_DOMAIN=datainteg.in
    ports:
      - "3000:3000"
    depends_on:
      - backend
    networks:
      - datainteg_network

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: datainteg_nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./deployment/nginx.conf:/etc/nginx/nginx.conf
      - ./deployment/ssl:/etc/nginx/ssl
      - ./frontend/public:/var/www/html/public
    depends_on:
      - frontend
      - backend
    networks:
      - datainteg_network

volumes:
  mongodb_data:
    driver: local
  redis_data:
    driver: local

networks:
  datainteg_network:
    driver: bridge
"""

# Backend Dockerfile
backend_dockerfile_content = """FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    gcc \\
    g++ \\
    libffi-dev \\
    libssl-dev \\
    default-libmysqlclient-dev \\
    pkg-config \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt .

# Install Python dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create necessary directories
RUN mkdir -p uploads logs

# Set permissions
RUN chmod +x app.py

# Expose port
EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:5000/api/health || exit 1

# Run the application
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "4", "--timeout", "120", "app:create_app()"]
"""

# Database Initialization Script
db_init_content = """// MongoDB initialization script
db = db.getSiblingDB('datainteg_mail');

// Create collections
db.createCollection('users');
db.createCollection('emails');
db.createCollection('mailboxes');
db.createCollection('attachments');
db.createCollection('domains');

// Create indexes
db.users.createIndex({ "username": 1 }, { unique: true });
db.users.createIndex({ "email": 1 }, { unique: true });
db.users.createIndex({ "employee_id": 1 }, { unique: true, sparse: true });
db.users.createIndex({ "roles": 1 });

db.emails.createIndex({ "user_id": 1, "folder": 1 });
db.emails.createIndex({ "user_id": 1, "created_at": -1 });
db.emails.createIndex({ "sender": 1 });
db.emails.createIndex({ "recipients": 1 });
db.emails.createIndex({ "subject": "text", "body": "text" });

db.mailboxes.createIndex({ "user_id": 1, "name": 1 }, { unique: true });

db.attachments.createIndex({ "email_id": 1 });

// Insert default domain
db.domains.insertOne({
    "domain": "datainteg.in",
    "is_active": true,
    "mx_records": [
        { "priority": 10, "server": "mail.datainteg.in" }
    ],
    "spf_record": "v=spf1 include:spf.hostinger.com ~all",
    "created_at": new Date()
});

// Create default admin user
db.users.insertOne({
    "username": "admin",
    "email": "admin@datainteg.in",
    "password": "$2b$12$LKF.HhO0qNjJZZ5V8V8KSeOKfS8vK8nO0.5P0bG0/vW8b9I4P1.8.", // Welcome@911
    "first_name": "System",
    "last_name": "Administrator",
    "display_name": "System Administrator",
    "roles": ["admin", "user"],
    "is_active": true,
    "employee_id": "ADMIN001",
    "department": "IT",
    "position": "System Administrator",
    "created_at": new Date(),
    "updated_at": new Date(),
    "mail_settings": {
        "signature": "Best regards,\\nSystem Administrator\\nDataInteg Solutions",
        "auto_reply": false,
        "forwarding_enabled": false
    }
});

print("Database initialized successfully!");
"""

# Nginx Configuration
nginx_conf_content = """events {
    worker_connections 1024;
}

http {
    upstream backend {
        server backend:5000;
    }

    upstream frontend {
        server frontend:3000;
    }

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=5r/s;

    # SSL Configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml;

    # Main server block for datainteg.in
    server {
        listen 80;
        server_name datainteg.in www.datainteg.in;
        
        # Redirect HTTP to HTTPS
        return 301 https://$server_name$request_uri;
    }

    server {
        listen 443 ssl http2;
        server_name datainteg.in www.datainteg.in;

        # SSL certificates (you'll need to add these)
        ssl_certificate /etc/nginx/ssl/datainteg.in.crt;
        ssl_certificate_key /etc/nginx/ssl/datainteg.in.key;

        # Security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header Referrer-Policy "no-referrer-when-downgrade" always;
        add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

        # Mail server frontend at /mailserver
        location /mailserver {
            proxy_pass http://frontend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
            
            # Rewrite to remove /mailserver prefix
            rewrite ^/mailserver/(.*) /$1 break;
        }

        # API endpoints
        location /api {
            limit_req zone=api burst=20 nodelay;
            
            proxy_pass http://backend;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # Handle preflight requests
            if ($request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' 'https://datainteg.in';
                add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'Authorization, Content-Type';
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                add_header 'Content-Length' 0;
                return 204;
            }
        }

        # Login rate limiting
        location /api/auth/login {
            limit_req zone=login burst=5 nodelay;
            proxy_pass http://backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Static files
        location /static {
            alias /var/www/html/public;
            expires 30d;
            add_header Cache-Control "public, immutable";
        }

        # Default location (main website)
        location / {
            root /var/www/html;
            index index.html;
            try_files $uri $uri/ /index.html;
            
            # Cache static assets
            location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
                expires 1y;
                add_header Cache-Control "public, immutable";
            }
        }

        # File upload size limit
        client_max_body_size 25M;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Health check endpoint
    server {
        listen 80;
        server_name health.datainteg.in;
        
        location /health {
            access_log off;
            return 200 "healthy\\n";
            add_header Content-Type text/plain;
        }
    }
}
"""

# Deployment Script
deploy_script_content = """#!/bin/bash

# DataInteg Mail Server Deployment Script

echo "🚀 Starting DataInteg Mail Server Deployment..."

# Colors for output
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
NC='\\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Create necessary directories
print_status "Creating necessary directories..."
mkdir -p ./backend/uploads
mkdir -p ./backend/logs
mkdir -p ./deployment/ssl
mkdir -p ./mongodb_data
mkdir -p ./redis_data

# Set permissions
chmod -R 755 ./backend/uploads
chmod -R 755 ./backend/logs

# Check if .env file exists
if [ ! -f .env ]; then
    print_warning ".env file not found. Creating from template..."
    cat > .env << EOF
# Mail Server Configuration
MAIL_PASSWORD=your_hostinger_email_password
JWT_SECRET=$(openssl rand -base64 32)

# MongoDB Configuration
MONGODB_ROOT_PASSWORD=DataInteg@2025

# SSL Configuration
SSL_CERT_PATH=./deployment/ssl/datainteg.in.crt
SSL_KEY_PATH=./deployment/ssl/datainteg.in.key
EOF
    print_warning "Please update the .env file with your actual credentials!"
fi

# Pull latest images
print_status "Pulling latest Docker images..."
docker-compose pull

# Build custom images
print_status "Building custom Docker images..."
docker-compose build --no-cache

# Stop existing containers
print_status "Stopping existing containers..."
docker-compose down

# Start services
print_status "Starting DataInteg Mail Server services..."
docker-compose up -d

# Wait for services to start
print_status "Waiting for services to initialize..."
sleep 30

# Check service health
print_status "Checking service health..."

# Check MongoDB
if docker exec datainteg_mongodb mongo --eval "db.adminCommand('ping')" > /dev/null 2>&1; then
    print_status "✅ MongoDB is healthy"
else
    print_error "❌ MongoDB is not responding"
fi

# Check Backend
if curl -f http://localhost:5000/api/health > /dev/null 2>&1; then
    print_status "✅ Backend API is healthy"
else
    print_error "❌ Backend API is not responding"
fi

# Check Frontend
if curl -f http://localhost:3000 > /dev/null 2>&1; then
    print_status "✅ Frontend is healthy"
else
    print_error "❌ Frontend is not responding"
fi

# Display service status
print_status "Service Status:"
docker-compose ps

# Display access URLs
echo ""
print_status "🎉 Deployment Complete!"
echo ""
echo "Access URLs:"
echo "  📧 Mail Server: https://datainteg.in/mailserver"
echo "  🔧 API Health:  http://localhost:5000/api/health"
echo "  🖥️  Frontend:    http://localhost:3000"
echo ""
echo "Default Admin Credentials:"
echo "  Username: admin"
echo "  Password: Welcome@911"
echo ""
print_warning "Remember to:"
echo "  1. Update your .env file with real credentials"
echo "  2. Configure SSL certificates in ./deployment/ssl/"
echo "  3. Update DNS settings to point to this server"
echo "  4. Configure your domain's MX records"
echo ""
"""

# SSL Setup Script
ssl_setup_content = """#!/bin/bash

# SSL Certificate Setup Script for DataInteg Mail Server

echo "🔒 Setting up SSL certificates for datainteg.in..."

# Colors for output
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
NC='\\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create SSL directory
mkdir -p ./deployment/ssl

# Check if Let's Encrypt is available (Certbot)
if command -v certbot &> /dev/null; then
    print_status "Using Let's Encrypt to generate SSL certificates..."
    
    # Generate certificates
    sudo certbot certonly --standalone \\
        -d datainteg.in \\
        -d www.datainteg.in \\
        -d mail.datainteg.in \\
        --agree-tos \\
        --register-unsafely-without-email
    
    # Copy certificates to deployment directory
    sudo cp /etc/letsencrypt/live/datainteg.in/fullchain.pem ./deployment/ssl/datainteg.in.crt
    sudo cp /etc/letsencrypt/live/datainteg.in/privkey.pem ./deployment/ssl/datainteg.in.key
    
    # Set permissions
    sudo chmod 644 ./deployment/ssl/datainteg.in.crt
    sudo chmod 600 ./deployment/ssl/datainteg.in.key
    sudo chown $(whoami):$(whoami) ./deployment/ssl/datainteg.in.*
    
    print_status "✅ Let's Encrypt SSL certificates generated successfully!"
    
else
    print_warning "Certbot not found. Generating self-signed certificates..."
    
    # Generate self-signed certificates
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \\
        -keyout ./deployment/ssl/datainteg.in.key \\
        -out ./deployment/ssl/datainteg.in.crt \\
        -subj "/C=IN/ST=Maharashtra/L=Mumbai/O=DataInteg/CN=datainteg.in"
    
    print_warning "⚠️  Self-signed certificates generated."
    print_warning "For production, please use proper SSL certificates from a CA."
fi

# Set up auto-renewal (for Let's Encrypt)
if command -v certbot &> /dev/null; then
    print_status "Setting up auto-renewal..."
    
    # Create renewal script
    cat > ./deployment/ssl/renew.sh << 'EOF'
#!/bin/bash
sudo certbot renew --quiet
sudo cp /etc/letsencrypt/live/datainteg.in/fullchain.pem ./deployment/ssl/datainteg.in.crt
sudo cp /etc/letsencrypt/live/datainteg.in/privkey.pem ./deployment/ssl/datainteg.in.key
sudo chown $(whoami):$(whoami) ./deployment/ssl/datainteg.in.*
docker-compose restart nginx
EOF
    
    chmod +x ./deployment/ssl/renew.sh
    
    # Add to crontab (runs every 12 hours)
    (crontab -l 2>/dev/null; echo "0 */12 * * * /path/to/your/project/deployment/ssl/renew.sh") | crontab -
    
    print_status "✅ Auto-renewal configured"
fi

print_status "🔒 SSL setup complete!"
echo ""
echo "Files created:"
echo "  🔐 Certificate: ./deployment/ssl/datainteg.in.crt"
echo "  🔑 Private Key: ./deployment/ssl/datainteg.in.key"
echo ""
"""

# Write Docker and deployment files
with open('DATAINTEG-MAILSERVER/docker-compose.yml', 'w') as f:
    f.write(docker_compose_content)

# Backend Dockerfile
backend_dockerfile_path = 'DATAINTEG-MAILSERVER/backend/Dockerfile'
with open(backend_dockerfile_path, 'w') as f:
    f.write(backend_dockerfile_content)

with open('DATAINTEG-MAILSERVER/backend/database/init.js', 'w') as f:
    f.write(db_init_content)

with open('DATAINTEG-MAILSERVER/deployment/nginx.conf', 'w') as f:
    f.write(nginx_conf_content)

with open('DATAINTEG-MAILSERVER/deployment/deploy.sh', 'w') as f:
    f.write(deploy_script_content)

with open('DATAINTEG-MAILSERVER/deployment/ssl-setup.sh', 'w') as f:
    f.write(ssl_setup_content)

# Make scripts executable
import stat
os.chmod('DATAINTEG-MAILSERVER/deployment/deploy.sh', stat.S_IRWXU | stat.S_IRGRP | stat.S_IROTH)
os.chmod('DATAINTEG-MAILSERVER/deployment/ssl-setup.sh', stat.S_IRWXU | stat.S_IRGRP | stat.S_IROTH)

print("✅ Created Docker and deployment files:")
print("  - docker-compose.yml")
print("  - backend/Dockerfile")
print("  - backend/database/init.js")
print("  - deployment/nginx.conf")
print("  - deployment/deploy.sh")
print("  - deployment/ssl-setup.sh")