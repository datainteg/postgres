# Authentication Routes
auth_routes_content = """
from flask import Blueprint, request, jsonify, current_app
from utils.auth_utils import authenticate_user, generate_jwt_token, require_auth
from utils.validation_utils import validation_utils
from models.user import User
from database.operations import db_ops
import logging

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    '''User login endpoint'''
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({"error": "Username and password are required"}), 400
        
        # Authenticate user
        auth_result = authenticate_user(username, password)
        
        if not auth_result['success']:
            return jsonify({"error": auth_result['error']}), 401
        
        logging.info(f"User logged in: {username}")
        
        return jsonify({
            "success": True,
            "message": auth_result['message'],
            "data": {
                "token": auth_result['token'],
                "user": auth_result['user']
            }
        }), 200
        
    except Exception as e:
        logging.error(f"Login error: {str(e)}")
        return jsonify({"error": "Login failed"}), 500

@auth_bp.route('/logout', methods=['POST'])
@require_auth
def logout():
    '''User logout endpoint'''
    try:
        # In a stateless JWT system, logout is handled client-side
        # But we can log the logout event
        current_user = getattr(request, 'current_user', {})
        username = current_user.get('username', 'unknown')
        
        logging.info(f"User logged out: {username}")
        
        return jsonify({
            "success": True,
            "message": "Logged out successfully"
        }), 200
        
    except Exception as e:
        logging.error(f"Logout error: {str(e)}")
        return jsonify({"error": "Logout failed"}), 500

@auth_bp.route('/verify', methods=['GET'])
@require_auth
def verify_token():
    '''Verify JWT token'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        return jsonify({
            "success": True,
            "message": "Token is valid",
            "data": {
                "user": current_user
            }
        }), 200
        
    except Exception as e:
        logging.error(f"Token verification error: {str(e)}")
        return jsonify({"error": "Token verification failed"}), 500

@auth_bp.route('/change-password', methods=['PUT'])
@require_auth
def change_password():
    '''Change user password'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        confirm_password = data.get('confirm_password')
        
        if not all([current_password, new_password, confirm_password]):
            return jsonify({"error": "All password fields are required"}), 400
        
        if new_password != confirm_password:
            return jsonify({"error": "New passwords do not match"}), 400
        
        # Verify current password
        if not User.verify_password(current_password, current_user.get('password', '')):
            return jsonify({"error": "Current password is incorrect"}), 401
        
        # Validate new password
        password_validation = validation_utils.validate_password(new_password)
        if not password_validation['valid']:
            return jsonify({"error": password_validation['error']}), 400
        
        # Hash new password
        hashed_password = User.hash_password(new_password)
        
        # Update password
        success = db_ops.update_user(current_user['_id'], {'password': hashed_password})
        
        if success:
            logging.info(f"Password changed for user: {current_user.get('username')}")
            return jsonify({
                "success": True,
                "message": "Password changed successfully"
            }), 200
        else:
            return jsonify({"error": "Failed to update password"}), 500
        
    except Exception as e:
        logging.error(f"Password change error: {str(e)}")
        return jsonify({"error": "Password change failed"}), 500

@auth_bp.route('/profile', methods=['GET'])
@require_auth
def get_profile():
    '''Get user profile'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        # Remove sensitive information
        profile_data = {k: v for k, v in current_user.items() if k != 'password'}
        
        return jsonify({
            "success": True,
            "data": profile_data
        }), 200
        
    except Exception as e:
        logging.error(f"Get profile error: {str(e)}")
        return jsonify({"error": "Failed to get profile"}), 500

@auth_bp.route('/profile', methods=['PUT'])
@require_auth
def update_profile():
    '''Update user profile'''
    try:
        current_user = getattr(request, 'current_user', {})
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Fields that can be updated by user
        updatable_fields = [
            'first_name', 'last_name', 'phone_number', 'emergency_contact',
            'mail_settings', 'timezone', 'language'
        ]
        
        update_data = {}
        for field in updatable_fields:
            if field in data:
                if field == 'phone_number' and data[field]:
                    phone_validation = validation_utils.validate_phone(data[field])
                    if not phone_validation['valid']:
                        return jsonify({"error": phone_validation['error']}), 400
                    update_data[field] = phone_validation.get('normalized', data[field])
                else:
                    update_data[field] = data[field]
        
        # Update display name if first or last name changed
        if 'first_name' in update_data or 'last_name' in update_data:
            first_name = update_data.get('first_name', current_user.get('first_name', ''))
            last_name = update_data.get('last_name', current_user.get('last_name', ''))
            update_data['display_name'] = f"{first_name} {last_name}".strip()
        
        if not update_data:
            return jsonify({"error": "No valid fields to update"}), 400
        
        success = db_ops.update_user(current_user['_id'], update_data)
        
        if success:
            # Get updated user data
            updated_user = db_ops.get_user_by_id(current_user['_id'])
            updated_user.pop('password', None)
            
            logging.info(f"Profile updated for user: {current_user.get('username')}")
            
            return jsonify({
                "success": True,
                "message": "Profile updated successfully",
                "data": updated_user
            }), 200
        else:
            return jsonify({"error": "Failed to update profile"}), 500
        
    except Exception as e:
        logging.error(f"Update profile error: {str(e)}")
        return jsonify({"error": "Profile update failed"}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    '''Forgot password - Send reset email'''
    try:
        data = request.get_json()
        
        if not data or not data.get('email'):
            return jsonify({"error": "Email is required"}), 400
        
        email = data.get('email')
        
        # Validate email
        email_validation = validation_utils.validate_email(email)
        if not email_validation['valid']:
            return jsonify({"error": "Invalid email format"}), 400
        
        # Check if user exists
        user = db_ops.get_user_by_email(email)
        if not user:
            # Don't reveal if email exists or not for security
            return jsonify({
                "success": True,
                "message": "If the email exists, a reset link has been sent"
            }), 200
        
        # TODO: Implement password reset token generation and email sending
        # For now, just log the request
        logging.info(f"Password reset requested for: {email}")
        
        return jsonify({
            "success": True,
            "message": "If the email exists, a reset link has been sent"
        }), 200
        
    except Exception as e:
        logging.error(f"Forgot password error: {str(e)}")
        return jsonify({"error": "Forgot password request failed"}), 500

@auth_bp.route('/health', methods=['GET'])
def auth_health():
    '''Auth service health check'''
    try:
        return jsonify({
            "status": "healthy",
            "service": "authentication",
            "endpoints": [
                "POST /api/auth/login",
                "POST /api/auth/logout", 
                "GET /api/auth/verify",
                "PUT /api/auth/change-password",
                "GET /api/auth/profile",
                "PUT /api/auth/profile",
                "POST /api/auth/forgot-password"
            ]
        }), 200
        
    except Exception as e:
        return jsonify({"status": "unhealthy", "error": str(e)}), 500
"""

# Admin Routes
admin_routes_content = """
from flask import Blueprint, request, jsonify, current_app
from utils.auth_utils import require_admin, require_auth
from utils.validation_utils import validation_utils
from utils.email_utils import email_utils
from models.user import User
from database.operations import db_ops
import logging

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/users', methods=['GET'])
@require_admin
def get_all_users():
    '''Get all users (admin only)'''
    try:
        # Get pagination parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        skip = (page - 1) * limit
        
        # Get search and filter parameters
        search = request.args.get('search', '').strip()
        department = request.args.get('department', '').strip()
        role = request.args.get('role', '').strip()
        status = request.args.get('status', '').strip()
        
        users = db_ops.get_all_users(skip=skip, limit=limit)
        
        # Apply filters (basic filtering - could be moved to database level)
        if search:
            users = [u for u in users if search.lower() in u.get('username', '').lower() 
                    or search.lower() in u.get('email', '').lower()
                    or search.lower() in u.get('display_name', '').lower()]
        
        if department:
            users = [u for u in users if u.get('department', '').lower() == department.lower()]
        
        if role:
            users = [u for u in users if role in u.get('roles', [])]
        
        if status == 'active':
            users = [u for u in users if u.get('is_active', True)]
        elif status == 'inactive':
            users = [u for u in users if not u.get('is_active', True)]
        
        return jsonify({
            "success": True,
            "data": {
                "users": users,
                "pagination": {
                    "page": page,
                    "limit": limit,
                    "total": len(users)
                }
            }
        }), 200
        
    except Exception as e:
        logging.error(f"Get all users error: {str(e)}")
        return jsonify({"error": "Failed to retrieve users"}), 500

@admin_bp.route('/users', methods=['POST'])
@require_admin
def create_user():
    '''Create new user (admin only)'''
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Validate user data
        validation_result = validation_utils.validate_user_registration(data)
        if not validation_result['valid']:
            return jsonify({"error": "Validation failed", "details": validation_result['errors']}), 400
        
        # Check if user already exists
        existing_user = db_ops.get_user_by_username(data.get('username'))
        if existing_user:
            return jsonify({"error": "Username already exists"}), 409
        
        existing_email = db_ops.get_user_by_email(data.get('email'))
        if existing_email:
            return jsonify({"error": "Email already exists"}), 409
        
        # Create user data
        user_data = User.create_user_data(data)
        
        # Admin can set additional fields
        admin_fields = ['roles', 'employee_id', 'department', 'position', 'is_active']
        for field in admin_fields:
            if field in data:
                user_data[field] = data[field]
        
        # Create user
        result = db_ops.create_user(user_data)
        
        if result['success']:
            # Send welcome email
            try:
                welcome_email = email_utils.create_welcome_email(user_data)
                email_utils.send_email(
                    sender=welcome_email['sender'],
                    recipients=welcome_email['recipients'],
                    subject=welcome_email['subject'],
                    body=welcome_email['body'],
                    html_body=welcome_email['html_body']
                )
            except Exception as email_error:
                logging.error(f"Failed to send welcome email: {str(email_error)}")
            
            current_user = getattr(request, 'current_user', {})
            logging.info(f"User created by admin {current_user.get('username')}: {data.get('username')}")
            
            # Remove password from response
            result['data'].pop('password', None)
            
            return jsonify({
                "success": True,
                "message": "User created successfully",
                "data": result['data']
            }), 201
        else:
            return jsonify({"error": result['error']}), 500
        
    except Exception as e:
        logging.error(f"Create user error: {str(e)}")
        return jsonify({"error": "Failed to create user"}), 500

@admin_bp.route('/users/<user_id>', methods=['GET'])
@require_admin
def get_user(user_id):
    '''Get user by ID (admin only)'''
    try:
        user = db_ops.get_user_by_id(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        return jsonify({
            "success": True,
            "data": user
        }), 200
        
    except Exception as e:
        logging.error(f"Get user error: {str(e)}")
        return jsonify({"error": "Failed to retrieve user"}), 500

@admin_bp.route('/users/<user_id>', methods=['PUT'])
@require_admin
def update_user(user_id):
    '''Update user (admin only)'''
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Check if user exists
        existing_user = db_ops.get_user_by_id(user_id)
        if not existing_user:
            return jsonify({"error": "User not found"}), 404
        
        # Fields that admin can update
        admin_updatable_fields = [
            'first_name', 'last_name', 'email', 'phone_number', 'roles',
            'is_active', 'employee_id', 'department', 'position', 
            'joining_date', 'reporting_manager', 'work_location',
            'emergency_contact', 'mail_settings'
        ]
        
        update_data = {}
        for field in admin_updatable_fields:
            if field in data:
                if field == 'email' and data[field] != existing_user.get('email'):
                    # Validate new email
                    email_validation = validation_utils.validate_email(data[field])
                    if not email_validation['valid']:
                        return jsonify({"error": email_validation['error']}), 400
                    
                    # Check if email already exists
                    existing_email = db_ops.get_user_by_email(data[field])
                    if existing_email and existing_email['_id'] != user_id:
                        return jsonify({"error": "Email already exists"}), 409
                
                update_data[field] = data[field]
        
        # Handle password update separately
        if 'password' in data:
            password_validation = validation_utils.validate_password(data['password'])
            if not password_validation['valid']:
                return jsonify({"error": password_validation['error']}), 400
            
            update_data['password'] = User.hash_password(data['password'])
        
        # Update display name if first or last name changed
        if 'first_name' in update_data or 'last_name' in update_data:
            first_name = update_data.get('first_name', existing_user.get('first_name', ''))
            last_name = update_data.get('last_name', existing_user.get('last_name', ''))
            update_data['display_name'] = f"{first_name} {last_name}".strip()
        
        if not update_data:
            return jsonify({"error": "No valid fields to update"}), 400
        
        success = db_ops.update_user(user_id, update_data)
        
        if success:
            # Get updated user
            updated_user = db_ops.get_user_by_id(user_id)
            
            current_user = getattr(request, 'current_user', {})
            logging.info(f"User updated by admin {current_user.get('username')}: {existing_user.get('username')}")
            
            return jsonify({
                "success": True,
                "message": "User updated successfully",
                "data": updated_user
            }), 200
        else:
            return jsonify({"error": "Failed to update user"}), 500
        
    except Exception as e:
        logging.error(f"Update user error: {str(e)}")
        return jsonify({"error": "Failed to update user"}), 500

@admin_bp.route('/users/<user_id>', methods=['DELETE'])
@require_admin
def delete_user(user_id):
    '''Delete user (admin only) - Soft delete by deactivating'''
    try:
        # Check if user exists
        existing_user = db_ops.get_user_by_id(user_id)
        if not existing_user:
            return jsonify({"error": "User not found"}), 404
        
        # Don't allow deleting other admins
        if 'admin' in existing_user.get('roles', []):
            current_user = getattr(request, 'current_user', {})
            if current_user.get('_id') != user_id:
                return jsonify({"error": "Cannot delete other admin users"}), 403
        
        # Soft delete - deactivate user
        success = db_ops.update_user(user_id, {'is_active': False})
        
        if success:
            current_user = getattr(request, 'current_user', {})
            logging.info(f"User deactivated by admin {current_user.get('username')}: {existing_user.get('username')}")
            
            return jsonify({
                "success": True,
                "message": "User deactivated successfully"
            }), 200
        else:
            return jsonify({"error": "Failed to deactivate user"}), 500
        
    except Exception as e:
        logging.error(f"Delete user error: {str(e)}")
        return jsonify({"error": "Failed to delete user"}), 500

@admin_bp.route('/stats', methods=['GET'])
@require_admin
def get_admin_stats():
    '''Get admin dashboard statistics'''
    try:
        all_users = db_ops.get_all_users(limit=1000)  # Get more users for stats
        
        total_users = len(all_users)
        active_users = len([u for u in all_users if u.get('is_active', True)])
        admin_users = len([u for u in all_users if 'admin' in u.get('roles', [])])
        
        # Department distribution
        departments = {}
        for user in all_users:
            dept = user.get('department', 'Unknown')
            departments[dept] = departments.get(dept, 0) + 1
        
        # Recent registrations (last 7 days)
        from datetime import datetime, timedelta
        week_ago = datetime.now() - timedelta(days=7)
        recent_users = [
            u for u in all_users 
            if u.get('created_at') and isinstance(u.get('created_at'), str)
            and datetime.fromisoformat(u['created_at'].replace('Z', '+00:00')) > week_ago
        ]
        
        stats = {
            "users": {
                "total": total_users,
                "active": active_users,
                "inactive": total_users - active_users,
                "admins": admin_users,
                "recent": len(recent_users)
            },
            "departments": departments,
            "system": {
                "status": "healthy",
                "uptime": "N/A"  # Could implement actual uptime tracking
            }
        }
        
        return jsonify({
            "success": True,
            "data": stats
        }), 200
        
    except Exception as e:
        logging.error(f"Get admin stats error: {str(e)}")
        return jsonify({"error": "Failed to retrieve statistics"}), 500

@admin_bp.route('/health', methods=['GET'])
@require_admin
def admin_health():
    '''Admin service health check'''
    try:
        current_user = getattr(request, 'current_user', {})
        
        return jsonify({
            "status": "healthy",
            "service": "admin",
            "admin_user": current_user.get('username'),
            "endpoints": [
                "GET /api/admin/users",
                "POST /api/admin/users", 
                "GET /api/admin/users/<id>",
                "PUT /api/admin/users/<id>",
                "DELETE /api/admin/users/<id>",
                "GET /api/admin/stats"
            ]
        }), 200
        
    except Exception as e:
        return jsonify({"status": "unhealthy", "error": str(e)}), 500
"""

# Write API route files
with open('DATAINTEG-MAILSERVER/backend/api/auth_routes.py', 'w') as f:
    f.write(auth_routes_content)

with open('DATAINTEG-MAILSERVER/backend/api/admin_routes.py', 'w') as f:
    f.write(admin_routes_content)

print("✅ Created API route files:")
print("  - auth_routes.py")
print("  - admin_routes.py")