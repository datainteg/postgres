# Create directory structure first
import os

# Create missing directories
os.makedirs('DATAINTEG-MAILSERVER/frontend/pages/mail', exist_ok=True)
os.makedirs('DATAINTEG-MAILSERVER/frontend/pages/admin', exist_ok=True)
os.makedirs('DATAINTEG-MAILSERVER/frontend/pages/api/auth', exist_ok=True)
os.makedirs('DATAINTEG-MAILSERVER/frontend/components/Layout', exist_ok=True)
os.makedirs('DATAINTEG-MAILSERVER/frontend/components/Auth', exist_ok=True)
os.makedirs('DATAINTEG-MAILSERVER/frontend/components/Mail', exist_ok=True)
os.makedirs('DATAINTEG-MAILSERVER/frontend/components/Admin', exist_ok=True)

# Mail Index Page
mail_index_content = """import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Cookies from 'js-cookie';
import toast from 'react-hot-toast';
import OutlookLayout from '../../components/Layout/OutlookLayout';
import Sidebar from '../../components/Mail/Sidebar';
import MailList from '../../components/Mail/MailList';
import MailViewer from '../../components/Mail/MailViewer';
import ComposeModal from '../../components/Mail/ComposeModal';

export default function MailPage() {
  const [user, setUser] = useState(null);
  const [selectedFolder, setSelectedFolder] = useState('INBOX');
  const [emails, setEmails] = useState([]);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [showCompose, setShowCompose] = useState(false);
  const [loading, setLoading] = useState(true);
  const [folders, setFolders] = useState([]);
  const router = useRouter();

  useEffect(() => {
    checkAuth();
    loadFolders();
  }, []);

  useEffect(() => {
    if (user && selectedFolder) {
      loadEmails();
    }
  }, [user, selectedFolder]);

  const checkAuth = async () => {
    try {
      const token = Cookies.get('auth-token');
      const userData = Cookies.get('user-data');

      if (!token || !userData) {
        router.push('/login');
        return;
      }

      const user = JSON.parse(userData);
      setUser(user);

      // Verify token is still valid
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/verify`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        Cookies.remove('auth-token');
        Cookies.remove('user-data');
        router.push('/login');
        return;
      }

      setLoading(false);
    } catch (error) {
      console.error('Auth check failed:', error);
      router.push('/login');
    }
  };

  const loadFolders = async () => {
    try {
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/mail/folders`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setFolders(data.data || []);
      }
    } catch (error) {
      console.error('Failed to load folders:', error);
    }
  };

  const loadEmails = async () => {
    try {
      setLoading(true);
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/mail/folders/${selectedFolder}/emails`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setEmails(data.data.emails || []);
      } else {
        toast.error('Failed to load emails');
      }
    } catch (error) {
      console.error('Failed to load emails:', error);
      toast.error('Failed to load emails');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSelect = async (email) => {
    setSelectedEmail(email);
    
    // Mark as read if not already
    if (!email.is_read) {
      try {
        const token = Cookies.get('auth-token');
        await fetch(`${process.env.NEXT_PUBLIC_API_URL}/mail/emails/${email._id}/read`, {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        
        // Update local state
        setEmails(prev => prev.map(e => 
          e._id === email._id ? { ...e, is_read: true } : e
        ));
      } catch (error) {
        console.error('Failed to mark email as read:', error);
      }
    }
  };

  const handleLogout = () => {
    Cookies.remove('auth-token');
    Cookies.remove('user-data');
    toast.success('Logged out successfully');
    router.push('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-outlook-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin-slow w-8 h-8 border-2 border-outlook-blue border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-outlook-gray-600">Loading your mail...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Head>
        <title>Mail - DataInteg</title>
      </Head>
      
      <OutlookLayout user={user} onLogout={handleLogout}>
        <div className="flex h-full">
          <Sidebar
            user={user}
            folders={folders}
            selectedFolder={selectedFolder}
            onFolderSelect={setSelectedFolder}
            onCompose={() => setShowCompose(true)}
            onRefresh={loadEmails}
          />
          
          <MailList
            emails={emails}
            loading={loading}
            selectedEmail={selectedEmail}
            onEmailSelect={handleEmailSelect}
            folder={selectedFolder}
            onRefresh={loadEmails}
          />
          
          <MailViewer
            email={selectedEmail}
            onClose={() => setSelectedEmail(null)}
            onReply={() => {
              setShowCompose(true);
            }}
          />
        </div>

        {showCompose && (
          <ComposeModal
            user={user}
            onClose={() => setShowCompose(false)}
            onSent={() => {
              setShowCompose(false);
              if (selectedFolder === 'SENT') {
                loadEmails();
              }
              toast.success('Email sent successfully!');
            }}
            replyTo={selectedEmail}
          />
        )}
      </OutlookLayout>
    </>
  );
}
"""

# Admin Index Page
admin_index_content = """import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Cookies from 'js-cookie';
import toast from 'react-hot-toast';
import AdminLayout from '../../components/Layout/AdminLayout';
import UserManagement from '../../components/Admin/UserManagement';
import UserOnboarding from '../../components/Admin/UserOnboarding';
import DashboardStats from '../../components/Admin/DashboardStats';

export default function AdminPage() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const router = useRouter();

  useEffect(() => {
    checkAdminAuth();
  }, []);

  useEffect(() => {
    if (user && activeTab === 'dashboard') {
      loadStats();
    }
  }, [user, activeTab]);

  const checkAdminAuth = async () => {
    try {
      const token = Cookies.get('auth-token');
      const userData = Cookies.get('user-data');

      if (!token || !userData) {
        router.push('/login');
        return;
      }

      const user = JSON.parse(userData);
      
      // Check admin role
      if (!user.roles?.includes('admin')) {
        toast.error('Access denied. Admin privileges required.');
        router.push('/mail');
        return;
      }

      setUser(user);

      // Verify token
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/verify`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        Cookies.remove('auth-token');
        Cookies.remove('user-data');
        router.push('/login');
        return;
      }

      setLoading(false);
    } catch (error) {
      console.error('Admin auth check failed:', error);
      router.push('/login');
    }
  };

  const loadStats = async () => {
    try {
      const token = Cookies.get('auth-token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/stats`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setStats(data.data);
      }
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleLogout = () => {
    Cookies.remove('auth-token');
    Cookies.remove('user-data');
    toast.success('Logged out successfully');
    router.push('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-outlook-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin-slow w-8 h-8 border-2 border-outlook-blue border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-outlook-gray-600">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'dashboard', name: 'Dashboard', icon: '📊' },
    { id: 'users', name: 'Manage Users', icon: '👥' },
    { id: 'onboard', name: 'Onboard User', icon: '➕' },
  ];

  return (
    <>
      <Head>
        <title>Admin Panel - DataInteg</title>
      </Head>
      
      <AdminLayout user={user} onLogout={handleLogout}>
        <div className="flex h-full">
          {/* Admin Sidebar */}
          <div className="w-64 bg-white border-r border-outlook-gray-200 flex flex-col">
            <div className="p-4 border-b border-outlook-gray-200">
              <h2 className="text-lg font-semibold text-outlook-gray-900">Admin Panel</h2>
              <p className="text-sm text-outlook-gray-600">Manage your mail server</p>
            </div>
            
            <nav className="flex-1 p-4">
              <ul className="space-y-2">
                {tabs.map((tab) => (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors \\${
                        activeTab === tab.id
                          ? 'bg-outlook-blue text-white'
                          : 'text-outlook-gray-700 hover:bg-outlook-gray-100'
                      }`}
                    >
                      <span className="mr-3">{tab.icon}</span>
                      {tab.name}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
            
            {/* Quick Actions */}
            <div className="p-4 border-t border-outlook-gray-200">
              <button
                onClick={() => router.push('/mail')}
                className="w-full flex items-center px-4 py-2 text-sm font-medium text-outlook-gray-700 hover:bg-outlook-gray-100 rounded-lg transition-colors"
              >
                <span className="mr-3">📧</span>
                Go to Mail
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-hidden">
            {activeTab === 'dashboard' && (
              <DashboardStats stats={stats} onRefresh={loadStats} />
            )}
            {activeTab === 'users' && (
              <UserManagement />
            )}
            {activeTab === 'onboard' && (
              <UserOnboarding onSuccess={() => {
                setActiveTab('users');
                toast.success('User onboarded successfully!');
              }} />
            )}
          </div>
        </div>
      </AdminLayout>
    </>
  );
}
"""

# Write mail and admin pages
with open('DATAINTEG-MAILSERVER/frontend/pages/mail/index.js', 'w') as f:
    f.write(mail_index_content)

with open('DATAINTEG-MAILSERVER/frontend/pages/admin/index.js', 'w') as f:
    f.write(admin_index_content)

print("✅ Created mail and admin pages:")
print("  - pages/mail/index.js")
print("  - pages/admin/index.js")