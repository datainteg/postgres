# Database Connection
db_connection_content = """
import os
import logging
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from flask import current_app

# Global database connection
db = None
client = None

def init_db():
    '''Initialize database connection'''
    global db, client
    
    try:
        mongo_uri = os.getenv('MONGO_URI', 'mongodb://admin:DataInteg@2025@localhost:27017/datainteg_mail?authSource=admin')
        db_name = os.getenv('MONGO_DB_NAME', 'datainteg_mail')
        
        # Create MongoDB client
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
        
        # Test connection
        client.admin.command('ismaster')
        
        # Get database
        db = client[db_name]
        
        # Create indexes for better performance
        create_indexes()
        
        logging.info(f"Successfully connected to MongoDB: {db_name}")
        return True
        
    except (ConnectionFailure, ServerSelectionTimeoutError) as e:
        logging.error(f"Failed to connect to MongoDB: {str(e)}")
        return False

def get_db():
    '''Get database instance'''
    global db
    if db is None:
        init_db()
    return db

def close_db():
    '''Close database connection'''
    global client
    if client:
        client.close()
        logging.info("MongoDB connection closed")

def create_indexes():
    '''Create database indexes for better performance'''
    global db
    if db is None:
        return
        
    try:
        # Users collection indexes
        db.users.create_index("username", unique=True)
        db.users.create_index("email", unique=True)
        db.users.create_index("employee_id", unique=True, sparse=True)
        db.users.create_index([("roles", 1)])
        
        # Emails collection indexes
        db.emails.create_index([("user_id", 1), ("folder", 1)])
        db.emails.create_index([("user_id", 1), ("created_at", -1)])
        db.emails.create_index([("sender", 1)])
        db.emails.create_index([("recipients", 1)])
        db.emails.create_index([("subject", "text"), ("body", "text")])
        
        # Mailboxes collection indexes
        db.mailboxes.create_index([("user_id", 1), ("name", 1)], unique=True)
        
        # Attachments collection indexes
        db.attachments.create_index([("email_id", 1)])
        db.attachments.create_index([("filename", 1)])
        
        # Domains collection indexes
        db.domains.create_index("domain", unique=True)
        
        logging.info("Database indexes created successfully")
        
    except Exception as e:
        logging.error(f"Error creating indexes: {str(e)}")

# Database health check
def check_db_health():
    '''Check database health'''
    try:
        global db
        if db is None:
            return False
            
        # Simple ping to check connection
        db.command('ping')
        return True
        
    except Exception as e:
        logging.error(f"Database health check failed: {str(e)}")
        return False
"""

# Database Operations
db_operations_content = """
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from bson import ObjectId
from pymongo.errors import DuplicateKeyError
from database.connection import get_db

class DatabaseOperations:
    def __init__(self):
        self.db = get_db()
    
    # User Operations
    def create_user(self, user_data: Dict) -> Dict:
        '''Create a new user'''
        try:
            user_data['created_at'] = datetime.now(timezone.utc)
            user_data['updated_at'] = datetime.now(timezone.utc)
            
            result = self.db.users.insert_one(user_data)
            user_data['_id'] = result.inserted_id
            
            # Create default mailbox folders
            self.create_default_mailboxes(result.inserted_id)
            
            logging.info(f"Created user: {user_data.get('username')}")
            return {"success": True, "user_id": str(result.inserted_id), "data": user_data}
            
        except DuplicateKeyError as e:
            logging.error(f"Duplicate user creation attempt: {str(e)}")
            return {"success": False, "error": "User already exists"}
        except Exception as e:
            logging.error(f"Error creating user: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_user_by_username(self, username: str) -> Optional[Dict]:
        '''Get user by username'''
        try:
            user = self.db.users.find_one({"username": username})
            if user:
                user['_id'] = str(user['_id'])
            return user
        except Exception as e:
            logging.error(f"Error getting user by username: {str(e)}")
            return None
    
    def get_user_by_email(self, email: str) -> Optional[Dict]:
        '''Get user by email'''
        try:
            user = self.db.users.find_one({"email": email})
            if user:
                user['_id'] = str(user['_id'])
            return user
        except Exception as e:
            logging.error(f"Error getting user by email: {str(e)}")
            return None
    
    def get_user_by_id(self, user_id: str) -> Optional[Dict]:
        '''Get user by ID'''
        try:
            user = self.db.users.find_one({"_id": ObjectId(user_id)})
            if user:
                user['_id'] = str(user['_id'])
            return user
        except Exception as e:
            logging.error(f"Error getting user by ID: {str(e)}")
            return None
    
    def update_user(self, user_id: str, update_data: Dict) -> bool:
        '''Update user'''
        try:
            update_data['updated_at'] = datetime.now(timezone.utc)
            result = self.db.users.update_one(
                {"_id": ObjectId(user_id)}, 
                {"$set": update_data}
            )
            return result.modified_count > 0
        except Exception as e:
            logging.error(f"Error updating user: {str(e)}")
            return False
    
    def get_all_users(self, skip: int = 0, limit: int = 100) -> List[Dict]:
        '''Get all users (admin function)'''
        try:
            users = list(self.db.users.find(
                {}, 
                {"password": 0}  # Exclude password
            ).skip(skip).limit(limit).sort("created_at", -1))
            
            for user in users:
                user['_id'] = str(user['_id'])
            
            return users
        except Exception as e:
            logging.error(f"Error getting all users: {str(e)}")
            return []
    
    # Email Operations
    def create_email(self, email_data: Dict) -> Dict:
        '''Create a new email'''
        try:
            email_data['created_at'] = datetime.now(timezone.utc)
            email_data['updated_at'] = datetime.now(timezone.utc)
            email_data['is_read'] = False
            
            result = self.db.emails.insert_one(email_data)
            email_data['_id'] = str(result.inserted_id)
            
            logging.info(f"Created email: {email_data.get('subject')}")
            return {"success": True, "email_id": str(result.inserted_id), "data": email_data}
            
        except Exception as e:
            logging.error(f"Error creating email: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_emails_by_user_and_folder(self, user_id: str, folder: str, skip: int = 0, limit: int = 50) -> List[Dict]:
        '''Get emails by user and folder'''
        try:
            emails = list(self.db.emails.find(
                {"user_id": ObjectId(user_id), "folder": folder}
            ).skip(skip).limit(limit).sort("created_at", -1))
            
            for email in emails:
                email['_id'] = str(email['_id'])
                email['user_id'] = str(email['user_id'])
            
            return emails
        except Exception as e:
            logging.error(f"Error getting emails: {str(e)}")
            return []
    
    def get_email_by_id(self, email_id: str) -> Optional[Dict]:
        '''Get email by ID'''
        try:
            email = self.db.emails.find_one({"_id": ObjectId(email_id)})
            if email:
                email['_id'] = str(email['_id'])
                email['user_id'] = str(email['user_id'])
            return email
        except Exception as e:
            logging.error(f"Error getting email by ID: {str(e)}")
            return None
    
    def mark_email_as_read(self, email_id: str, user_id: str) -> bool:
        '''Mark email as read'''
        try:
            result = self.db.emails.update_one(
                {"_id": ObjectId(email_id), "user_id": ObjectId(user_id)},
                {"$set": {"is_read": True, "read_at": datetime.now(timezone.utc)}}
            )
            return result.modified_count > 0
        except Exception as e:
            logging.error(f"Error marking email as read: {str(e)}")
            return False
    
    def move_email_to_folder(self, email_id: str, folder: str, user_id: str) -> bool:
        '''Move email to different folder'''
        try:
            result = self.db.emails.update_one(
                {"_id": ObjectId(email_id), "user_id": ObjectId(user_id)},
                {"$set": {"folder": folder, "updated_at": datetime.now(timezone.utc)}}
            )
            return result.modified_count > 0
        except Exception as e:
            logging.error(f"Error moving email: {str(e)}")
            return False
    
    # Mailbox Operations
    def create_default_mailboxes(self, user_id: ObjectId) -> bool:
        '''Create default mailboxes for a new user'''
        try:
            default_folders = [
                {"name": "INBOX", "display_name": "Inbox", "count": 0},
                {"name": "SENT", "display_name": "Sent", "count": 0},
                {"name": "DRAFTS", "display_name": "Drafts", "count": 0},
                {"name": "SPAM", "display_name": "Spam", "count": 0},
                {"name": "TRASH", "display_name": "Trash", "count": 0}
            ]
            
            for folder in default_folders:
                folder['user_id'] = user_id
                folder['created_at'] = datetime.now(timezone.utc)
            
            self.db.mailboxes.insert_many(default_folders)
            logging.info(f"Created default mailboxes for user: {user_id}")
            return True
            
        except Exception as e:
            logging.error(f"Error creating default mailboxes: {str(e)}")
            return False
    
    def get_user_mailboxes(self, user_id: str) -> List[Dict]:
        '''Get user mailboxes'''
        try:
            mailboxes = list(self.db.mailboxes.find({"user_id": ObjectId(user_id)}))
            for mailbox in mailboxes:
                mailbox['_id'] = str(mailbox['_id'])
                mailbox['user_id'] = str(mailbox['user_id'])
            return mailboxes
        except Exception as e:
            logging.error(f"Error getting user mailboxes: {str(e)}")
            return []
    
    # Attachment Operations
    def save_attachment(self, attachment_data: Dict) -> Dict:
        '''Save attachment metadata'''
        try:
            attachment_data['created_at'] = datetime.now(timezone.utc)
            result = self.db.attachments.insert_one(attachment_data)
            attachment_data['_id'] = str(result.inserted_id)
            
            return {"success": True, "attachment_id": str(result.inserted_id), "data": attachment_data}
        except Exception as e:
            logging.error(f"Error saving attachment: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_email_attachments(self, email_id: str) -> List[Dict]:
        '''Get attachments for an email'''
        try:
            attachments = list(self.db.attachments.find({"email_id": ObjectId(email_id)}))
            for attachment in attachments:
                attachment['_id'] = str(attachment['_id'])
                attachment['email_id'] = str(attachment['email_id'])
            return attachments
        except Exception as e:
            logging.error(f"Error getting email attachments: {str(e)}")
            return []

# Global instance
db_ops = DatabaseOperations()
"""

# Write database files
with open('DATAINTEG-MAILSERVER/backend/database/connection.py', 'w') as f:
    f.write(db_connection_content)

with open('DATAINTEG-MAILSERVER/backend/database/operations.py', 'w') as f:
    f.write(db_operations_content)

# Database __init__.py
with open('DATAINTEG-MAILSERVER/backend/database/__init__.py', 'w') as f:
    f.write("from .connection import init_db, get_db, close_db\nfrom .operations import db_ops")

print("✅ Created database modules:")
print("  - connection.py")
print("  - operations.py")
print("  - __init__.py")