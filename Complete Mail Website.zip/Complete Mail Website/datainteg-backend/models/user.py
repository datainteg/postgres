from datetime import datetime
from bson import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash
import re

class User:
    """User model with role-based authentication"""
    
    def __init__(self, username, email, password, display_name=None, 
                 roles=None, is_active=True, created_at=None):
        self.username = username
        self.email = email.lower()
        self.password_hash = generate_password_hash(password) if password else None
        self.display_name = display_name or username
        self.roles = roles or ['user']  # Default role is 'user'
        self.is_active = is_active
        self.created_at = created_at or datetime.utcnow()
        self.last_login = None
        
    def check_password(self, password):
        """Check if provided password matches user's password"""
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)
        
    def has_role(self, role):
        """Check if user has specific role"""
        return role in self.roles
        
    def add_role(self, role):
        """Add role to user"""
        if role not in self.roles:
            self.roles.append(role)
            
    def remove_role(self, role):
        """Remove role from user"""
        if role in self.roles and len(self.roles) > 1:  # Keep at least one role
            self.roles.remove(role)
            
    def to_dict(self):
        """Convert user object to dictionary"""
        return {
            'username': self.username,
            'email': self.email,
            'password_hash': self.password_hash,
            'display_name': self.display_name,
            'roles': self.roles,
            'is_active': self.is_active,
            'created_at': self.created_at,
            'last_login': self.last_login
        }
    
    @staticmethod
    def from_dict(data):
        """Create user object from dictionary"""
        user = User(
            username=data['username'],
            email=data['email'],
            password=None,
            display_name=data.get('display_name'),
            roles=data.get('roles', ['user']),
            is_active=data.get('is_active', True),
            created_at=data.get('created_at')
        )
        user.password_hash = data.get('password_hash')
        user.last_login = data.get('last_login')
        return user

class UserManager:
    """Enhanced user manager with role management"""
    
    def __init__(self, db):
        self.db = db
        self.collection = db.users
        
    def create_indexes(self):
        """Create database indexes for users"""
        self.collection.create_index('username', unique=True)
        self.collection.create_index('email', unique=True)
        self.collection.create_index('roles')
        
    def create_user(self, username, email, password, display_name=None, roles=None):
        """Create a new user with roles"""
        # Validation
        if len(username) < 3:
            raise ValueError("Username must be at least 3 characters")
        if len(password) < 6:
            raise ValueError("Password must be at least 6 characters")
            
        # Check if user exists
        if self.get_user_by_username(username):
            raise ValueError("Username already exists")
        if self.get_user_by_email(email):
            raise ValueError("Email already exists")
            
        # Create user
        user = User(
            username=username,
            email=email,
            password=password,
            display_name=display_name,
            roles=roles or ['user']
        )
        
        result = self.collection.insert_one(user.to_dict())
        return str(result.inserted_id)
        
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        try:
            user_data = self.collection.find_one({'_id': ObjectId(user_id)})
            if user_data:
                return User.from_dict(user_data)
            return None
        except:
            return None
            
    def get_user_by_username(self, username):
        """Get user by username"""
        user_data = self.collection.find_one({'username': username})
        if user_data:
            return User.from_dict(user_data)
        return None
        
    def authenticate_user(self, username_or_email, password):
        """Authenticate user by username/email and password"""
        user = self.get_user_by_username(username_or_email)
        if not user:
            user = self.get_user_by_email(username_or_email)
            
        if user and user.is_active and user.check_password(password):
            return user
        return None
        
    def update_user_password(self, user_id, new_password):
        """Update user password"""
        password_hash = generate_password_hash(new_password)
        self.collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': {'password_hash': password_hash}}
        )
        
    def update_user_roles(self, user_id, roles):
        """Update user roles"""
        self.collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': {'roles': roles}}
        )
        
    def get_all_users(self, skip=0, limit=50):
        """Get all users with pagination"""
        cursor = self.collection.find().skip(skip).limit(limit)
        return [User.from_dict(user_data) for user_data in cursor]
        
    def delete_user(self, user_id):
        """Delete user by ID"""
        self.collection.delete_one({'_id': ObjectId(user_id)})
