from datetime import datetime
from bson import ObjectId
import uuid

class Email:
    """Email model for storing email messages"""
    
    def __init__(self, message_id, sender, recipients, subject, body, 
                 html_body=None, attachments=None, folder='INBOX', 
                 is_read=False, is_starred=False, created_at=None):
        self.message_id = message_id or str(uuid.uuid4())
        self.sender = sender
        self.recipients = recipients if isinstance(recipients, list) else [recipients]
        self.subject = subject
        self.body = body
        self.html_body = html_body
        self.attachments = attachments or []
        self.folder = folder
        self.is_read = is_read
        self.is_starred = is_starred
        self.is_deleted = False
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
    def to_dict(self):
        """Convert email object to dictionary"""
        return {
            'message_id': self.message_id,
            'sender': self.sender,
            'recipients': self.recipients,
            'subject': self.subject,
            'body': self.body,
            'html_body': self.html_body,
            'attachments': self.attachments,
            'folder': self.folder,
            'is_read': self.is_read,
            'is_starred': self.is_starred,
            'is_deleted': self.is_deleted,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
    
    @staticmethod
    def from_dict(data):
        """Create email object from dictionary"""
        email = Email(
            message_id=data.get('message_id'),
            sender=data.get('sender'),
            recipients=data.get('recipients', []),
            subject=data.get('subject'),
            body=data.get('body'),
            html_body=data.get('html_body'),
            attachments=data.get('attachments', []),
            folder=data.get('folder', 'INBOX'),
            is_read=data.get('is_read', False),
            is_starred=data.get('is_starred', False),
            created_at=data.get('created_at')
        )
        email.is_deleted = data.get('is_deleted', False)
        email.updated_at = data.get('updated_at', datetime.utcnow())
        return email

class EmailManager:
    """Manager class for email operations"""
    
    def __init__(self, db):
        self.db = db
        self.collection = db.emails
        
    def create_indexes(self):
        """Create database indexes for emails"""
        self.collection.create_index('message_id', unique=True)
        self.collection.create_index('sender')
        self.collection.create_index('recipients')
        self.collection.create_index('created_at')
        self.collection.create_index([('sender', 1), ('created_at', -1)])
        self.collection.create_index([('recipients', 1), ('created_at', -1)])
        self.collection.create_index([('subject', 'text'), ('body', 'text')])
        
    def store_email(self, message_id, sender, recipients, subject, body, 
                   html_body=None, attachments=None):
        """Store a new email"""
        email = Email(
            message_id=message_id,
            sender=sender,
            recipients=recipients,
            subject=subject,
            body=body,
            html_body=html_body,
            attachments=attachments
        )
        
        result = self.collection.insert_one(email.to_dict())
        return str(result.inserted_id)
        
    def get_email_by_id(self, email_id):
        """Get email by ID"""
        try:
            email_data = self.collection.find_one({'_id': ObjectId(email_id)})
            if email_data:
                return Email.from_dict(email_data)
            return None
        except:
            return None
            
    def get_user_emails(self, user_email, folder='INBOX', skip=0, limit=50, search=None):
        """Get emails for a user"""
        query = {
            'is_deleted': False
        }
        
        # Folder-based filtering
        if folder == 'INBOX':
            query['recipients'] = {'$in': [user_email]}
            query['folder'] = 'INBOX'
        elif folder == 'SENT':
            query['sender'] = user_email
        elif folder == 'DRAFTS':
            query['sender'] = user_email
            query['folder'] = 'DRAFTS'
        elif folder == 'SPAM':
            query['recipients'] = {'$in': [user_email]}
            query['folder'] = 'SPAM'
        elif folder == 'TRASH':
            query['$or'] = [
                {'sender': user_email, 'folder': 'TRASH'},
                {'recipients': {'$in': [user_email]}, 'folder': 'TRASH'}
            ]
            
        # Search functionality
        if search:
            query['$and'] = [
                query,
                {
                    '$or': [
                        {'subject': {'$regex': search, '$options': 'i'}},
                        {'body': {'$regex': search, '$options': 'i'}},
                        {'sender': {'$regex': search, '$options': 'i'}}
                    ]
                }
            ]
            
        cursor = self.collection.find(query).sort('created_at', -1).skip(skip).limit(limit)
        return [Email.from_dict(email_data) for email_data in cursor]
        
    def get_folder_counts(self, user_email):
        """Get email counts for each folder"""
        counts = {}
        
        # Inbox count
        counts['inbox'] = self.collection.count_documents({
            'recipients': {'$in': [user_email]},
            'folder': 'INBOX',
            'is_deleted': False
        })
        
        # Sent count
        counts['sent'] = self.collection.count_documents({
            'sender': user_email,
            'folder': {'$ne': 'DRAFTS'},
            'is_deleted': False
        })
        
        # Drafts count
        counts['drafts'] = self.collection.count_documents({
            'sender': user_email,
            'folder': 'DRAFTS',
            'is_deleted': False
        })
        
        # Spam count
        counts['spam'] = self.collection.count_documents({
            'recipients': {'$in': [user_email]},
            'folder': 'SPAM',
            'is_deleted': False
        })
        
        # Trash count
        counts['trash'] = self.collection.count_documents({
            '$or': [
                {'sender': user_email, 'folder': 'TRASH'},
                {'recipients': {'$in': [user_email]}, 'folder': 'TRASH'}
            ]
        })
        
        return counts
        
    def mark_as_read(self, email_id):
        """Mark email as read"""
        self.collection.update_one(
            {'_id': ObjectId(email_id)},
            {'$set': {'is_read': True, 'updated_at': datetime.utcnow()}}
        )
        
    def mark_as_starred(self, email_id, starred=True):
        """Mark email as starred/unstarred"""
        self.collection.update_one(
            {'_id': ObjectId(email_id)},
            {'$set': {'is_starred': starred, 'updated_at': datetime.utcnow()}}
        )
        
    def move_to_folder(self, email_id, folder):
        """Move email to a specific folder"""
        self.collection.update_one(
            {'_id': ObjectId(email_id)},
            {'$set': {'folder': folder, 'updated_at': datetime.utcnow()}}
        )
        
    def delete_email(self, email_id, permanent=False):
        """Delete email (move to trash or permanent)"""
        if permanent:
            self.collection.delete_one({'_id': ObjectId(email_id)})
        else:
            self.collection.update_one(
                {'_id': ObjectId(email_id)},
                {'$set': {'folder': 'TRASH', 'updated_at': datetime.utcnow()}}
            )
