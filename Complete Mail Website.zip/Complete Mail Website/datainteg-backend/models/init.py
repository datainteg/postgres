"""
DataInteg Email Server - Database Models

This module contains all the database models for the email server.
Models are designed to work with MongoDB and include proper validation.
"""

from .user import User, UserManager
from .email import Email, EmailManager
from .attachment import Attachment, AttachmentManager
from .domain import Domain, DomainManager
from .folder import Folder, FolderManager

__all__ = [
    'User', 'UserManager',
    'Email', 'EmailManager', 
    'Attachment', 'AttachmentManager',
    'Domain', 'DomainManager',
    'Folder', 'FolderManager'
]
