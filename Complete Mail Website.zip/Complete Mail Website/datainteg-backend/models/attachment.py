from datetime import datetime
from bson import ObjectId
import gridfs

class Attachment:
    """Attachment model for file handling"""
    
    def __init__(self, filename, file_data, content_type, size, 
                 user_id, email_id=None, created_at=None):
        self.filename = filename
        self.content_type = content_type
        self.size = size
        self.user_id = user_id
        self.email_id = email_id
        self.created_at = created_at or datetime.utcnow()
        self.file_data = file_data
        
    def to_dict(self):
        """Convert attachment to dictionary (without file data)"""
        return {
            'filename': self.filename,
            'content_type': self.content_type,
            'size': self.size,
            'user_id': self.user_id,
            'email_id': self.email_id,
            'created_at': self.created_at
        }

class AttachmentManager:
    """Manager class for file attachments using GridFS"""
    
    def __init__(self, db):
        self.db = db
        self.fs = gridfs.GridFS(db)
        
    def store_attachment(self, filename, file_data, content_type, user_id, email_id=None):
        """Store file attachment in GridFS"""
        file_id = self.fs.put(
            file_data,
            filename=filename,
            content_type=content_type,
            user_id=user_id,
            email_id=email_id,
            upload_date=datetime.utcnow()
        )
        
        return str(file_id)
        
    def get_attachment(self, file_id):
        """Get attachment file from GridFS"""
        try:
            grid_out = self.fs.get(ObjectId(file_id))
            return {
                'filename': grid_out.filename,
                'content_type': grid_out.content_type,
                'data': grid_out.read(),
                'size': grid_out.length,
                'upload_date': grid_out.upload_date
            }
        except gridfs.errors.NoFile:
            return None
        except:
            return None
            
    def delete_attachment(self, file_id):
        """Delete attachment from GridFS"""
        try:
            self.fs.delete(ObjectId(file_id))
            return True
        except:
            return False
            
    def get_user_attachments(self, user_id, skip=0, limit=50):
        """Get all attachments for a user"""
        files = self.fs.find({'user_id': user_id}).skip(skip).limit(limit)
        attachments = []
        
        for file in files:
            attachments.append({
                'file_id': str(file._id),
                'filename': file.filename,
                'content_type': file.content_type,
                'size': file.length,
                'upload_date': file.upload_date,
                'user_id': file.user_id,
                'email_id': file.email_id
            })
            
        return attachments
        
    def get_storage_usage(self, user_id):
        """Get total storage usage for a user"""
        pipeline = [
            {'$match': {'user_id': user_id}},
            {'$group': {'_id': None, 'total_size': {'$sum': '$length'}}}
        ]
        
        result = list(self.fs._GridFS__files.aggregate(pipeline))
        if result:
            return result[0]['total_size'] / (1024 * 1024)  # Convert to MB
        return 0.0
