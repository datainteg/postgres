from datetime import datetime
from bson import ObjectId

class Folder:
    """Email folder model"""
    
    def __init__(self, name, user_id, folder_type='custom', created_at=None):
        self.name = name
        self.user_id = user_id
        self.folder_type = folder_type  # system, custom
        self.created_at = created_at or datetime.utcnow()
        self.email_count = 0
        
    def to_dict(self):
        """Convert folder to dictionary"""
        return {
            'name': self.name,
            'user_id': self.user_id,
            'folder_type': self.folder_type,
            'created_at': self.created_at,
            'email_count': self.email_count
        }
    
    @staticmethod
    def from_dict(data):
        """Create folder from dictionary"""
        folder = Folder(
            name=data['name'],
            user_id=data['user_id'],
            folder_type=data.get('folder_type', 'custom'),
            created_at=data.get('created_at')
        )
        folder.email_count = data.get('email_count', 0)
        return folder

class FolderManager:
    """Manager for folder operations"""
    
    def __init__(self, db):
        self.db = db
        self.collection = db.folders
        
    def create_indexes(self):
        """Create indexes for folders"""
        self.collection.create_index([('user_id', 1), ('name', 1)], unique=True)
        
    def create_default_folders(self, user_id):
        """Create default system folders for a user"""
        default_folders = [
            Folder('INBOX', user_id, 'system'),
            Folder('SENT', user_id, 'system'),
            Folder('DRAFTS', user_id, 'system'),
            Folder('SPAM', user_id, 'system'),
            Folder('TRASH', user_id, 'system')
        ]
        
        for folder in default_folders:
            try:
                self.collection.insert_one(folder.to_dict())
            except:
                pass  # Folder already exists
                
    def create_folder(self, name, user_id):
        """Create a custom folder"""
        folder = Folder(name, user_id)
        result = self.collection.insert_one(folder.to_dict())
        return str(result.inserted_id)
        
    def get_user_folders(self, user_id):
        """Get all folders for a user"""
        cursor = self.collection.find({'user_id': user_id})
        return [Folder.from_dict(data) for data in cursor]
        
    def update_folder_count(self, user_id, folder_name, count):
        """Update email count for a folder"""
        self.collection.update_one(
            {'user_id': user_id, 'name': folder_name},
            {'$set': {'email_count': count}}
        )
