from datetime import datetime
from bson import ObjectId

class Domain:
    """Domain model for email domain management"""
    
    def __init__(self, domain_name, is_active=True, created_at=None):
        self.domain_name = domain_name.lower()
        self.is_active = is_active
        self.created_at = created_at or datetime.utcnow()
        self.mx_records = []
        self.dkim_enabled = False
        self.spf_record = f"v=spf1 include:{domain_name} ~all"
        
    def to_dict(self):
        """Convert domain to dictionary"""
        return {
            'domain_name': self.domain_name,
            'is_active': self.is_active,
            'created_at': self.created_at,
            'mx_records': self.mx_records,
            'dkim_enabled': self.dkim_enabled,
            'spf_record': self.spf_record
        }
    
    @staticmethod
    def from_dict(data):
        """Create domain from dictionary"""
        domain = Domain(
            domain_name=data['domain_name'],
            is_active=data.get('is_active', True),
            created_at=data.get('created_at')
        )
        domain.mx_records = data.get('mx_records', [])
        domain.dkim_enabled = data.get('dkim_enabled', False)
        domain.spf_record = data.get('spf_record', f"v=spf1 include:{domain.domain_name} ~all")
        return domain

class DomainManager:
    """Manager for domain operations"""
    
    def __init__(self, db):
        self.db = db
        self.collection = db.domains
        
    def create_indexes(self):
        """Create indexes for domains"""
        self.collection.create_index('domain_name', unique=True)
        
    def add_domain(self, domain_name):
        """Add a new domain"""
        domain = Domain(domain_name)
        result = self.collection.insert_one(domain.to_dict())
        return str(result.inserted_id)
        
    def get_domain(self, domain_name):
        """Get domain by name"""
        data = self.collection.find_one({'domain_name': domain_name.lower()})
        if data:
            return Domain.from_dict(data)
        return None
        
    def get_all_domains(self):
        """Get all domains"""
        cursor = self.collection.find()
        return [Domain.from_dict(data) for data in cursor]
        
    def update_domain(self, domain_name, **kwargs):
        """Update domain settings"""
        self.collection.update_one(
            {'domain_name': domain_name.lower()},
            {'$set': kwargs}
        )
        
    def is_valid_domain(self, email):
        """Check if email domain is valid"""
        domain = email.split('@')[1].lower()
        domain_obj = self.get_domain(domain)
        return domain_obj and domain_obj.is_active
