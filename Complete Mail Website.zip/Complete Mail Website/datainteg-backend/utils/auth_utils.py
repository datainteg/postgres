import jwt
from datetime import datetime, timedelta
from config import Config
import logging

logger = logging.getLogger(__name__)

def generate_jwt_token_with_roles(user_id, roles, config=None):
    """Generate JWT token with roles"""
    try:
        if config is None:
            config = Config()
            
        payload = {
            'user_id': str(user_id),
            'roles': roles,
            'iat': datetime.utcnow(),
            'exp': datetime.utcnow() + config.JWT_EXPIRATION_DELTA
        }
        
        token = jwt.encode(
            payload,
            config.JWT_SECRET_KEY,
            algorithm=config.JWT_ALGORITHM
        )
        
        return token
    except Exception as e:
        logger.error(f"Error generating JWT token with roles: {str(e)}")
        return None

def verify_jwt_token_with_roles(token, config=None):
    """Verify JWT token and return user ID and roles"""
    try:
        if config is None:
            config = Config()
            
        payload = jwt.decode(
            token,
            config.JWT_SECRET_KEY,
            algorithms=[config.JWT_ALGORITHM]
        )
        
        return payload.get('user_id'), payload.get('roles', [])
    except jwt.ExpiredSignatureError:
        logger.warning("JWT token has expired")
        return None, None
    except jwt.InvalidTokenError as e:
        logger.warning(f"Invalid JWT token: {str(e)}")
        return None, None
    except Exception as e:
        logger.error(f"Error verifying JWT token: {str(e)}")
        return None, None
