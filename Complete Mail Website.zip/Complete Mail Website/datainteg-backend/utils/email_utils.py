import re
import html
import email
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import logging

logger = logging.getLogger(__name__)

def validate_email_address(email_addr):
    """Validate email address format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email_addr) is not None

def parse_email_content(raw_email):
    """Parse raw email content"""
    try:
        msg = email.message_from_string(raw_email)
        
        parsed = {
            'sender': msg.get('From', ''),
            'recipients': msg.get('To', '').split(','),
            'subject': msg.get('Subject', ''),
            'date': msg.get('Date', ''),
            'message_id': msg.get('Message-ID', ''),
            'body': '',
            'html_body': '',
            'attachments': []
        }
        
        # Parse body
        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                if content_type == 'text/plain':
                    parsed['body'] = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                elif content_type == 'text/html':
                    parsed['html_body'] = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                elif part.get_filename():
                    # Attachment
                    parsed['attachments'].append({
                        'filename': part.get_filename(),
                        'content_type': content_type,
                        'data': part.get_payload(decode=True)
                    })
        else:
            parsed['body'] = msg.get_payload(decode=True).decode('utf-8', errors='ignore')
            
        return parsed
    except Exception as e:
        logger.error(f"Error parsing email: {str(e)}")
        return None

def format_email_for_frontend(email_doc):
    """Format email document for frontend consumption"""
    try:
        formatted = {
            'id': str(email_doc.get('_id', '')),
            'message_id': email_doc.get('message_id', ''),
            'sender': email_doc.get('sender', ''),
            'recipients': email_doc.get('recipients', []),
            'subject': email_doc.get('subject', ''),
            'body': email_doc.get('body', ''),
            'html_body': email_doc.get('html_body', ''),
            'attachments': email_doc.get('attachments', []),
            'folder': email_doc.get('folder', 'INBOX'),
            'is_read': email_doc.get('is_read', False),
            'is_starred': email_doc.get('is_starred', False),
            'created_at': email_doc.get('created_at', datetime.utcnow()).isoformat(),
            'updated_at': email_doc.get('updated_at', datetime.utcnow()).isoformat()
        }
        
        return formatted
    except Exception as e:
        logger.error(f"Error formatting email for frontend: {str(e)}")
        return {}

def sanitize_email_content(content):
    """Sanitize email content for safe display"""
    try:
        # Remove potentially dangerous HTML tags
        dangerous_tags = ['script', 'iframe', 'object', 'embed', 'form']
        
        for tag in dangerous_tags:
            content = re.sub(f'<{tag}.*?</{tag}>', '', content, flags=re.IGNORECASE | re.DOTALL)
            
        # Escape HTML entities
        content = html.escape(content, quote=False)
        
        return content
    except Exception as e:
        logger.error(f"Error sanitizing email content: {str(e)}")
        return content

def create_email_message(sender, recipients, subject, body, html_body=None, attachments=None):
    """Create email message object"""
    try:
        if html_body or attachments:
            msg = MIMEMultipart('alternative')
        else:
            msg = MIMEText(body, 'plain', 'utf-8')
            msg['From'] = sender
            msg['To'] = ', '.join(recipients) if isinstance(recipients, list) else recipients
            msg['Subject'] = subject
            return msg
            
        msg['From'] = sender
        msg['To'] = ', '.join(recipients) if isinstance(recipients, list) else recipients
        msg['Subject'] = subject
        
        # Add text part
        if body:
            text_part = MIMEText(body, 'plain', 'utf-8')
            msg.attach(text_part)
            
        # Add HTML part
        if html_body:
            html_part = MIMEText(html_body, 'html', 'utf-8')
            msg.attach(html_part)
            
        # Add attachments
        if attachments:
            for attachment in attachments:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment['data'])
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename= {attachment["filename"]}'
                )
                msg.attach(part)
                
        return msg
    except Exception as e:
        logger.error(f"Error creating email message: {str(e)}")
        return None

def extract_email_addresses(text):
    """Extract email addresses from text"""
    pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    return re.findall(pattern, text)

def clean_email_address(email_addr):
    """Clean and normalize email address"""
    if not email_addr:
        return ''
        
    # Remove whitespace and convert to lowercase
    email_addr = email_addr.strip().lower()
    
    # Extract email from "Name <email@domain.com>" format
    match = re.search(r'<([^>]+)>', email_addr)
    if match:
        email_addr = match.group(1)
        
    return email_addr

def generate_message_id(domain='datainteg.com'):
    """Generate unique message ID"""
    import uuid
    return f"{uuid.uuid4()}@{domain}"

def is_valid_mime_type(mime_type):
    """Check if MIME type is allowed"""
    allowed_types = [
        'text/', 'image/', 'application/pdf', 'application/msword',
        'application/vnd.ms-excel', 'application/vnd.ms-powerpoint',
        'application/zip', 'application/x-zip-compressed'
    ]
    
    return any(mime_type.startswith(allowed) for allowed in allowed_types)
