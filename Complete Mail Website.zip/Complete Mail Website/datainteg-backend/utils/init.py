"""
DataInteg Email Server - Utilities Module

This module contains utility functions for authentication, email processing,
file handling, and other common operations.
"""

from .auth_utils import (
    generate_jwt_token,
    verify_jwt_token, 
    hash_password,
    verify_password
)
from .email_utils import (
    parse_email_content,
    format_email_for_frontend,
    validate_email_address,
    sanitize_email_content
)
from .file_utils import (
    validate_file_upload,
    get_file_size_mb,
    get_file_extension,
    is_allowed_file_type
)

__all__ = [
    'generate_jwt_token', 'verify_jwt_token', 'hash_password', 'verify_password',
    'parse_email_content', 'format_email_for_frontend', 'validate_email_address', 'sanitize_email_content',
    'validate_file_upload', 'get_file_size_mb', 'get_file_extension', 'is_allowed_file_type'
]
