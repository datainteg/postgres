import os
import magic
import mimetypes
from werkzeug.utils import secure_filename
import logging

logger = logging.getLogger(__name__)

def validate_file_upload(file, max_size_mb=100):
    """Validate uploaded file"""
    try:
        # Check if file exists
        if not file or not file.filename:
            return False, "No file selected"
            
        # Check file size
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(0)  # Reset file pointer
        
        if size > max_size_mb * 1024 * 1024:
            return False, f"File too large. Maximum size is {max_size_mb}MB"
            
        # Check file extension
        filename = secure_filename(file.filename)
        if not is_allowed_file_type(filename):
            return False, "File type not allowed"
            
        return True, "File is valid"
    except Exception as e:
        logger.error(f"Error validating file: {str(e)}")
        return False, "File validation error"

def get_file_size_mb(file):
    """Get file size in MB"""
    try:
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(0)  # Reset file pointer
        return round(size / (1024 * 1024), 2)
    except Exception as e:
        logger.error(f"Error getting file size: {str(e)}")
        return 0

def get_file_extension(filename):
    """Get file extension"""
    try:
        return os.path.splitext(filename)[1].lower()
    except Exception as e:
        logger.error(f"Error getting file extension: {str(e)}")
        return ''

def is_allowed_file_type(filename):
    """Check if file type is allowed"""
    allowed_extensions = {
        '.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
        '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff',
        '.zip', '.rar', '.7z', '.tar', '.gz',
        '.mp3', '.mp4', '.avi', '.mkv', '.mov',
        '.csv', '.json', '.xml', '.yml', '.yaml'
    }
    
    ext = get_file_extension(filename)
    return ext in allowed_extensions

def get_mime_type(file_path):
    """Get MIME type of file"""
    try:
        mime_type, _ = mimetypes.guess_type(file_path)
        if not mime_type:
            # Try using python-magic if available
            try:
                mime_type = magic.from_file(file_path, mime=True)
            except:
                mime_type = 'application/octet-stream'
        return mime_type
    except Exception as e:
        logger.error(f"Error getting MIME type: {str(e)}")
        return 'application/octet-stream'

def sanitize_filename(filename):
    """Sanitize filename for safe storage"""
    try:
        # Use werkzeug's secure_filename
        filename = secure_filename(filename)
        
        # Additional sanitization
        filename = filename.replace(' ', '_')
        filename = re.sub(r'[^\w\-_\.]', '', filename)
        
        return filename
    except Exception as e:
        logger.error(f"Error sanitizing filename: {str(e)}")
        return 'unknown_file'

def format_file_size(size_bytes):
    """Format file size in human readable format"""
    try:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"
    except Exception as e:
        logger.error(f"Error formatting file size: {str(e)}")
        return "Unknown size"

def create_upload_folder(path):
    """Create upload folder if it doesn't exist"""
    try:
        os.makedirs(path, exist_ok=True)
        return True
    except Exception as e:
        logger.error(f"Error creating upload folder: {str(e)}")
        return False

def delete_file(file_path):
    """Safely delete file"""
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        return False
    except Exception as e:
        logger.error(f"Error deleting file: {str(e)}")
        return False

def get_file_info(file):
    """Get comprehensive file information"""
    try:
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(0)
        
        info = {
            'filename': secure_filename(file.filename),
            'size_bytes': size,
            'size_mb': round(size / (1024 * 1024), 2),
            'extension': get_file_extension(file.filename),
            'mime_type': file.content_type or 'application/octet-stream',
            'is_allowed': is_allowed_file_type(file.filename)
        }
        
        return info
    except Exception as e:
        logger.error(f"Error getting file info: {str(e)}")
        return {}
