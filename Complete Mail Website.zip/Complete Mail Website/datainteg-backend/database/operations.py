import logging
from datetime import datetime
from bson import ObjectId
from models.user import UserManager
from models.email import EmailManager
from models.attachment import AttachmentManager
from models.domain import DomainManager
from models.folder import FolderManager

logger = logging.getLogger(__name__)

class DatabaseOperations:
    """Centralized database operations for the email server"""
    
    def __init__(self, database=None):
        if database is None:
            from .connection import get_database
            database = get_database()
            
        self.db = database
        
        # Initialize managers
        self.user_manager = UserManager(database)
        self.email_manager = EmailManager(database)
        self.attachment_manager = AttachmentManager(database)
        self.domain_manager = DomainManager(database)
        self.folder_manager = FolderManager(database)
        
    def create_indexes(self):
        """Create all database indexes"""
        try:
            logger.info("Creating database indexes...")
            
            self.user_manager.create_indexes()
            self.email_manager.create_indexes()
            self.domain_manager.create_indexes()
            self.folder_manager.create_indexes()
            
            logger.info("Database indexes created successfully")
            return True
        except Exception as e:
            logger.error(f"Error creating indexes: {str(e)}")
            return False
            
    # def create_default_users(self):
    #     """Create default admin and demo users"""
    #     try:
    #         logger.info("Creating default users...")
            
    #         # Check if admin user exists
    #         admin_user = self.user_manager.get_user_by_username('admin')
    #         if not admin_user:
    #             self.user_manager.create_user(
    #                 username='admin',
    #                 email='admin@datainteg.com',
    #                 password='admin123',
    #                 display_name='Administrator',
    #                 is_admin=True
    #             )
    #             logger.info("Created admin user: admin/admin123")
                
    #         # Check if support user exists
    #         support_user = self.user_manager.get_user_by_username('support')
    #         if not support_user:
    #             self.user_manager.create_user(
    #                 username='support',
    #                 email='support@datainteg.com',
    #                 password='support123',
    #                 display_name='Support Team',
    #                 is_admin=False
    #             )
    #             logger.info("Created support user: support/support123")
                
    #         return True
    #     except Exception as e:
    #         logger.error(f"Error creating default users: {str(e)}")
    #         return False


    def create_default_users(self):
        """Create default admin and developer users"""
        try:
            logger.info("Creating default users...")
            
            # Create admin user
            admin_user = self.user_manager.get_user_by_username('admin')
            if not admin_user:
                self.user_manager.create_user(
                    username='admin',
                    email='admin@datainteg.com',
                    password='Welcome@911',
                    display_name='System Administrator',
                    roles=['admin']
                )
                logger.info("Created admin user: admin / Welcome@911")
                
            # Create developer user
            developer_user = self.user_manager.get_user_by_username('developer')
            if not developer_user:
                self.user_manager.create_user(
                    username='developer',
                    email='developer@datainteg.com',
                    password='Welcome@911',
                    display_name='Developer User',
                    roles=['developer']
                )
                logger.info("Created developer user: developer / Welcome@911")
                
            return True
        except Exception as e:
            logger.error(f"Error creating default users: {str(e)}")
            return False

    def create_default_domain(self):
        """Create default domain"""
        try:
            domain = self.domain_manager.get_domain('datainteg.com')
            if not domain:
                self.domain_manager.add_domain('datainteg.com')
                logger.info("Created default domain: datainteg.com")
            return True
        except Exception as e:
            logger.error(f"Error creating default domain: {str(e)}")
            return False
            
    def create_sample_emails(self):
        """Create sample emails for demo"""
        try:
            logger.info("Creating sample emails...")
            
            sample_emails = [
                {
                    'message_id': 'welcome-001@datainteg.com',
                    'sender': 'admin@datainteg.com',
                    'recipients': ['support@datainteg.com'],
                    'subject': 'Welcome to DataInteg Mail',
                    'body': 'Welcome to your new professional email system. This is a sample email to demonstrate the functionality.',
                    'folder': 'INBOX'
                },
                {
                    'message_id': 'update-002@datainteg.com',
                    'sender': 'system@datainteg.com',
                    'recipients': ['admin@datainteg.com'],
                    'subject': 'System Update Notification',
                    'body': 'Your email server has been successfully configured with MongoDB backend and GridFS support.',
                    'folder': 'INBOX'
                },
                {
                    'message_id': 'features-003@datainteg.com',
                    'sender': 'support@datainteg.com',
                    'recipients': ['admin@datainteg.com'],
                    'subject': 'New Features Available',
                    'body': 'Check out the new features: responsive design, file attachments, search functionality, and more!',
                    'folder': 'INBOX'
                }
            ]
            
            for email_data in sample_emails:
                # Check if email already exists
                existing = self.db.emails.find_one({'message_id': email_data['message_id']})
                if not existing:
                    email_data['created_at'] = datetime.utcnow()
                    email_data['is_read'] = False
                    email_data['is_starred'] = False
                    email_data['is_deleted'] = False
                    self.db.emails.insert_one(email_data)
                    
            logger.info("Sample emails created successfully")
            return True
        except Exception as e:
            logger.error(f"Error creating sample emails: {str(e)}")
            return False
            
    def get_system_stats(self):
        """Get system statistics"""
        try:
            stats = {
                'total_users': self.user_manager.get_user_count(),
                'total_emails': self.db.emails.count_documents({}),
                'total_domains': len(self.domain_manager.get_all_domains()),
                'storage_used_mb': 0,  # Will be calculated from GridFS
                'unread_emails': self.db.emails.count_documents({'is_read': False}),
                'last_updated': datetime.utcnow()
            }
            
            # Calculate storage usage
            try:
                pipeline = [{'$group': {'_id': None, 'total': {'$sum': '$length'}}}]
                result = list(self.db.fs.files.aggregate(pipeline))
                if result:
                    stats['storage_used_mb'] = round(result[0]['total'] / (1024 * 1024), 2)
            except:
                pass
                
            return stats
        except Exception as e:
            logger.error(f"Error getting system stats: {str(e)}")
            return {}
            
    def cleanup_old_data(self, days=30):
        """Clean up old data (emails in trash, old attachments)"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Delete old emails from trash
            result = self.db.emails.delete_many({
                'folder': 'TRASH',
                'updated_at': {'$lt': cutoff_date}
            })
            
            logger.info(f"Cleaned up {result.deleted_count} old emails from trash")
            return True
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")
            return False
