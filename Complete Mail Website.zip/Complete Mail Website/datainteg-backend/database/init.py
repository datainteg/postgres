"""
DataInteg Email Server - Database Module

This module handles all database connections, operations, and migrations.
Designed for MongoDB with proper connection pooling and error handling.
"""

from .connection import MongoDBConnection, get_database
from .operations import DatabaseOperations
from .migrations import DatabaseMigrations

__all__ = [
    'MongoDBConnection',
    'get_database', 
    'DatabaseOperations',
    'DatabaseMigrations'
]
