import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseMigrations:
    """Database migration and setup scripts"""
    
    def __init__(self, database):
        self.db = database
        
    def run_migrations(self):
        """Run all database migrations"""
        try:
            logger.info("Running database migrations...")
            
            # Migration 1: Ensure collections exist
            self._ensure_collections()
            
            # Migration 2: Create indexes
            self._create_indexes()
            
            # Migration 3: Add default data
            self._add_default_data()
            
            logger.info("Database migrations completed successfully")
            return True
        except Exception as e:
            logger.error(f"Error running migrations: {str(e)}")
            return False
            
    def _ensure_collections(self):
        """Ensure all required collections exist"""
        collections = [
            'users', 'emails', 'domains', 'folders',
            'fs.files', 'fs.chunks'  # GridFS collections
        ]
        
        existing_collections = self.db.list_collection_names()
        
        for collection_name in collections:
            if collection_name not in existing_collections:
                self.db.create_collection(collection_name)
                logger.info(f"Created collection: {collection_name}")
                
    def _create_indexes(self):
        """Create database indexes for performance"""
        # User indexes
        self.db.users.create_index('username', unique=True)
        self.db.users.create_index('email', unique=True)
        
        # Email indexes
        self.db.emails.create_index('message_id', unique=True)
        self.db.emails.create_index('sender')
        self.db.emails.create_index('recipients')
        self.db.emails.create_index('created_at')
        self.db.emails.create_index([('sender', 1), ('created_at', -1)])
        self.db.emails.create_index([('recipients', 1), ('created_at', -1)])
        
        # Text search index for emails
        try:
            self.db.emails.create_index([
                ('subject', 'text'),
                ('body', 'text'),
                ('sender', 'text')
            ])
        except:
            pass  # Index might already exist
            
        # Domain indexes
        self.db.domains.create_index('domain_name', unique=True)
        
        # Folder indexes
        self.db.folders.create_index([('user_id', 1), ('name', 1)], unique=True)
        
        logger.info("Database indexes created")
        
    def _add_default_data(self):
        """Add default data if not exists"""
        # Add default domain
        if not self.db.domains.find_one({'domain_name': 'datainteg.com'}):
            self.db.domains.insert_one({
                'domain_name': 'datainteg.com',
                'is_active': True,
                'created_at': datetime.utcnow(),
                'mx_records': [],
                'dkim_enabled': False,
                'spf_record': 'v=spf1 include:datainteg.com ~all'
            })
            logger.info("Added default domain")
            
    def reset_database(self):
        """Reset database - USE WITH CAUTION"""
        try:
            logger.warning("RESETTING DATABASE - ALL DATA WILL BE LOST")
            
            collections_to_drop = ['users', 'emails', 'domains', 'folders', 'fs.files', 'fs.chunks']
            
            for collection_name in collections_to_drop:
                self.db[collection_name].drop()
                
            # Re-run migrations
            self.run_migrations()
            
            logger.info("Database reset completed")
            return True
        except Exception as e:
            logger.error(f"Error resetting database: {str(e)}")
            return False
