import os
import logging
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from config import Config

logger = logging.getLogger(__name__)

class MongoDBConnection:
    """MongoDB connection manager with connection pooling"""
    
    def __init__(self, config=None):
        self.config = config or Config()
        self.client = None
        self.database = None
        
    def connect(self):
        """Establish connection to MongoDB"""
        try:
            self.client = MongoClient(
                self.config.MONGODB_URI,
                serverSelectionTimeoutMS=self.config.MONGODB_SERVER_SELECTION_TIMEOUT,
                connectTimeoutMS=self.config.MONGODB_CONNECT_TIMEOUT,
                maxPoolSize=50,
                minPoolSize=10,
                maxIdleTimeMS=30000,
                waitQueueTimeoutMS=5000,
                retryWrites=True
            )
            
            # Test connection
            self.client.admin.command('ismaster')
            
            # Get database
            self.database = self.client[self.config.MONGODB_DB]
            
            logger.info(f"Successfully connected to MongoDB database: {self.config.MONGODB_DB}")
            return True
            
        except ConnectionFailure as e:
            logger.error(f"Failed to connect to MongoDB: {str(e)}")
            return False
        except ServerSelectionTimeoutError as e:
            logger.error(f"MongoDB server selection timeout: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error connecting to MongoDB: {str(e)}")
            return False
            
    def get_database(self):
        """Get database instance"""
        if not self.database:
            if not self.connect():
                raise Exception("Failed to connect to MongoDB")
        return self.database
        
    def close(self):
        """Close MongoDB connection"""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")
            
    def test_connection(self):
        """Test MongoDB connection health"""
        try:
            if self.client:
                self.client.admin.command('ping')
                return True
            return False
        except Exception as e:
            logger.error(f"MongoDB connection test failed: {str(e)}")
            return False

# Global connection instance
_mongo_connection = None

def get_database():
    """Get global database instance"""
    global _mongo_connection
    
    if _mongo_connection is None:
        _mongo_connection = MongoDBConnection()
        
    return _mongo_connection.get_database()

def close_connection():
    """Close global database connection"""
    global _mongo_connection
    
    if _mongo_connection:
        _mongo_connection.close()
        _mongo_connection = None
