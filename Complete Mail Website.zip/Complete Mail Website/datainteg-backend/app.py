from flask import Flask, jsonify
from flask_cors import CORS
import logging
import sys
import os
from datetime import datetime

# Import configuration
from config import Config

# Import database
from database.connection import get_database, close_connection
from database.operations import DatabaseOperations

# Import API blueprints
from api.auth_routes import auth_bp
from api.mail_routes import mail_bp
from api.admin_routes import admin_bp

# Import email server
from email_server.smtp_server import start_smtp_server

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('datainteg_email.log')
    ]
)
logger = logging.getLogger(__name__)

def create_app(config_class=Config):
    """Application factory"""
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Enable CORS
    CORS(app, origins=config_class.CORS_ORIGINS)
    
    return app

# Create Flask application
app = create_app()

# =============================================================================
# HEALTH CHECK AND ROOT ENDPOINTS
# =============================================================================

@app.route('/', methods=['GET'])
def root():
    """Root endpoint"""
    return jsonify({
        'message': 'DataInteg Email Server API',
        'version': '2.0.0',
        'status': 'running',
        'timestamp': datetime.utcnow().isoformat(),
        'endpoints': {
            'health': '/api/health',
            'auth': '/api/auth/*',
            'mail': '/api/mail/*',
            'admin': '/api/admin/*'
        }
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        db = get_database()
        db.command('ping')
        db_status = 'healthy'
    except Exception as e:
        logger.error(f"Database health check failed: {str(e)}")
        db_status = 'unhealthy'
    
    health_data = {
        'status': 'healthy' if db_status == 'healthy' else 'unhealthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '2.0.0',
        'database': db_status,
        'uptime': 'running'
    }
    
    status_code = 200 if db_status == 'healthy' else 503
    return jsonify(health_data), status_code

# =============================================================================
# ERROR HANDLERS
# =============================================================================

@app.errorhandler(400)
def bad_request(error):
    """Handle 400 errors"""
    return jsonify({
        'success': False,
        'error': 'Bad request',
        'status_code': 400
    }), 400

@app.errorhandler(401)
def unauthorized(error):
    """Handle 401 errors"""
    return jsonify({
        'success': False,
        'error': 'Unauthorized',
        'status_code': 401
    }), 401

@app.errorhandler(403)
def forbidden(error):
    """Handle 403 errors"""
    return jsonify({
        'success': False,
        'error': 'Forbidden',
        'status_code': 403
    }), 403

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Not found',
        'status_code': 404
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({
        'success': False,
        'error': 'Internal server error',
        'status_code': 500
    }), 500

# =============================================================================
# REGISTER BLUEPRINTS
# =============================================================================

app.register_blueprint(auth_bp)
app.register_blueprint(mail_bp)
app.register_blueprint(admin_bp)

# =============================================================================
# APPLICATION INITIALIZATION
# =============================================================================

def initialize_application():
    """Initialize application with database setup"""
    try:
        logger.info("Initializing DataInteg Email Server...")
        
        # Test database connection
        db = get_database()
        logger.info("✅ Database connection established")
        
        # Initialize database operations
        db_ops = DatabaseOperations()
        
        # Create indexes
        if app.config['CREATE_INDEXES_ON_STARTUP']:
            logger.info("Creating database indexes...")
            db_ops.create_indexes()
            logger.info("✅ Database indexes created")
        
        # Create default users
        logger.info("Setting up default users...")
        db_ops.create_default_users()
        logger.info("✅ Default users created")
        
        # Create default domain
        logger.info("Setting up default domain...")
        db_ops.create_default_domain()
        logger.info("✅ Default domain created")
        
        # Create sample emails
        logger.info("Creating sample emails...")
        db_ops.create_sample_emails()
        logger.info("✅ Sample emails created")
        
        logger.info("🎉 Application initialization completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Application initialization failed: {str(e)}")
        return False

def start_email_servers():
    """Start SMTP and IMAP servers"""
    try:
        logger.info("Starting email servers...")
        
        # Start SMTP server
        smtp_server = start_smtp_server(
            host=app.config['SMTP_HOST'],
            port=app.config['SMTP_PORT']
        )
        
        if smtp_server:
            logger.info(f"✅ SMTP server started on {app.config['SMTP_HOST']}:{app.config['SMTP_PORT']}")
        else:
            logger.warning("⚠️ SMTP server failed to start")
            
        return smtp_server
        
    except Exception as e:
        logger.error(f"❌ Error starting email servers: {str(e)}")
        return None

# =============================================================================
# APPLICATION STARTUP
# =============================================================================

if __name__ == '__main__':
    logger.info("🚀 Starting DataInteg Email Server...")
    logger.info(f"Environment: {'Development' if app.config['DEBUG'] else 'Production'}")
    logger.info(f"MongoDB URI: {app.config['MONGODB_URI']}")
    logger.info(f"Domain: {app.config['DOMAIN']}")
    
    # Initialize application
    if not initialize_application():
        logger.error("Failed to initialize application. Exiting.")
        sys.exit(1)
    
    # Start email servers
    smtp_server = start_email_servers()
    
    try:
        # Start Flask application
        logger.info(f"🌐 Starting Flask server on http://0.0.0.0:5000")
        logger.info("📧 Demo credentials: admin/admin123, support/support123")
        logger.info("🔗 Frontend should connect to: http://localhost:5000")
        logger.info("Press Ctrl+C to stop the server")
        
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=app.config['DEBUG'],
            threaded=True
        )
        
    except KeyboardInterrupt:
        logger.info("\n🛑 Shutting down DataInteg Email Server...")
        
        # Stop SMTP server
        if smtp_server:
            smtp_server.stop()
            
        # Close database connection
        close_connection()
        
        logger.info("👋 Server stopped successfully")
        
    except Exception as e:
        logger.error(f"❌ Server error: {str(e)}")
        
        # Cleanup
        if smtp_server:
            smtp_server.stop()
        close_connection()
        
        sys.exit(1)
