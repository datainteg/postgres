# 📧 **DataInteg Email Server - Backend**

[![Flask](https://img.shields.io/badge/Flask-3.0-green?logo=flask)](https://flask.palletsprojects.com/)
[![MongoDB](https://img.shields.io/badge/MongoDB-7.0-green?logo=mongodb)](https://www.mongodb.com/)
[![Python](https://img.shields.io/badge/Python-3.11-blue?logo=python)](https://python.org/)
[![GridFS](https://img.shields.io/badge/GridFS-Enabled-orange)](https://docs.mongodb.com/manual/core/gridfs/)

A **professional email server backend** built with Flask, MongoDB, and GridFS. Features complete email management, user authentication, file attachments, and SMTP/IMAP server functionality.

## 📁 **Project Structure**

datainteg-backend/
├── 🚀 Core Application
│ ├── app.py # Main Flask application with routing
│ ├── config.py # Configuration management with env vars
│ ├── requirements.txt # Python dependencies
│ └── .env # Environment variables
│
├── 🗄️ Database Layer
│ ├── models/
│ │ ├── user.py # User model with authentication
│ │ ├── email.py # Email model with CRUD operations
│ │ ├── attachment.py # File attachment via GridFS
│ │ ├── domain.py # Email domain management
│ │ └── folder.py # Email folder organization
│ │
│ └── database/
│ ├── connection.py # MongoDB connection management
│ ├── operations.py # Centralized database operations
│ └── migrations.py # Database setup and migrations
│
├── 🔌 API Layer
│ ├── api/
│ │ ├── auth_routes.py # Authentication endpoints

│ │ ├── admin_routes.py # Admin management APIs
│ │ └── utils.py # API helpers and decorators
│
├── 🛠️ Utilities
│ ├── utils/
│ │ ├── auth_utils.py # JWT tokens, password hashing
│ │ ├── email_utils.py # Email parsing and formatting
│ │ └── file_utils.py # File validation and processing
│
├── 📧 Email Server
│ ├── email_server/
│ │ ├── smtp_server.py # SMTP server implementation
│ │ └── imap_server.py # IMAP server implementation
│
└── 🐳 Deployment