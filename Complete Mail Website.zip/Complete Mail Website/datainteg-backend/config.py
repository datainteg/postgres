import os
from datetime import timedelta
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Application configuration class"""
    
    # Flask configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'datainteg-email-server-secret-key-2025'
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    TESTING = os.environ.get('FLASK_TESTING', 'False').lower() == 'true'
    
    # Domain configuration
    DOMAIN = os.environ.get('DOMAIN') or 'datainteg.com'
    FRONTEND_URL = os.environ.get('FRONTEND_URL') or 'http://localhost:3000'
    
    # MongoDB configuration
    MONGODB_URI = os.environ.get('MONGODB_URI') or 'mongodb://localhost:27017/'
    MONGODB_DB = os.environ.get('MONGODB_DB') or 'datainteg_email'
    MONGODB_CONNECT_TIMEOUT = int(os.environ.get('MONGODB_CONNECT_TIMEOUT', 5000))
    MONGODB_SERVER_SELECTION_TIMEOUT = int(os.environ.get('MONGODB_SERVER_SELECTION_TIMEOUT', 3000))
    
    # JWT configuration
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or SECRET_KEY
    JWT_EXPIRATION_DELTA = timedelta(days=int(os.environ.get('JWT_EXPIRATION_DAYS', 30)))
    JWT_ALGORITHM = 'HS256'
    
    # Email server configuration
    SMTP_HOST = os.environ.get('SMTP_HOST') or '0.0.0.0'
    SMTP_PORT = int(os.environ.get('SMTP_PORT', 8025))
    IMAP_HOST = os.environ.get('IMAP_HOST') or '0.0.0.0'
    IMAP_PORT = int(os.environ.get('IMAP_PORT', 8143))
    
    # File upload configuration
    MAX_CONTENT_LENGTH = int(os.environ.get('MAX_CONTENT_LENGTH', 100 * 1024 * 1024))  # 100MB
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or 'uploads'
    ALLOWED_EXTENSIONS = {
        'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'bmp', 'tiff',
        'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
        'zip', 'rar', '7z', 'tar', 'gz',
        'mp3', 'mp4', 'avi', 'mkv', 'mov',
        'csv', 'json', 'xml', 'yml', 'yaml'
    }
    
    # User configuration
    DEFAULT_QUOTA_MB = int(os.environ.get('DEFAULT_QUOTA_MB', 1000))  # 1GB
    ADMIN_QUOTA_MB = int(os.environ.get('ADMIN_QUOTA_MB', 10000))  # 10GB
    
    # Security configuration
    PASSWORD_MIN_LENGTH = int(os.environ.get('PASSWORD_MIN_LENGTH', 6))
    USERNAME_MIN_LENGTH = int(os.environ.get('USERNAME_MIN_LENGTH', 3))
    
    # CORS configuration
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:3000,https://datainteg.com').split(',')
    
    # Logging configuration
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FILE = os.environ.get('LOG_FILE', 'datainteg_email.log')
    
    # Database indexing
    CREATE_INDEXES_ON_STARTUP = os.environ.get('CREATE_INDEXES_ON_STARTUP', 'True').lower() == 'true'

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False
    PASSWORD_MIN_LENGTH = 8
    JWT_EXPIRATION_DELTA = timedelta(days=7)

class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    MONGODB_DB = 'datainteg_email_test'

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
