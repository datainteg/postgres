"""
DataInteg Email Server - Email Server Module

This module contains SMTP and IMAP server implementations
for handling email sending and receiving functionality.
"""

from .smtp_server import SMTPHandler, start_smtp_server
from .imap_server import IMAPServer, start_imap_server

__all__ = [
    'SMTPHandler', 'start_smtp_server',
    'IMAPServer', 'start_imap_server'
]
