import asyncio
import socket
import threading
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class IMAPServer:
    """Basic IMAP server implementation for email retrieval"""
    
    def __init__(self, host='localhost', port=8143, db_operations=None):
        self.host = host
        self.port = port
        self.db_ops = db_operations
        self.server_socket = None
        self.running = False
        
    def start(self):
        """Start IMAP server"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            
            self.running = True
            logger.info(f"IMAP server started on {self.host}:{self.port}")
            
            # Start accepting connections in a separate thread
            thread = threading.Thread(target=self._accept_connections)
            thread.daemon = True
            thread.start()
            
            return True
        except Exception as e:
            logger.error(f"Error starting IMAP server: {str(e)}")
            return False
            
    def _accept_connections(self):
        """Accept client connections"""
        while self.running:
            try:
                client_socket, addr = self.server_socket.accept()
                logger.info(f"IMAP client connected from {addr}")
                
                # Handle client in separate thread
                thread = threading.Thread(
                    target=self._handle_client, 
                    args=(client_socket,)
                )
                thread.daemon = True
                thread.start()
                
            except Exception as e:
                if self.running:
                    logger.error(f"Error accepting IMAP connection: {str(e)}")
                    
    def _handle_client(self, client_socket):
        """Handle individual IMAP client"""
        try:
            # Send greeting
            client_socket.send(b"* OK DataInteg IMAP Server ready\r\n")
            
            authenticated = False
            selected_folder = None
            
            while True:
                data = client_socket.recv(1024)
                if not data:
                    break
                    
                command = data.decode('utf-8', errors='ignore').strip()
                logger.debug(f"IMAP command: {command}")
                
                # Parse command
                parts = command.split(' ', 2)
                if len(parts) < 2:
                    client_socket.send(b"* BAD Invalid command\r\n")
                    continue
                    
                tag, cmd = parts[0], parts[1].upper()
                args = parts[2] if len(parts) > 2 else ""
                
                # Handle commands
                response = self._handle_command(tag, cmd, args, authenticated, selected_folder)
                
                if response:
                    client_socket.send(response.encode() + b"\r\n")
                    
                    # Update authentication status
                    if cmd == "LOGIN" and response.startswith(tag + " OK"):
                        authenticated = True
                    elif cmd == "SELECT" and response.startswith(tag + " OK"):
                        selected_folder = args.strip('"')
                        
        except Exception as e:
            logger.error(f"Error handling IMAP client: {str(e)}")
        finally:
            client_socket.close()
            
    def _handle_command(self, tag, cmd, args, authenticated, selected_folder):
        """Handle IMAP commands"""
        try:
            if cmd == "CAPABILITY":
                return f"* CAPABILITY IMAP4rev1 AUTH=PLAIN\r\n{tag} OK CAPABILITY completed"
                
            elif cmd == "LOGIN":
                # Simple authentication - in production, use proper auth
                return f"{tag} OK LOGIN completed"
                
            elif cmd == "LIST":
                if not authenticated:
                    return f"{tag} NO Not authenticated"
                folders = ['INBOX', 'SENT', 'DRAFTS', 'TRASH', 'SPAM']
                response_lines = []
                for folder in folders:
                    response_lines.append(f'* LIST () "/" "{folder}"')
                response_lines.append(f"{tag} OK LIST completed")
                return "\r\n".join(response_lines)
                
            elif cmd == "SELECT":
                if not authenticated:
                    return f"{tag} NO Not authenticated"
                folder = args.strip('"')
                return f"* 0 EXISTS\r\n* 0 RECENT\r\n{tag} OK SELECT completed"
                
            elif cmd == "LOGOUT":
                return f"* BYE DataInteg IMAP Server logging out\r\n{tag} OK LOGOUT completed"
                
            else:
                return f"{tag} BAD Command not implemented"
                
        except Exception as e:
            logger.error(f"Error handling IMAP command {cmd}: {str(e)}")
            return f"{tag} BAD Server error"
            
    def stop(self):
        """Stop IMAP server"""
        try:
            self.running = False
            if self.server_socket:
                self.server_socket.close()
            logger.info("IMAP server stopped")
            return True
        except Exception as e:
            logger.error(f"Error stopping IMAP server: {str(e)}")
            return False

def start_imap_server(host='0.0.0.0', port=8143, db_operations=None):
    """Start IMAP server"""
    try:
        imap_server = IMAPServer(host, port, db_operations)
        imap_server.start()
        return imap_server
    except Exception as e:
        logger.error(f"Error starting IMAP server: {str(e)}")
        return None
