import asyncio
import logging
from datetime import datetime
from aiosmtpd.controller import Controller
from aiosmtpd.handlers import Message
from email import message_from_string
from utils.email_utils import parse_email_content, generate_message_id
from database.operations import DatabaseOperations

logger = logging.getLogger(__name__)

class SMTPHandler:
    """Custom SMTP handler for processing incoming emails"""
    
    def __init__(self, db_operations=None):
        self.db_ops = db_operations or DatabaseOperations()
        
    async def handle_RCPT(self, server, session, envelope, address, rcpt_options):
        """Handle RCPT TO command"""
        try:
            # Validate recipient domain
            domain = address.split('@')[1].lower()
            if not self.db_ops.domain_manager.get_domain(domain):
                return '550 Domain not accepted'
                
            envelope.rcpt_tos.append(address)
            return '250 OK'
        except Exception as e:
            logger.error(f"Error handling RCPT: {str(e)}")
            return '550 Error processing recipient'
            
    async def handle_DATA(self, server, session, envelope):
        """Handle email data"""
        try:
            # Parse email content
            parsed = parse_email_content(envelope.content.decode('utf-8', errors='ignore'))
            if not parsed:
                return '550 Error parsing email'
                
            # Generate message ID if not present
            if not parsed['message_id']:
                parsed['message_id'] = generate_message_id()
                
            # Store email in database
            email_id = self.db_ops.email_manager.store_email(
                message_id=parsed['message_id'],
                sender=envelope.mail_from,
                recipients=envelope.rcpt_tos,
                subject=parsed['subject'],
                body=parsed['body'],
                html_body=parsed['html_body']
            )
            
            if email_id:
                logger.info(f"Email stored successfully: {email_id}")
                return '250 Message accepted for delivery'
            else:
                return '550 Error storing email'
                
        except Exception as e:
            logger.error(f"Error handling email data: {str(e)}")
            return '550 Error processing email'

class DataIntegSMTPServer:
    """DataInteg SMTP server implementation"""
    
    def __init__(self, host='localhost', port=8025):
        self.host = host
        self.port = port
        self.controller = None
        self.handler = SMTPHandler()
        
    def start(self):
        """Start SMTP server"""
        try:
            self.controller = Controller(
                self.handler,
                hostname=self.host,
                port=self.port
            )
            self.controller.start()
            logger.info(f"SMTP server started on {self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"Error starting SMTP server: {str(e)}")
            return False
            
    def stop(self):
        """Stop SMTP server"""
        try:
            if self.controller:
                self.controller.stop()
                logger.info("SMTP server stopped")
                return True
            return False
        except Exception as e:
            logger.error(f"Error stopping SMTP server: {str(e)}")
            return False

def start_smtp_server(host='0.0.0.0', port=8025):
    """Start SMTP server in a separate thread"""
    try:
        smtp_server = DataIntegSMTPServer(host, port)
        smtp_server.start()
        return smtp_server
    except Exception as e:
        logger.error(f"Error starting SMTP server: {str(e)}")
        return None
