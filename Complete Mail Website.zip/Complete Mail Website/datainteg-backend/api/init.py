"""
DataInteg Email Server - API Routes Module

This module contains all API route definitions for authentication,
email operations, and administrative functions.
"""

from .auth_routes import auth_bp
from .mail_routes import mail_bp  
from .admin_routes import admin_bp
from .utils import require_auth, require_admin, success_response, error_response

__all__ = [
    'auth_bp', 'mail_bp', 'admin_bp',
    'require_auth', 'require_admin', 'success_response', 'error_response'
]
