from flask import Blueprint, request, jsonify, g, send_file
from database.operations import DatabaseOperations
from utils.email_utils import format_email_for_frontend, generate_message_id
from utils.file_utils import validate_file_upload
from .utils import require_auth, success_response, error_response, validate_json_request
import logging
import io

logger = logging.getLogger(__name__)
mail_bp = Blueprint('mail', __name__, url_prefix='/api/mail')

@mail_bp.route('/emails', methods=['GET'])
@require_auth
def get_emails():
    """Get emails for authenticated user"""
    try:
        user = g.current_user
        folder = request.args.get('folder', 'INBOX').upper()
        limit = min(int(request.args.get('limit', 50)), 100)
        skip = int(request.args.get('skip', 0))
        search = request.args.get('search', '')
        
        db_ops = DatabaseOperations()
        emails = db_ops.email_manager.get_user_emails(
            user_email=user.email,
            folder=folder,
            skip=skip,
            limit=limit,
            search=search if search else None
        )
        
        # Format emails for frontend
        formatted_emails = []
        for email in emails:
            formatted_email = format_email_for_frontend(email.to_dict())
            formatted_emails.append(formatted_email)
        
        return success_response('Emails retrieved successfully', {
            'emails': formatted_emails,
            'total': len(formatted_emails),
            'folder': folder
        })
        
    except Exception as e:
        logger.error(f"Error getting emails: {str(e)}")
        return error_response('Failed to retrieve emails', 500)

@mail_bp.route('/send', methods=['POST'])
@require_auth
@validate_json_request(['to', 'subject'])
def send_email():
    """Send email endpoint"""
    try:
        user = g.current_user
        data = request.get_json()
        
        # Extract email data
        recipients = data['to'] if isinstance(data['to'], list) else [data['to']]
        cc = data.get('cc', [])
        bcc = data.get('bcc', [])
        subject = data['subject']
        body = data.get('body', '')
        html_body = data.get('html_body')
        attachments = data.get('attachments', [])
        
        # All recipients
        all_recipients = recipients + cc + bcc
        
        db_ops = DatabaseOperations()
        message_id = generate_message_id(user.email.split('@')[1])
        
        # Store email
        email_id = db_ops.email_manager.store_email(
            message_id=message_id,
            sender=user.email,
            recipients=all_recipients,
            subject=subject,
            body=body,
            html_body=html_body,
            attachments=attachments
        )
        
        if email_id:
            # Move to sent folder
            db_ops.email_manager.move_to_folder(email_id, 'SENT')
            
            return success_response('Email sent successfully', {
                'email_id': email_id,
                'message_id': message_id
            })
        else:
            return error_response('Failed to send email', 500)
            
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return error_response('Failed to send email', 500)

@mail_bp.route('/folders', methods=['GET'])
@require_auth
def get_folder_counts():
    """Get email counts for each folder"""
    try:
        user = g.current_user
        db_ops = DatabaseOperations()
        counts = db_ops.email_manager.get_folder_counts(user.email)
        
        return success_response('Folder counts retrieved', {
            'inbox': counts.get('inbox', 0),
            'sent': counts.get('sent', 0),
            'drafts': counts.get('drafts', 0),
            'spam': counts.get('spam', 0),
            'trash': counts.get('trash', 0)
        })
        
    except Exception as e:
        logger.error(f"Error getting folder counts: {str(e)}")
        return error_response('Failed to get folder counts', 500)

@mail_bp.route('/upload', methods=['POST'])
@require_auth
def upload_file():
    """Upload file attachment"""
    try:
        user = g.current_user
        
        if 'file' not in request.files:
            return error_response('No file provided', 400)
            
        file = request.files['file']
        if file.filename == '':
            return error_response('No file selected', 400)
            
        # Validate file
        valid, message = validate_file_upload(file)
        if not valid:
            return error_response(message, 400)
            
        db_ops = DatabaseOperations()
        
        # Store file in GridFS
        file_id = db_ops.attachment_manager.store_attachment(
            filename=file.filename,
            file_data=file.read(),
            content_type=file.content_type or 'application/octet-stream',
            user_id=str(user.__dict__.get('_id') or 'user_id')
        )
        
        if file_id:
            return success_response('File uploaded successfully', {
                'file_id': file_id,
                'filename': file.filename,
                'content_type': file.content_type,
                'size': len(file.read()) if hasattr(file, 'read') else 0
            })
        else:
            return error_response('Failed to upload file', 500)
            
    except Exception as e:
        logger.error(f"Error uploading file: {str(e)}")
        return error_response('Failed to upload file', 500)

@mail_bp.route('/download/<file_id>', methods=['GET'])
@require_auth
def download_file(file_id):
    """Download file attachment"""
    try:
        user = g.current_user
        db_ops = DatabaseOperations()
        
        file_data = db_ops.attachment_manager.get_attachment(file_id)
        if not file_data:
            return error_response('File not found', 404)
            
        return send_file(
            io.BytesIO(file_data['data']),
            as_attachment=True,
            download_name=file_data['filename'],
            mimetype=file_data['content_type']
        )
        
    except Exception as e:
        logger.error(f"Error downloading file: {str(e)}")
        return error_response('Failed to download file', 500)

@mail_bp.route('/<email_id>/read', methods=['PUT'])
@require_auth
def mark_as_read(email_id):
    """Mark email as read"""
    try:
        db_ops = DatabaseOperations()
        db_ops.email_manager.mark_as_read(email_id)
        
        return success_response('Email marked as read')
        
    except Exception as e:
        logger.error(f"Error marking email as read: {str(e)}")
        return error_response('Failed to mark email as read', 500)

@mail_bp.route('/<email_id>/star', methods=['PUT'])
@require_auth
def toggle_star(email_id):
    """Toggle email star status"""
    try:
        data = request.get_json() or {}
        starred = data.get('starred', True)
        
        db_ops = DatabaseOperations()
        db_ops.email_manager.mark_as_starred(email_id, starred)
        
        return success_response(f'Email {"starred" if starred else "unstarred"}')
        
    except Exception as e:
        logger.error(f"Error toggling star: {str(e)}")
        return error_response('Failed to toggle star', 500)

@mail_bp.route('/<email_id>', methods=['DELETE'])
@require_auth
def delete_email(email_id):
    """Delete email (move to trash)"""
    try:
        permanent = request.args.get('permanent', 'false').lower() == 'true'
        
        db_ops = DatabaseOperations()
        db_ops.email_manager.delete_email(email_id, permanent=permanent)
        
        message = 'Email permanently deleted' if permanent else 'Email moved to trash'
        return success_response(message)
        
    except Exception as e:
        logger.error(f"Error deleting email: {str(e)}")
        return error_response('Failed to delete email', 500)

@mail_bp.route('/<email_id>/move', methods=['PUT'])
@require_auth
@validate_json_request(['folder'])
def move_email(email_id):
    """Move email to different folder"""
    try:
        data = request.get_json()
        folder = data['folder'].upper()
        
        valid_folders = ['INBOX', 'SENT', 'DRAFTS', 'SPAM', 'TRASH']
        if folder not in valid_folders:
            return error_response('Invalid folder', 400)
            
        db_ops = DatabaseOperations()
        db_ops.email_manager.move_to_folder(email_id, folder)
        
        return success_response(f'Email moved to {folder.lower()}')
        
    except Exception as e:
        logger.error(f"Error moving email: {str(e)}")
        return error_response('Failed to move email', 500)
