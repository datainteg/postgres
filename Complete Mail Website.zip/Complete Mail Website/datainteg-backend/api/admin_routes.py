from flask import Blueprint, request, jsonify, g
from database.operations import DatabaseOperations
from .utils import require_auth, require_role, success_response, error_response, validate_json_request
import logging
from datetime import datetime

logger = logging.getLogger(__name__)
admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

def require_admin_role(f):
    """Decorator to require admin role"""
    @require_auth
    def decorated_function(*args, **kwargs):
        if not g.current_user.has_role('admin'):
            return error_response('Admin role required', 403)
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/users', methods=['GET'])
@require_admin_role
def get_all_users():
    """Get all users for admin panel"""
    try:
        page = int(request.args.get('page', 1))
        per_page = min(int(request.args.get('per_page', 50)), 100)
        search = request.args.get('search', '')
        
        db_ops = DatabaseOperations()
        
        # Build query
        query = {}
        if search:
            query['$or'] = [
                {'username': {'$regex': search, '$options': 'i'}},
                {'email': {'$regex': search, '$options': 'i'}},
                {'display_name': {'$regex': search, '$options': 'i'}}
            ]
            
        # Get users with pagination
        skip = (page - 1) * per_page
        users_cursor = db_ops.db.users.find(query).skip(skip).limit(per_page).sort('created_at', -1)
        total_count = db_ops.db.users.count_documents(query)
        
        users_list = []
        for user_data in users_cursor:
            users_list.append({
                'id': str(user_data['_id']),
                'username': user_data['username'],
                'email': user_data['email'],
                'display_name': user_data.get('display_name', ''),
                'roles': user_data.get('roles', ['user']),
                'is_active': user_data.get('is_active', True),
                'created_at': user_data.get('created_at', '').isoformat() if user_data.get('created_at') else '',
                'last_login': user_data.get('last_login', '').isoformat() if user_data.get('last_login') else None
            })
        
        return success_response('Users retrieved successfully', {
            'users': users_list,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total_count,
                'pages': (total_count + per_page - 1) // per_page
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting users: {str(e)}")
        return error_response('Failed to get users', 500)

@admin_bp.route('/users', methods=['POST'])
@require_admin_role
@validate_json_request(['username', 'email', 'password'])
def create_user():
    """Create new user via admin panel"""
    try:
        data = request.get_json()
        
        db_ops = DatabaseOperations()
        user_id = db_ops.user_manager.create_user(
            username=data['username'],
            email=data['email'],
            password=data['password'],
            display_name=data.get('display_name', data['username']),
            roles=data.get('roles', ['user'])
        )
        
        return success_response('User created successfully', {
            'user_id': user_id,
            'username': data['username'],
            'email': data['email'],
            'roles': data.get('roles', ['user'])
        }, 201)
            
    except ValueError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Error creating user: {str(e)}")
        return error_response('Failed to create user', 500)

@admin_bp.route('/users/<user_id>', methods=['PUT'])
@require_admin_role
def update_user(user_id):
    """Update user via admin panel"""
    try:
        data = request.get_json()
        if not data:
            return error_response('No update data provided', 400)
            
        db_ops = DatabaseOperations()
        
        # Get current user
        user = db_ops.user_manager.get_user_by_id(user_id)
        if not user:
            return error_response('User not found', 404)
            
        # Prevent admin from removing own admin role
        current_user = g.current_user
        if (str(user.__dict__.get('_id')) == str(current_user.__dict__.get('_id')) and 
            'roles' in data and 'admin' not in data['roles']):
            return error_response('Cannot remove admin role from yourself', 400)
            
        # Update allowed fields
        update_data = {}
        if 'display_name' in data:
            update_data['display_name'] = data['display_name']
        if 'email' in data:
            update_data['email'] = data['email']
        if 'roles' in data:
            update_data['roles'] = data['roles']
        if 'is_active' in data:
            update_data['is_active'] = data['is_active']
            
        # Update user
        db_ops.db.users.update_one(
            {'_id': user.__dict__.get('_id')},
            {'$set': update_data}
        )
        
        return success_response('User updated successfully')
        
    except Exception as e:
        logger.error(f"Error updating user: {str(e)}")
        return error_response('Failed to update user', 500)

@admin_bp.route('/users/<user_id>/password', methods=['PUT'])
@require_admin_role
@validate_json_request(['new_password'])
def reset_password(user_id):
    """Reset user password via admin panel"""
    try:
        data = request.get_json()
        new_password = data['new_password']
        
        if len(new_password) < 6:
            return error_response('Password must be at least 6 characters', 400)
            
        db_ops = DatabaseOperations()
        user = db_ops.user_manager.get_user_by_id(user_id)
        if not user:
            return error_response('User not found', 404)
            
        # Update password
        db_ops.user_manager.update_user_password(user_id, new_password)
        
        return success_response('Password reset successfully')
        
    except Exception as e:
        logger.error(f"Error resetting password: {str(e)}")
        return error_response('Failed to reset password', 500)

@admin_bp.route('/users/<user_id>', methods=['DELETE'])
@require_admin_role
def delete_user(user_id):
    """Delete user via admin panel"""
    try:
        db_ops = DatabaseOperations()
        user = db_ops.user_manager.get_user_by_id(user_id)
        if not user:
            return error_response('User not found', 404)
            
        # Prevent admin from deleting themselves
        current_user = g.current_user
        if str(user.__dict__.get('_id')) == str(current_user.__dict__.get('_id')):
            return error_response('Cannot delete your own account', 400)
            
        # Delete user
        db_ops.user_manager.delete_user(user_id)
        
        return success_response('User deleted successfully')
        
    except Exception as e:
        logger.error(f"Error deleting user: {str(e)}")
        return error_response('Failed to delete user', 500)

@admin_bp.route('/roles', methods=['GET'])
@require_admin_role
def get_available_roles():
    """Get list of available roles"""
    roles = [
        {'value': 'admin', 'label': 'Administrator', 'description': 'Full system access'},
        {'value': 'developer', 'label': 'Developer', 'description': 'Development access'},
        {'value': 'user', 'label': 'User', 'description': 'Standard user access'}
    ]
    
    return success_response('Available roles', {'roles': roles})
