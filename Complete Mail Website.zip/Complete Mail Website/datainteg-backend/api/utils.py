from functools import wraps
from flask import request, jsonify, g
from utils.auth_utils import verify_jwt_token
from database.operations import DatabaseOperations
import logging

logger = logging.getLogger(__name__)

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return error_response('No valid authorization token provided', 401)
            
        token = auth_header.split(' ')[1]
        user_id = verify_jwt_token(token)
        
        if not user_id:
            return error_response('Invalid or expired token', 401)
            
        # Get user data
        try:
            db_ops = DatabaseOperations()
            user = db_ops.user_manager.get_user_by_id(user_id)
            if not user or not user.is_active:
                return error_response('User not found or inactive', 401)
                
            g.current_user = user
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in auth decorator: {str(e)}")
            return error_response('Authentication error', 500)
            
    return decorated_function

def require_admin(f):
    """Decorator to require admin privileges"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not hasattr(g, 'current_user') or not g.current_user.is_admin:
            return error_response('Admin privileges required', 403)
        return f(*args, **kwargs)
    return decorated_function

def success_response(message, data=None, status_code=200):
    """Create standardized success response"""
    response = {'success': True, 'message': message}
    if data is not None:
        response['data'] = data
    return jsonify(response), status_code

def error_response(message, status_code=400, error_code=None):
    """Create standardized error response"""
    response = {
        'success': False,
        'error': message,
        'status_code': status_code
    }
    if error_code:
        response['error_code'] = error_code
    return jsonify(response), status_code

def validate_json_request(required_fields=None):
    """Decorator to validate JSON request"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not request.is_json:
                return error_response('Request must be JSON', 400)
                
            data = request.get_json()
            if not data:
                return error_response('No JSON data provided', 400)
                
            if required_fields:
                missing_fields = [field for field in required_fields if field not in data]
                if missing_fields:
                    return error_response(f'Missing required fields: {", ".join(missing_fields)}', 400)
                    
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def paginate_results(query_func, page=1, per_page=50):
    """Helper function for pagination"""
    try:
        page = max(1, page)
        per_page = min(100, max(1, per_page))
        
        skip = (page - 1) * per_page
        results = query_func(skip=skip, limit=per_page)
        
        return {
            'items': results,
            'page': page,
            'per_page': per_page,
            'total': len(results)
        }
    except Exception as e:
        logger.error(f"Error in pagination: {str(e)}")
        return {'items': [], 'page': 1, 'per_page': per_page, 'total': 0}
