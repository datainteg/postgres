from flask import Blueprint, request, jsonify, g
from database.operations import DatabaseOperations
from utils.auth_utils import generate_jwt_token
from .utils import require_auth, success_response, error_response, validate_json_request
import logging

logger = logging.getLogger(__name__)
auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@auth_bp.route('/login', methods=['POST'])
@validate_json_request(['username', 'password'])
def login():
    """User login endpoint"""
    try:
        data = request.get_json()
        username = data['username'].strip()
        password = data['password']
        
        db_ops = DatabaseOperations()
        user = db_ops.user_manager.authenticate_user(username, password)
        
        if not user:
            return error_response('Invalid credentials', 401)
            
        # Generate JWT token
        token = generate_jwt_token(str(user.__dict__.get('_id') or 'user_id'))
        if not token:
            return error_response('Failed to generate authentication token', 500)
            
        # Update last login
        db_ops.user_manager.update_last_login(str(user.__dict__.get('_id') or 'user_id'))
        
        # Prepare user data
        user_data = {
            'id': str(user.__dict__.get('_id') or 'user_id'),
            'username': user.username,
            'email': user.email,
            'display_name': user.display_name,
            'is_admin': user.is_admin,
            'quota_mb': user.quota_mb,
            'used_quota_mb': user.used_quota_mb
        }
        
        return success_response('Login successful', {
            'token': token,
            'user': user_data
        })
        
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return error_response('Login failed', 500)

@auth_bp.route('/register', methods=['POST'])
@validate_json_request(['username', 'email', 'password'])
def register():
    """User registration endpoint"""
    try:
        data = request.get_json()
        username = data['username'].strip()
        email = data['email'].strip().lower()
        password = data['password']
        display_name = data.get('display_name', username)
        
        db_ops = DatabaseOperations()
        
        # Validate input
        if len(username) < 3:
            return error_response('Username must be at least 3 characters long')
        if len(password) < 6:
            return error_response('Password must be at least 6 characters long')
            
        # Check if user exists
        if db_ops.user_manager.get_user_by_username(username):
            return error_response('Username already exists', 409)
        if db_ops.user_manager.get_user_by_email(email):
            return error_response('Email already registered', 409)
            
        # Create user
        user_id = db_ops.user_manager.create_user(
            username=username,
            email=email,
            password=password,
            display_name=display_name
        )
        
        if user_id:
            # Generate JWT token
            token = generate_jwt_token(user_id)
            
            user_data = {
                'id': user_id,
                'username': username,
                'email': email,
                'display_name': display_name,
                'is_admin': False,
                'quota_mb': 1000,
                'used_quota_mb': 0
            }
            
            return success_response('Registration successful', {
                'token': token,
                'user': user_data
            }, 201)
        else:
            return error_response('Failed to create user', 500)
            
    except ValueError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        return error_response('Registration failed', 500)

@auth_bp.route('/verify', methods=['GET'])
@require_auth
def verify_token():
    """Verify JWT token endpoint"""
    try:
        user = g.current_user
        user_data = {
            'id': str(user.__dict__.get('_id') or 'user_id'),
            'username': user.username,
            'email': user.email,
            'display_name': user.display_name,
            'is_admin': user.is_admin,
            'quota_mb': user.quota_mb,
            'used_quota_mb': user.used_quota_mb
        }
        
        return success_response('Token valid', {'user': user_data})
        
    except Exception as e:
        logger.error(f"Token verification error: {str(e)}")
        return error_response('Token verification failed', 500)

@auth_bp.route('/logout', methods=['POST'])
@require_auth
def logout():
    """User logout endpoint"""
    try:
        # In a real implementation, you might want to blacklist the token
        # For now, we'll just return success as the frontend will remove the token
        return success_response('Logged out successfully')
        
    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
        return error_response('Logout failed', 500)

@auth_bp.route('/change-password', methods=['PUT'])
@require_auth
@validate_json_request(['current_password', 'new_password'])
def change_password():
    """Change user password"""
    try:
        data = request.get_json()
        current_password = data['current_password']
        new_password = data['new_password']
        
        user = g.current_user
        
        # Verify current password
        if not user.check_password(current_password):
            return error_response('Current password is incorrect', 401)
            
        # Validate new password
        if len(new_password) < 6:
            return error_response('New password must be at least 6 characters long')
            
        # Update password
        db_ops = DatabaseOperations()
        from werkzeug.security import generate_password_hash
        new_hash = generate_password_hash(new_password)
        
        db_ops.user_manager.collection.update_one(
            {'_id': user.__dict__.get('_id')},
            {'$set': {'password_hash': new_hash}}
        )
        
        return success_response('Password changed successfully')
        
    except Exception as e:
        logger.error(f"Change password error: {str(e)}")
        return error_response('Failed to change password', 500)
