/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        outlook: {
          blue: '#0078d4',
          lightblue: '#106ebe',
          darkblue: '#005a9e',
          gray: '#323130',
          lightgray: '#605e5c',
          border: '#edebe9',
          hover: '#f3f2f1',
        },
        primary: {
          50: '#f0f4ff',
          100: '#e0e9ff',
          500: '#0078d4',
          600: '#106ebe',
          700: '#005a9e',
        },
      },
    },
  },
  plugins: [],
};
