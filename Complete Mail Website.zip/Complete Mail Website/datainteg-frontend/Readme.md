datainteg-frontend/
├── 📦 Configuration Files
│   ├── package.json                 # Project dependencies and scripts
│   ├── next.config.js              # Next.js configuration with API proxy
│   ├── tailwind.config.js          # Tailwind CSS with Outlook theme colors
│   ├── postcss.config.js           # PostCSS configuration for Tailwind
│   └── .env.local                  # Environment variables
│
├── 🧩 Components Architecture
│   ├── auth/                       # Authentication Components
│   │   └── LoginForm/
│   │       ├── LoginForm.js            # Login form with demo credentials
│   │       └── LoginForm.module.css    # Styled form with Outlook theme
│   │
│   ├── layout/                     # Layout Components
│   │   └── Header/
│   │       ├── Header.js               # App header with navigation
│   │       └── Header.module.css       # Header styling
│   │
│   └── mail/                       # Mail Components (Core Features)
│       ├── MailLayout/
│       │   ├── MailLayout.js           # Main mail container with state management
│       │   └── MailLayout.module.css   # Layout styling
│       ├── Sidebar/
│       │   ├── Sidebar.js              # Folder navigation & user info
│       │   └── Sidebar.module.css      # Outlook-style sidebar
│       ├── MailList/
│       │   ├── MailList.js             # Email list with search & filters
│       │   └── MailList.module.css     # List styling with read/unread states
│       ├── MailViewer/
│       │   ├── MailViewer.js           # Email content viewer
│       │   └── MailViewer.module.css   # Email display styling
│       ├── TopBar/
│       │   ├── TopBar.js               # Search bar & user menu
│       │   └── TopBar.module.css       # Top navigation styling
│       └── Compose/
│           ├── Compose.js              # Email composition modal
│           └── Compose.module.css      # Compose form styling
│
├── 📄 Pages (Next.js Routing)
│   ├── _app.js                         # Global app wrapper with toast notifications
│   ├── _document.js                    # HTML document structure
│   ├── index.js                        # Landing page (redirects to login)
│   ├── login.js                        # Login page with authentication
│   └── mail/
│       └── index.js                    # Main mail interface (protected route)
│
├── 🎨 Styling
│   └── globals.css                     # Global styles, CSS variables, animations
│
└── 📚 Library
    └── api.js                          # API client with axios & auth interceptors
