import { useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

export default function HomePage() {
  const router = useRouter();

  useEffect(() => {
    router.push('/login');
  }, [router]);

  return (
    <>
      <Head>
        <title>DataInteg Mail - Professional Email</title>
      </Head>
      <div className="min-h-screen flex items-center justify-center bg-outlook-blue">
        <div className="text-white text-center">
          <div className="text-6xl mb-4">📧</div>
          <h1 className="text-2xl font-semibold mb-2">DataInteg Mail</h1>
          <p>Redirecting to login...</p>
        </div>
      </div>
    </>
  );
}
