import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Cookies from 'js-cookie';
import toast from 'react-hot-toast';
import AdminLayout from '../../components/admin/AdminLayout/AdminLayout';

export default function AdminPage() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = Cookies.get('auth-token');
    const userData = Cookies.get('user-data');
    
    if (!token || !userData) {
      router.push('/login');
      return;
    }

    try {
      const parsedUser = JSON.parse(userData);
      
      // Check if user has admin role
      if (!parsedUser.roles || !parsedUser.roles.includes('admin')) {
        toast.error('Admin access required');
        router.push('/mail');
        return;
      }
      
      setUser(parsedUser);
    } catch (error) {
      console.error('Auth check error:', error);
      toast.error('Authentication failed');
      router.push('/login');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-outlook-blue mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Head>
        <title>Admin Panel - DataInteg</title>
      </Head>
      
      <AdminLayout user={user} />
    </>
  );
}
