import { useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';
import LoginForm from '../components/auth/LoginForm/LoginForm';

export default function LoginPage() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleLogin = async (credentials) => {
    setLoading(true);
    
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      const data = await response.json();

      if (response.ok) {
        // Store token and user data
        Cookies.set('auth-token', data.data.token, { expires: 30 });
        Cookies.set('user-data', JSON.stringify(data.data.user), { expires: 30 });
        
        // Show role-based welcome message
        const userRoles = data.data.user.roles.join(', ');
        toast.success(`Welcome ${data.data.user.display_name}! Roles: ${userRoles}`);
        
        // Redirect based on role
        if (data.data.user.roles.includes('admin')) {
          router.push('/admin');
        } else {
          router.push('/mail');
        }
      } else {
        toast.error(data.error || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Head>
        <title>Sign In - DataInteg Mail</title>
      </Head>
      
      <div className="min-h-screen bg-gradient-to-br from-outlook-blue to-outlook-darkblue flex items-center justify-center py-12 px-4">
        <LoginForm onLogin={handleLogin} loading={loading} />
      </div>
    </>
  );
}
