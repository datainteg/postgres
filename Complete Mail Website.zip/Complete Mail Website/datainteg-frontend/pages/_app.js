import '../styles/globals.css';
import { Toaster } from 'react-hot-toast';

export default function App({ Component, pageProps }) {
  return (
    <>
      <Component {...pageProps} />
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#323130',
            color: '#fff',
          },
          success: {
            duration: 3000,
            iconTheme: {
              primary: '#0078d4',
              secondary: '#fff',
            },
          },
        }}
      />
    </>
  );
}
