/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  
  // API proxy to Python backend
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:5000/api/:path*',
      },
    ];
  },
  
  env: {
    DOMAIN_NAME: 'datainteg.com',
    BACKEND_URL: 'http://localhost:5000',
  },
  
  experimental: {
    largePageDataBytes: 128 * 1024,
  },
};

module.exports = nextConfig;
