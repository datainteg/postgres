import { useState } from 'react';
import styles from './LoginForm.module.css';

export default function LoginForm({ onLogin, loading }) {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(formData);
  };

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        {/* Header */}
        <div className={styles.header}>
          <div className={styles.logo}>
            <span className={styles.icon}>📧</span>
            <h1>DataInteg Mail</h1>
          </div>
          <p className={styles.subtitle}>Professional Email & Admin System</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.formGroup}>
            <label className={styles.label}>Username</label>
            <input
              type="text"
              required
              value={formData.username}
              onChange={(e) => setFormData({...formData, username: e.target.value})}
              className={styles.input}
              placeholder="Enter your username"
            />
          </div>

          <div className={styles.formGroup}>
            <label className={styles.label}>Password</label>
            <input
              type="password"
              required
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className={styles.input}
              placeholder="Enter your password"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className={styles.submitButton}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        {/* Role Tags */}
        <div className={styles.roleSection}>
          <p className={styles.roleTitle}>Available User Types:</p>
          <div className={styles.roleTags}>
            <span className={styles.roleTag + ' ' + styles.adminTag}>
              👨‍💼 Admin Users
            </span>
            <span className={styles.roleTag + ' ' + styles.developerTag}>
              💻 Developer Users  
            </span>
            <span className={styles.roleTag + ' ' + styles.userTag}>
              👤 Standard Users
            </span>
          </div>
          <p className={styles.roleNote}>
            Contact your administrator for login credentials
          </p>
        </div>
      </div>
    </div>
  );
}
