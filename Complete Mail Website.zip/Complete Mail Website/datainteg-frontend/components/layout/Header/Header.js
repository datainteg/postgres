import Link from 'next/link';
import { useState } from 'react';
import styles from './Header.module.css';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <div className={styles.content}>
          <Link href="/" className={styles.logo}>
            <span className={styles.logoIcon}>📧</span>
            <span className={styles.logoText}>DataInteg Mail</span>
          </Link>
          
          <nav className={styles.nav}>
            <Link href="/" className={styles.navLink}>Home</Link>
            <Link href="/login" className={styles.navLink}>Login</Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
