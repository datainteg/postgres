import { useState } from 'react';
import UserManagement from '../UserManagement/UserManagement';
import AdminSidebar from '../AdminSidebar/AdminSidebar';
import AdminTopBar from '../AdminTopBar/AdminTopBar';
import styles from './AdminLayout.module.css';

export default function AdminLayout({ user }) {
  const [activeSection, setActiveSection] = useState('users');

  const renderContent = () => {
    switch (activeSection) {
      case 'users':
        return <UserManagement />;
      case 'statistics':
        return <div className={styles.placeholder}>System Statistics (Coming Soon)</div>;
      case 'settings':
        return <div className={styles.placeholder}>System Settings (Coming Soon)</div>;
      default:
        return <UserManagement />;
    }
  };

  return (
    <div className={styles.container}>
      <AdminTopBar user={user} />
      
      <div className={styles.main}>
        <AdminSidebar
          activeSection={activeSection}
          onSectionChange={setActiveSection}
        />
        
        <div className={styles.content}>
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
