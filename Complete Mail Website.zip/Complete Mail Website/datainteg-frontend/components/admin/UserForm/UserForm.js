import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import Cookies from 'js-cookie';
import styles from './UserForm.module.css';

export default function UserForm({ user, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    display_name: '',
    password: '',
    roles: ['user'],
    is_active: true
  });
  const [loading, setLoading] = useState(false);
  const [availableRoles, setAvailableRoles] = useState([]);

  useEffect(() => {
    loadAvailableRoles();
    
    if (user) {
      setFormData({
        username: user.username,
        email: user.email,
        display_name: user.display_name,
        password: '', // Don't show existing password
        roles: user.roles,
        is_active: user.is_active
      });
    }
  }, [user]);

  const loadAvailableRoles = async () => {
    try {
      const token = Cookies.get('auth-token');
      const response = await fetch('/api/admin/roles', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setAvailableRoles(data.data.roles);
      }
    } catch (error) {
      console.error('Load roles error:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = Cookies.get('auth-token');
      const url = user ? `/api/admin/users/${user.id}` : '/api/admin/users';
      const method = user ? 'PUT' : 'POST';
      
      const submitData = { ...formData };
      if (user && !submitData.password) {
        delete submitData.password; // Don't update password if empty
      }

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(submitData),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(user ? 'User updated successfully' : 'User created successfully');
        onSave();
      } else {
        toast.error(data.error || 'Operation failed');
      }
    } catch (error) {
      console.error('Submit error:', error);
      toast.error('Operation failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = (role, checked) => {
    if (checked) {
      setFormData({
        ...formData,
        roles: [...formData.roles, role]
      });
    } else {
      setFormData({
        ...formData,
        roles: formData.roles.filter(r => r !== role)
      });
    }
  };

  return (
    <div className={styles.overlay}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h3>{user ? 'Edit User' : 'Create New User'}</h3>
          <button onClick={onCancel} className={styles.closeButton}>✕</button>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.row}>
            <div className={styles.field}>
              <label className={styles.label}>Username</label>
              <input
                type="text"
                required
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                className={styles.input}
                disabled={user} // Can't change username after creation
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label}>Email</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className={styles.input}
              />
            </div>
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Display Name</label>
            <input
              type="text"
              value={formData.display_name}
              onChange={(e) => setFormData({...formData, display_name: e.target.value})}
              className={styles.input}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label}>
              {user ? 'New Password (leave blank to keep current)' : 'Password'}
            </label>
            <input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className={styles.input}
              required={!user}
              minLength={6}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Roles</label>
            <div className={styles.rolesContainer}>
              {availableRoles.map((role) => (
                <label key={role.value} className={styles.roleCheckbox}>
                  <input
                    type="checkbox"
                    checked={formData.roles.includes(role.value)}
                    onChange={(e) => handleRoleChange(role.value, e.target.checked)}
                  />
                  <span className={styles.roleLabel}>
                    {role.label}
                    <small className={styles.roleDescription}>{role.description}</small>
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className={styles.field}>
            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                checked={formData.is_active}
                onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
              />
              User is active
            </label>
          </div>

          <div className={styles.actions}>
            <button
              type="button"
              onClick={onCancel}
              className={styles.cancelButton}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className={styles.saveButton}
            >
              {loading ? 'Saving...' : (user ? 'Update User' : 'Create User')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
