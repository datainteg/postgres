import { useState } from 'react';
import styles from './UserList.module.css';

export default function UserList({ users, loading, onEdit, onDelete, onRefresh }) {
  const [sortField, setSortField] = useState('created_at');
  const [sortDirection, setSortDirection] = useState('desc');

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedUsers = [...users].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    
    if (sortDirection === 'asc') {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });

  const formatDate = (dateString) => {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleString();
  };

  const formatRoles = (roles) => {
    return roles.map(role => (
      <span key={role} className={`${styles.roleTag} ${styles[role + 'Tag']}`}>
        {role}
      </span>
    ));
  };

  if (loading) {
    return (
      <div className={styles.loading}>
        <div className={styles.spinner}></div>
        <span>Loading users...</span>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.tableHeader}>
        <h3>Users ({users.length})</h3>
        <button onClick={onRefresh} className={styles.refreshButton}>
          🔄 Refresh
        </button>
      </div>

      <div className={styles.tableContainer}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th onClick={() => handleSort('username')}>
                Username {sortField === 'username' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th onClick={() => handleSort('email')}>
                Email {sortField === 'email' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th>Display Name</th>
              <th>Roles</th>
              <th>Status</th>
              <th onClick={() => handleSort('created_at')}>
                Created {sortField === 'created_at' && (sortDirection === 'asc' ? '↑' : '↓')}
              </th>
              <th>Last Login</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedUsers.map((user) => (
              <tr key={user.id}>
                <td className={styles.username}>{user.username}</td>
                <td>{user.email}</td>
                <td>{user.display_name}</td>
                <td className={styles.roles}>
                  {formatRoles(user.roles)}
                </td>
                <td>
                  <span className={`${styles.status} ${user.is_active ? styles.active : styles.inactive}`}>
                    {user.is_active ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td>{formatDate(user.created_at)}</td>
                <td>{formatDate(user.last_login)}</td>
                <td className={styles.actions}>
                  <button
                    onClick={() => onEdit(user)}
                    className={styles.editButton}
                    title="Edit User"
                  >
                    ✏️
                  </button>
                  <button
                    onClick={() => onDelete(user.id)}
                    className={styles.deleteButton}
                    title="Delete User"
                  >
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {users.length === 0 && (
          <div className={styles.emptyState}>
            <p>No users found</p>
          </div>
        )}
      </div>
    </div>
  );
}
