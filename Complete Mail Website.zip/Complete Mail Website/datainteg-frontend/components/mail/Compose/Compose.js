import { useState } from 'react';
import toast from 'react-hot-toast';
import styles from './Compose.module.css';

export default function Compose({ user, onClose, onSent }) {
  const [formData, setFormData] = useState({
    to: '',
    cc: '',
    bcc: '',
    subject: '',
    body: ''
  });
  const [showCc, setShowCc] = useState(false);
  const [showBcc, setShowBcc] = useState(false);
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.to.trim()) {
      toast.error('Please enter recipient email');
      return;
    }

    setSending(true);

    try {
      // Simulate sending email
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success('Email sent successfully!');
      onSent();
    } catch (error) {
      console.error('Send email error:', error);
      toast.error('Failed to send email');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className={styles.overlay}>
      <div className={styles.container}>
        {/* Header */}
        <div className={styles.header}>
          <h3 className={styles.title}>New message</h3>
          <button onClick={onClose} className={styles.closeButton}>
            ✕
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className={styles.form}>
          {/* Recipients */}
          <div className={styles.recipients}>
            <div className={styles.recipientRow}>
              <label className={styles.recipientLabel}>To:</label>
              <input
                type="email"
                multiple
                value={formData.to}
                onChange={(e) => setFormData({...formData, to: e.target.value})}
                placeholder="Enter email addresses separated by commas"
                className={styles.recipientInput}
                required
              />
            </div>

            <div className={styles.recipientActions}>
              {!showCc && (
                <button
                  type="button"
                  onClick={() => setShowCc(true)}
                  className={styles.addRecipientButton}
                >
                  Cc
                </button>
              )}
              {!showBcc && (
                <button
                  type="button"
                  onClick={() => setShowBcc(true)}
                  className={styles.addRecipientButton}
                >
                  Bcc
                </button>
              )}
            </div>

            {showCc && (
              <div className={styles.recipientRow}>
                <label className={styles.recipientLabel}>Cc:</label>
                <input
                  type="email"
                  multiple
                  value={formData.cc}
                  onChange={(e) => setFormData({...formData, cc: e.target.value})}
                  placeholder="Enter email addresses separated by commas"
                  className={styles.recipientInput}
                />
              </div>
            )}

            {showBcc && (
              <div className={styles.recipientRow}>
                <label className={styles.recipientLabel}>Bcc:</label>
                <input
                  type="email"
                  multiple
                  value={formData.bcc}
                  onChange={(e) => setFormData({...formData, bcc: e.target.value})}
                  placeholder="Enter email addresses separated by commas"
                  className={styles.recipientInput}
                />
              </div>
            )}
          </div>

          {/* Subject */}
          <div className={styles.subjectRow}>
            <input
              type="text"
              value={formData.subject}
              onChange={(e) => setFormData({...formData, subject: e.target.value})}
              placeholder="Add a subject"
              className={styles.subjectInput}
            />
          </div>

          {/* Body */}
          <div className={styles.bodyContainer}>
            <textarea
              value={formData.body}
              onChange={(e) => setFormData({...formData, body: e.target.value})}
              placeholder="Type your message here..."
              className={styles.bodyTextarea}
              rows={12}
            />
          </div>

          {/* Actions */}
          <div className={styles.actions}>
            <div className={styles.leftActions}>
              <button
                type="submit"
                disabled={sending}
                className={styles.sendButton}
              >
                {sending ? 'Sending...' : 'Send'}
              </button>

              <button type="button" className={styles.attachButton}>
                📎 Attach
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className={styles.discardButton}
            >
              Discard
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
