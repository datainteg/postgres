import { useState } from 'react';
import styles from './TopBar.module.css';

export default function TopBar({ user, onCompose, onRefresh }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    console.log('Search:', searchTerm);
  };

  return (
    <div className={styles.container}>
      {/* Left section */}
      <div className={styles.left}>
        <div className={styles.logo}>
          <span className={styles.logoIcon}>📧</span>
          <span className={styles.logoText}>DataInteg Mail</span>
        </div>
      </div>

      {/* Center section - Search */}
      <div className={styles.center}>
        <form onSubmit={handleSearch} className={styles.searchForm}>
          <div className={styles.searchBox}>
            <span className={styles.searchIcon}>🔍</span>
            <input
              type="text"
              placeholder="Search mail and people"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={styles.searchInput}
            />
          </div>
        </form>
      </div>

      {/* Right section */}
      <div className={styles.right}>
        <button onClick={onRefresh} className={styles.iconButton} title="Refresh">
          🔄
        </button>
        
        <button onClick={onCompose} className={styles.composeButton}>
          <span className={styles.composeIcon}>✏️</span>
          <span className={styles.composeText}>New message</span>
        </button>

        {/* User menu */}
        <div className={styles.userMenu}>
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className={styles.userButton}
          >
            <div className={styles.userAvatar}>
              {(user?.display_name || user?.username || 'U').charAt(0).toUpperCase()}
            </div>
          </button>

          {showUserMenu && (
            <div className={styles.userDropdown}>
              <div className={styles.userInfo}>
                <div className={styles.userName}>
                  {user?.display_name || user?.username}
                </div>
                <div className={styles.userEmail}>{user?.email}</div>
              </div>
              <div className={styles.dropdownDivider}></div>
              <button className={styles.dropdownItem}>
                ⚙️ Settings
              </button>
              <button className={styles.dropdownItem}>
                ❓ Help
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
