import { useState, useEffect } from 'react';
import Sidebar from '../Sidebar/Sidebar';
import MailList from '../MailList/MailList';
import MailViewer from '../MailViewer/MailViewer';
import TopBar from '../TopBar/TopBar';
import Compose from '../Compose/Compose';
import styles from './MailLayout.module.css';

export default function MailLayout({ user }) {
  const [selectedFolder, setSelectedFolder] = useState('INBOX');
  const [emails, setEmails] = useState([]);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [showCompose, setShowCompose] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailCounts, setEmailCounts] = useState({});

  // Sample emails for demonstration
  useEffect(() => {
    loadSampleEmails();
  }, [selectedFolder]);

  const loadSampleEmails = () => {
    setLoading(true);
    
    // Simulate API call with sample data
    setTimeout(() => {
      const sampleEmails = [
        {
          id: '1',
          sender: 'john.doe@company.com',
          recipients: ['me@datainteg.com'],
          subject: 'Welcome to DataInteg Mail',
          body: 'Thank you for using our professional email service. This is a sample email to demonstrate the functionality.',
          created_at: new Date().toISOString(),
          is_read: false,
          attachments: []
        },
        {
          id: '2',
          sender: 'support@datainteg.com',
          recipients: ['me@datainteg.com'],
          subject: 'System Update Notification',
          body: 'Our email system has been updated with new features including improved security and performance.',
          created_at: new Date(Date.now() - 3600000).toISOString(),
          is_read: true,
          attachments: [{ filename: 'update-notes.pdf', size: 1024 }]
        },
        {
          id: '3',
          sender: 'admin@datainteg.com',
          recipients: ['me@datainteg.com'],
          subject: 'Account Setup Complete',
          body: 'Your DataInteg Mail account has been successfully configured. You can now send and receive emails.',
          created_at: new Date(Date.now() - 7200000).toISOString(),
          is_read: true,
          attachments: []
        }
      ];
      
      setEmails(sampleEmails);
      setEmailCounts({
        inbox: sampleEmails.length,
        sent: 0,
        drafts: 0,
        spam: 0,
        trash: 0
      });
      setLoading(false);
    }, 500);
  };

  const handleRefresh = () => {
    loadSampleEmails();
  };

  return (
    <div className={styles.container}>
      <TopBar 
        user={user} 
        onCompose={() => setShowCompose(true)}
        onRefresh={handleRefresh}
      />
      
      <div className={styles.main}>
        <Sidebar
          user={user}
          selectedFolder={selectedFolder}
          onFolderChange={setSelectedFolder}
          emailCounts={emailCounts}
          onCompose={() => setShowCompose(true)}
        />
        
        <MailList
          emails={emails}
          loading={loading}
          selectedEmail={selectedEmail}
          onEmailSelect={setSelectedEmail}
          folder={selectedFolder}
        />
        
        <MailViewer
          email={selectedEmail}
          onClose={() => setSelectedEmail(null)}
        />
      </div>

      {showCompose && (
        <Compose
          user={user}
          onClose={() => setShowCompose(false)}
          onSent={() => {
            setShowCompose(false);
            handleRefresh();
          }}
        />
      )}
    </div>
  );
}
