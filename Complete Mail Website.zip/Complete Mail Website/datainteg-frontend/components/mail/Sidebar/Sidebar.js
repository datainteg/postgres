import { useRouter } from 'next/router';
import Cookies from 'js-cookie';
import toast from 'react-hot-toast';
import styles from './Sidebar.module.css';

export default function Sidebar({ 
  user, 
  selectedFolder, 
  onFolderChange, 
  emailCounts = {},
  onCompose 
}) {
  const router = useRouter();

  const folders = [
    { 
      id: 'INBOX', 
      name: 'Inbox', 
      icon: '📥', 
      count: emailCounts.inbox || 0,
      color: '#0078d4'
    },
    { 
      id: 'SENT', 
      name: 'Sent Items', 
      icon: '📤', 
      count: emailCounts.sent || 0,
      color: '#107c10'
    },
    { 
      id: 'DRAFTS', 
      name: 'Drafts', 
      icon: '📝', 
      count: emailCounts.drafts || 0,
      color: '#ff8c00'
    },
    { 
      id: 'SPAM', 
      name: 'Junk Email', 
      icon: '🚫', 
      count: emailCounts.spam || 0,
      color: '#d13438'
    },
    { 
      id: 'TRASH', 
      name: 'Deleted Items', 
      icon: '🗑️', 
      count: emailCounts.trash || 0,
      color: '#605e5c'
    }
  ];

  const handleLogout = () => {
    Cookies.remove('auth-token');
    toast.success('Logged out successfully');
    router.push('/login');
  };

  return (
    <div className={styles.container}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.logo}>
          <span className={styles.logoIcon}>📧</span>
          <span className={styles.logoText}>Mail</span>
        </div>
        <button onClick={onCompose} className={styles.composeButton}>
          <span className={styles.composeIcon}>✏️</span>
          New message
        </button>
      </div>

      {/* Folders */}
      <div className={styles.folders}>
        <div className={styles.folderTitle}>Folders</div>
        {folders.map((folder) => (
          <button
            key={folder.id}
            onClick={() => onFolderChange(folder.id)}
            className={`${styles.folderItem} ${
              selectedFolder === folder.id ? styles.folderActive : ''
            }`}
          >
            <div className={styles.folderLeft}>
              <span className={styles.folderIcon}>{folder.icon}</span>
              <span className={styles.folderName}>{folder.name}</span>
            </div>
            {folder.count > 0 && (
              <span className={styles.folderCount}>{folder.count}</span>
            )}
          </button>
        ))}
      </div>

      {/* User Info */}
      <div className={styles.userSection}>
        <div className={styles.userInfo}>
          <div className={styles.userAvatar}>
            {(user?.display_name || user?.username || 'U').charAt(0).toUpperCase()}
          </div>
          <div className={styles.userDetails}>
            <div className={styles.userName}>
              {user?.display_name || user?.username}
            </div>
            <div className={styles.userEmail}>{user?.email}</div>
          </div>
        </div>
        <button onClick={handleLogout} className={styles.logoutButton}>
          🚪
        </button>
      </div>
    </div>
  );
}
