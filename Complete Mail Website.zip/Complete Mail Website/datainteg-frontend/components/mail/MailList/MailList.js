import { useState } from 'react';
import { format } from 'date-fns';
import styles from './MailList.module.css';

export default function MailList({ 
  emails = [], 
  loading, 
  selectedEmail, 
  onEmailSelect, 
  folder = 'INBOX' 
}) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredEmails = emails.filter(email =>
    email.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    email.sender?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    email.body?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return format(date, 'HH:mm');
    } else if (diffInHours < 168) { // 7 days
      return format(date, 'EEE');
    } else {
      return format(date, 'MMM d');
    }
  };

  const truncateText = (text, maxLength = 100) => {
    if (!text) return '';
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };

  const getSenderDisplay = (email) => {
    if (folder === 'SENT') {
      return email.recipients && email.recipients.length > 0 
        ? `To: ${email.recipients.join(', ')}` 
        : 'Unknown';
    }
    return email.sender || 'Unknown';
  };

  return (
    <div className={styles.container}>
      {/* Header */}
      <div className={styles.header}>
        <h2 className={styles.title}>
          {folder.charAt(0) + folder.slice(1).toLowerCase()}
          {filteredEmails.length > 0 && (
            <span className={styles.count}>({filteredEmails.length})</span>
          )}
        </h2>
      </div>

      {/* Search */}
      <div className={styles.searchContainer}>
        <div className={styles.searchBox}>
          <span className={styles.searchIcon}>🔍</span>
          <input
            type="text"
            placeholder={`Search in ${folder.toLowerCase()}...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={styles.searchInput}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className={styles.clearButton}
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Email List */}
      <div className={styles.emailList}>
        {loading ? (
          <div className={styles.loading}>
            <div className={styles.spinner}></div>
            <span>Loading emails...</span>
          </div>
        ) : filteredEmails.length === 0 ? (
          <div className={styles.empty}>
            <div className={styles.emptyIcon}>
              {searchTerm ? '🔍' : '📭'}
            </div>
            <p className={styles.emptyTitle}>
              {searchTerm ? 'No search results' : 'No emails found'}
            </p>
            <p className={styles.emptySubtitle}>
              {searchTerm 
                ? `No emails match "${searchTerm}"`
                : `No emails in ${folder.toLowerCase()}`
              }
            </p>
          </div>
        ) : (
          filteredEmails.map((email) => (
            <div
              key={email.id}
              onClick={() => onEmailSelect(email)}
              className={`${styles.emailItem} ${
                !email.is_read ? styles.unread : ''
              } ${selectedEmail?.id === email.id ? styles.selected : ''}`}
            >
              <div className={styles.emailContent}>
                <div className={styles.emailHeader}>
                  <div className={styles.sender}>
                    {getSenderDisplay(email)}
                  </div>
                  <div className={styles.date}>
                    {formatDate(email.created_at)}
                  </div>
                </div>
                
                <div className={styles.subject}>
                  {email.subject || '(No subject)'}
                </div>
                
                <div className={styles.preview}>
                  {truncateText(email.body)}
                </div>
                
                {email.attachments && email.attachments.length > 0 && (
                  <div className={styles.attachments}>
                    <span className={styles.attachmentIcon}>📎</span>
                    <span className={styles.attachmentCount}>
                      {email.attachments.length} attachment{email.attachments.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
