import { useState } from 'react';
import { format } from 'date-fns';
import styles from './MailViewer.module.css';

export default function MailViewer({ email, onClose }) {
  const [showDetails, setShowDetails] = useState(false);

  if (!email) {
    return (
      <div className={styles.container}>
        <div className={styles.empty}>
          <div className={styles.emptyIcon}>📧</div>
          <h3>Select an email</h3>
          <p>Choose an email from the list to view its contents</p>
        </div>
      </div>
    );
  }

  const formatFullDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return format(date, 'EEEE, MMMM d, yyyy \'at\' h:mm a');
  };

  return (
    <div className={styles.container}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerTop}>
          <h2 className={styles.subject}>
            {email.subject || '(No subject)'}
          </h2>
          <div className={styles.actions}>
            <button className={styles.actionButton} title="Reply">
              ↩️
            </button>
            <button className={styles.actionButton} title="Forward">
              ➡️
            </button>
            <button className={styles.actionButton} title="Delete">
              🗑️
            </button>
            {onClose && (
              <button onClick={onClose} className={styles.closeButton} title="Close">
                ✕
              </button>
            )}
          </div>
        </div>
        
        <div className={styles.metadata}>
          <div className={styles.sender}>
            <div className={styles.senderAvatar}>
              {(email.sender || 'U').charAt(0).toUpperCase()}
            </div>
            <div className={styles.senderInfo}>
              <div className={styles.senderName}>{email.sender}</div>
              <div className={styles.recipients}>
                To: {email.recipients ? email.recipients.join(', ') : 'me'}
              </div>
            </div>
          </div>
          
          <div className={styles.date}>
            {formatFullDate(email.created_at)}
          </div>
        </div>

        {showDetails && (
          <div className={styles.details}>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>From:</span>
              <span>{email.sender}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>To:</span>
              <span>{email.recipients ? email.recipients.join(', ') : 'me'}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Date:</span>
              <span>{formatFullDate(email.created_at)}</span>
            </div>
            <div className={styles.detailRow}>
              <span className={styles.detailLabel}>Subject:</span>
              <span>{email.subject || '(No subject)'}</span>
            </div>
          </div>
        )}

        <button 
          onClick={() => setShowDetails(!showDetails)}
          className={styles.detailsToggle}
        >
          {showDetails ? '🔼 Hide details' : '🔽 Show details'}
        </button>
      </div>

      {/* Attachments */}
      {email.attachments && email.attachments.length > 0 && (
        <div className={styles.attachments}>
          <div className={styles.attachmentsTitle}>
            📎 {email.attachments.length} attachment{email.attachments.length !== 1 ? 's' : ''}
          </div>
          <div className={styles.attachmentList}>
            {email.attachments.map((attachment, index) => (
              <div key={index} className={styles.attachment}>
                <div className={styles.attachmentInfo}>
                  <div className={styles.attachmentName}>{attachment.filename}</div>
                  <div className={styles.attachmentSize}>
                    {attachment.size ? `${Math.round(attachment.size / 1024)} KB` : 'Unknown size'}
                  </div>
                </div>
                <button className={styles.downloadButton}>
                  📥 Download
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Content */}
      <div className={styles.content}>
        <div className={styles.emailBody}>
          {email.html_body ? (
            <div dangerouslySetInnerHTML={{ __html: email.html_body }} />
          ) : (
            <pre className={styles.plainText}>{email.body}</pre>
          )}
        </div>
      </div>
    </div>
  );
}
